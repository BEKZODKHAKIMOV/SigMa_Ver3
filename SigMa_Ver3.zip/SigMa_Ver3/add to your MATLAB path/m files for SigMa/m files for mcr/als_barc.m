function [output]=als_barc(d)

xorg=d;

[nrow,ncol]=size(d);
x0=mean(d,2);

[nrow2,ncol2]=size(x0);

if nrow2==nrow,	nsign=ncol2; ils=1;end
if ncol2==nrow, nsign=nrow2; x0=x0'; ils=1; end 

if ncol2==ncol, nsign=nrow2; ils=2;end
if nrow2==ncol, nsign=ncol2; x0=x0'; ils=2; end

if ils==1,
	conc=x0;
	[nrow,nsign]=size(conc);
	abss=conc\d;
end

if ils==2,
	abss=x0;
	[nsign,ncol]=size(abss);
	conc=d/abss;
end

nexp=1;
nit=10;
nit=10;
tolsigma=0.1;
isp=ones(nexp,nsign);
csel=[];
ssel=[];
vclos1=0;
vclos2=0;
scons='n';
ccons='n';
ncinic(nexp)=1;
ncfin(nexp)=ncol;
nrinic(nexp)=1;
nrfin(nexp)=nrow;

scons='y'; % all the spectra matrices the same constraints
ccons='y'; % all the concentration matrices the same constraints
niter=0;% iterations counter
idev=0;% divergence counter
idevmax=10;% maximum number of diverging iterations
answer='n'; % default answer
ineg=0;% used for non-negativity constraints
imod=0;% used for unimodality constraints
iclos0=0;% used for closure constraints
iassim=0;% used for shape constraints
datamod=99;% in three-way type of matrix augmentation (1=row,2=column)
matr=1;% one matrix
matc=1;% one matrix
vclos1n=0;% used for closure constraints
vclos2n=0;% used for closure constraints
inorm=0;% no normalizatio (when closurfe is applied)
type_csel=[]; %no equality/lower than constraints in concentrations 
type_ssel=[]; %no equality/lower than constraints in spectra

t3=toc

%***************************
% DEFINITION OF THE DATA SET
%***************************

totalconc(1:nsign,1:nexp)=ones(nsign,nexp);

% WHEN ONLY ONE EXPERIMENT IS PRESENT EVERYTHING IS CLEAR

  	nrsol(1)=nrow;
  	nrinic(1)=1;
  	nrfin(1)=nrsol(1);
  	nesp(1)=nsign;
	matr = 1;
	matc = 1;
  	isp(1,1:nsign)=ones(1,nsign);
	ishape=0;

% end

wcons = 1;

if matc>1
ccons='n';
end

if matr>1
scons='n';
end

c1 = find(wcons == 1);
if ~isempty(c1) 

ineg=2;

if ineg==3|ineg ==2

ialgs=1;

	if scons=='y' | nexp == 1
		
		if ialgs == 0
		disp(' ')
		nspneg=input('How many spectra should be positive? ');
			if nspneg == nsign
			spneg = ones(nsign,matr);
			else
			spnegr= input('Enter a vector with the positive spectra (e.g. sp 1 and 3 [1,0,1]) ');
			spneg = spnegr'*ones(1,matr);
			end
		else
			spneg = ones(nsign,matr);
		end
	end

	if scons == 'n'

	spneg=[];	
		for i=1:matr
        selneg='n';
		if selneg =='y'
		if ialgs == 0
		nspneg=input('How many spectra should be positive? ');
			if nspneg == nsign
			spneg(:,i) = ones(nsign,1);
			else
			spneg(:,i)= input('Enter a vector with the positive spectra (e.g. sp 1 and 3 [1,0,1]) ');
			end
		else
			spneg(:,i) = ones(nsign,1);
		end
		end	
		if selneg == 'n'
			spneg(:,i) = zeros(nsign,1);
		end
		end
	end
end

if ineg==1|ineg ==2

       ialg=1;

	if ccons=='y' | nexp == 1
		
		if ialg == 0
		ncneg=input('How many conc profiles should be positive? ');
			if ncneg == nsign
			cneg = ones(matc,nsign);
			else
			cnegr= input('Enter a vector with the positive conc profiles (e.g. conc 1 and 3 [1,0,1]) ');
			cneg = ones(matc,1)*cnegr;
			end
		else
			cneg = ones(matc,nsign);
		end
	end

	if ccons == 'n'

	cneg=[];	
		for i=1:matc
		disp(' ')
		disp(['C submatrix number ' num2str(i)])
% 		selcneg = input('Apply non-negativity? (y/n)','s');
         selcneg = 'y';
		if selcneg =='y'
		if ialg == 0
		ncneg=input('How many conc profiles should be positive? ');
			if ncneg == nsign
			cneg(i,:) = ones(1,nsign);
			else
			cneg(i,:)= input('Enter a vector with the positive conc profiles (e.g. sp 1 and 3 [1,0,1]) ');
			end
		else
			cneg(i,:) = ones(1,nsign);
		end
		end	
		if selcneg == 'n'
			cneg(i,:) = zeros(1,nsign);
		end
		end
	end
	end
else

cneg=zeros(matc,nsign);
spneg = zeros(nsign,matr);
ialg = 99;
ialgs = 99;

end

dn=d;
[u,s,v,d,sd]=pcarep(dn,nsign);


clc
sstn=sum(sum(dn.*dn));
sst=sum(sum(d.*d));
sigma2=sqrt(sstn);

% ************************************************************
% D) STARTING ALTERNATING CONSTRAINED LEAST SQUARES OPTIMIZATION
% ************************************************************

while niter < nit

niter=niter+1;

% ***************************************
% E) ESTIMATE CONCENTRATIONS (ALS solutions)
% ***************************************

conc=d/abss;
	
% ******************************************
% CONSTRAIN APPROPRIATELY THE CONCENTRATIONS
% ******************************************

% ****************
% non-negativity
% ****************

if ~isempty(c1)
    
if ineg==1|ineg==2
    
for i =1:matc

kinic=nrinic(i);
kfin=nrfin(i);
conc2=conc(kinic:kfin,:);

if ialg==0
	for k=1:nsign,
	if cneg(i,k) ==1
		for j=1:kfin+1-kinic,
			if conc2(j,k)<0.0,
				conc2(j,k)=0.0;
			end
		end
	end
	end
end


if ialg==1
	for j=kinic:kfin
		if cneg(i,:) == ones(1,size(isp,2))
		x=lsqnonneg(abss',d(j,:)');
		conc2(j-kinic+1,:)=x';
	end
	end
end


if ialg==2
	for j=kinic:kfin
		if cneg(i,:) == ones(1,size(isp,2)) 
		x=fnnls(abss*abss',abss*d(j,:)');
		conc2(j-kinic+1,:)=x';
	end
	end
end

conc(kinic:kfin,:) = conc2;
end
end
end

% ************
% trilinearity
% ************

if ishape>=1
if trildir==1|trildir==3
   	for j=1:nsign,
   		if spetric(j)==1,
   			[conc(:,j),t]=trilin(conc(:,j),matc,ishape);
            totalconc(j,1:matc)=t;
            if totalconc(j,1)>0,
	   			rt(j,1:matc)=totalconc(j,1:matc)./totalconc(j,1);
            else
               rt(j,1:matc)=totalconc(j,1:matc);
            end
         end
   	end
end
end

% **************************
% zero concentration species
% **************************

if matc>1
for i=1:matc,
	for j=1:nsign,
		if isp(i,j)==0,
				conc(nrinic(i):nrfin(i),j)=zeros(nrsol(i),1);
		end
	end
end
end

% ************************************************
% QUANTITATIVE INFORMATION FOR THREE-WAY DATA SETS
% ************************************************

% recalculation of total and ratio concentrations if ishape=0 or niter=1

if ishape==0 | niter==1,
   	for j=1:nsign,
   		for inexp=1:matc,
   			totalconc(j,inexp)=sum(conc(nrinic(inexp):nrfin(inexp),j));
         end
         if totalconc(j,1)>0,
	   			rt(j,1:matc)=totalconc(j,1:matc)./totalconc(j,1);
         else
               rt(j,1:matc)=totalconc(j,1:matc);
         end
   	end
end

% areas under concentration profiles
area=totalconc;

% ********************************
% ESTIMATE SPECTRA (ALS solution)
% ********************************

abss=conc\d;

% ********************
% non-negative spectra
% ********************

if ineg ==2 |ineg==3,

for i = 1:matr
kinic = ncinic(i);
kfin = ncfin(i);
abss2 = abss(:,kinic:kfin);

	if ialgs==0,
		for k=1:nsign,
		if spneg(k,i)==1
			for j=1:kfin+1-kinic,
    				if abss2(k,j)<0.0,
    					abss2(k,j)=0.0;
    				end
			end
		end
		end
	end

	if ialgs==1,
		for j=kinic:kfin,
			if spneg(:,i)== ones(size(isp,2),1)
			abss2(:,j-kinic+1)=lsqnonneg(conc,d(:,j));
			end
		end
	end

	if ialgs==2, 
		for j=kinic:kfin,
			if spneg(:,i)== ones(size(isp,2),1)			
			abss2(:,j-kinic+1)=fnnls(conc'*conc,conc'*d(:,j));
			end			
		end
	end
abss(:,kinic:kfin)=abss2;
end
end

% ************
% trilinearity
% ************

if ishape>=1,
if trildir==2|trildir==3
   	for j=1:nsign,
   		if spetris(j)==1,
   			[absst,t]=trilin(abss(j,:)',matr,ishape);
			abss(j,:)=absst';
   		end
   	end
end
end

% ************************************
% constrain the unimodality of spectra
% ************************************

for i = 1:matr
kinic = ncinic(i);
kfin = ncfin(i);
abss2 = abss(:,kinic:kfin);

if imod==2|imod==3,
	for j=1:nsign,
		if spsmod(i,j)==1
		dummy=unimod(abss2(j,:)',smod,cmod);
		abss2(j,:)=dummy';
		end
	end
end
abss(:,kinic:kfin)=abss2;
end

% ************************
% NORMALIZATION OF SPECTRA
% ************************

% equal heighth

if inorm==1,
	maxabss=max(abss');
		for i=1:nsign,
			abss(i,:)=abss(i,:)./maxabss(i);
		end
end

% equal length

if inorm==2, abss=normv2(abss); end

% *******************************
% CALCULATE RESIDUALS
% *******************************

res=d-conc*abss;
resn=dn-conc*abss;

% ********************************
% OPTIMIZATION RESULTS
% *********************************

u=sum(sum(res.*res));
un=sum(sum(resn.*resn));
sigma=sqrt(u/(nrow*ncol));
sigman=sqrt(un/(nrow*ncol));
change=((sigma2-sigma)/sigma);

if change < 0.0,
	idev=idev+1;
else
	idev=0;
end
change=change*100;
sstd(1)=sqrt(u/sst)*100;
sstd(2)=sqrt(un/sstn)*100;
r2=(sstn-un)/sstn;

% *************************************************************
% If change is positive, the optimization is working correctly
% *************************************************************

if change>0 | niter==1,
	sigma2=sigma;
	copt=conc;
	sopt=abss;
	sdopt=sstd;
	ropt=res;
	rtopt=rt';
	itopt=niter;
        areaopt=area;
	r2opt=r2;   
end

end
mcrmodeldata=copt*sopt;
residuals=xorg-mcrmodeldata;
output.mcrmodeldata=mcrmodeldata;
output.scores=copt;
output.loadings=sopt;
output.residuals=residuals;
output.expvar=r2opt;

return       

