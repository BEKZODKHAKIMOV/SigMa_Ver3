function [Cnew,Snew,diff,error,lof,expvar] = htals(data,ncomp,nonneg,closure,itermax,endpoint)

% It uses fnnls if nonnegativity is applied
%   ncomp --> three options
%       - ncomp (1x1): number of components. Random spectra will be chosen.
%       - X(ncomp,wavelengths): A matrix containing initial estimations for the spectra (spectra x
%       wavelength)
%       - X(ncomp,noise): A call for simplisma model using its findings as
%       initial estimations.


% Initial estimates

if size(ncomp,1) == 1 && size(ncomp,2) == 1
    a = randperm(size(data,1));
    Snew = data(a(1:ncomp),:);
elseif size(ncomp,1) == 1 && size(ncomp,2) > 1
%     [sp,imp] = htpurity(data',ncomp(1,1),ncomp(1,2));
    Snew = ncomp;
elseif size(ncomp,1) ~= 1
    Snew = ncomp;
end

Snew = Snew./norm(Snew);

% Added by WW, norm of Snew by sum of 1 in each spectra
% 
% for i = 1:size(Snew)
% Snew(i,:) = Snew(i,:)./sum(Snew(i,:));
% end

it = 0;
diff(1) = 1e5;

while it < itermax
    it = it + 1;
    
    if nonneg(1) == 0
        Cnew = data*pinv(Snew);
    elseif nonneg(1) == 1
        Snew = Snew';
        for ii = 1:size(data,1)
            Cnew(ii,:) = fnnls(Snew'*+Snew,Snew'*data(ii,:)'); % Time Consuming Part 
        end
    end
    
    if closure ~= 0
        for ii = 1:size(data,1)
            Cnew(ii,:) = Cnew(ii,:)*closure/sum(Cnew(ii,:));
        end
    end
    
    if nonneg(2) == 0
        Snew = pinv(Cnew)*data;
    elseif nonneg(2) == 1
        for ii = 1:size(data,2)
            Snew2(ii,:) = fnnls(Cnew'*Cnew,Cnew'*data(:,ii));
        end
        Snew = Snew2';
    end
    
    Dnew{it} = Cnew*Snew;
    
    res = Dnew{it} - data;
    error(it) = sum(sum(res.*res));
    sigma(it) = sqrt(error(it)/(size(data,1)*size(data,2)));
    
    if it < 3
        continue
    elseif it >= 2
        diff(it) = abs((sigma(it) - sigma(it-1))/sigma(it));
        if diff(it) > endpoint
            continue
        elseif diff(it) <= endpoint
            break
        end
    end
    
  
    
end

lof = 100*sqrt(error(end)/sum(sum(data*data')));
expvar = 100*sqrt((sum(sum(data*data')) - error(end))/sum(sum(data*data')));

xcalc2 = Cnew(:,:)*Snew(:,:);
var3= 100*((sum(sum(xcalc2.*xcalc2))/sum(sum(data.*data))));

end



