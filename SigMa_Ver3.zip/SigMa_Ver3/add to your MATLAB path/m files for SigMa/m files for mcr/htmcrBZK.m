function model = htmcrBZK(data,wave,plots,ncomp,nonneg,closure,iter,endpoint)

% model = htmcr(sample,wave,plots,ncomp,nonneg,closure,iter,endpoint,mask)
%
% This function perform Multivariate Curve Resolution (MCR)
%
% INPUT:
%   sample --> samples x ppm
%   wave --> ppm vector (1 x wave). If empty, type []
%   plots --> final plots
%       1 for final plots
%       0 if you don�t want plots
%       NOTE: Only the first 10 components will be plotted if comp > 10
%   ncomp --> three options
%       - ncomp (1x1): number of components. Random spectra will be chosen.
%       - X(ncomp,wavelengths): A matrix containing initial estimations for the spectra (spectra x
%       wavelength)
%       - X(ncomp,noise): A call for simplisma model using its findings as
%       initial estimations.
%   nonneg --> [concentration spectra]. Two columns vector for nonnegativity:
%       1 for imposing nonnegativity
%       0 for not imposing nonnegativity
%   closure --> Integer imposing closure in the concentration profiles.
%       When nonnegativity is imposed!
%       New concentration = conc(1)*closure/sum(all(concentrations))
%   iter --> Maximum of iterations (100 recomended)
%   endpoint --> Converge criteria. (0.001 recomended) 
%       abs(residual(iter - previousiter)) < endpoint
%   mask --> OPTIONAL. Logical matrix created by htmaskin* functions
%
% OUTPUT: MCR model structure containing
%   concentration --> Concentration profiles
%   spectra --> Spectral profiles
%   ssq --> Sum of residuals
%   var --> Explained variance
%   cumvar --> Cummulative explained variance
%   concentrationmatrices --> cell array structure containing the
%       concentration surfaces for each component
%   diff --> Difference between iterations 
%   sumerror --> Sum of the error with iterations
%
% This is a freeware function.
% For questions, doubts, problems or suggestion, please contact:
%    Jos� Manuel Amigo
%    e-mail: jmar@life.ku.dk
%    website: http://www.models.life.ku.dk
%
% Copyrigth Jos� Manuel Amigo (University of Copenhagen)
% If you use this function, please refer it in your papers.
%
% This is a freeware function. If you use it, just cite the following papers:
%   Pre-processing of hyperspectral images. Essential steps before image analysis. Chemolab. DOI: j.chemolab.2012.01.011
%   Practical Issues of Hyperspectral Imaging Analysis of Solid Dosage Forms. Analytical and Bioanalytical Chemistry. 398:1 (2010) 93-109

if isempty(wave)
    wave = (1:size(data,2));
else
end

% Applying MCR

[Cnew,Snew,diff,error,lof,expvar] = htals(data,ncomp,nonneg,closure,iter,endpoint);

if size(ncomp,1) == 1 && size(ncomp,2) == 1
    N = ncomp;
elseif size(ncomp,1) == 1 && size(ncomp,2) > 1
    N = size(ncomp,1);
elseif size(ncomp,1) ~= 1
    N = size(ncomp,1);
end


for i = 1:N
    xcalc = Cnew(:,i)*Snew(i,:);
    ssq(i) = 100 - (sum(sum(xcalc.*xcalc)) - sum(sum(data.*data)))*100/sum(sum(data.*data));
    var(i) = 100*((sum(sum(xcalc.*xcalc))/sum(sum(data.*data))));
    sig(i) = sum(sum(xcalc.^2));
    resW{i} = data-xcalc;
    ModeledSpectras{i} = xcalc; 
end

for i = 1:N
    var_normalized(i) = var(i)*100/sum(var);
end

% EXP VAR BY BEKZOD
xcalc2 = Cnew(:,:)*Snew(:,:);
org_exp_var= 100*((sum(sum(xcalc2.*xcalc2))/sum(sum(data.*data))));
sig = normaliz(sig,[],1);  %normalize to 100%
res2=data-xcalc2;
uncap = sum(sum(res2.^2))./sum(sum(data.^2));
if uncap>=1
    uncap = 0;
end

model.exp_var_bkh = [[1:N]' sig'*100 (1-uncap)*sig'*100 cumsum((1-uncap)*sig')*100];
model.exp_var_bkh_detail={'#PCs' 'Total Variation' 'Explained Var.' 'Explained Var. Cummulative'};

  %%%%%%%%%%%%%%%%%%%%%%
  

% cumvar = cumsum(var);

model.type = 'mcr';
model.concentration = Cnew;
model.spectra = Snew;
model.ssq =  ssq;
model.var=var;
model.var_normalized = var_normalized;
model.org_exp_var=org_exp_var;
% model.cumvar = cumvar;
model.diff = diff;
model.error = error;
model.lackoffit = lof;
model.totalvar = expvar;
model.wave = wave;
model.ncomp = N;
model.nonneg = nonneg;
model.closure = closure;
% model.mask = mask;
model.modeled_spectra = ModeledSpectras;
model.res = res2;

if plots == 1
    
    % Concentration surfaces and pure spectra
%     figure;
    if N <= 10
        for i = 1:N
            subplot(2,1,1,'Parent',handles.tab_MCR.Children(3));
            htplotimage(model.concentrationmatrices{i});
            title( ['C =' num2str(i) ' var(%) ' num2str(model.var(i))]);
            subplot(2,1,2,'Parent',handles.tab_MCR.Children(3));
            plot(wave,model.spectra(i,:));
            title(['Spectrum for C = ' num2str(i)]);
            axis('tight');
            xlabel('wavelengths');
            grid;
        end
    elseif N > 10
        for i = 1:10
            subplot(2,5,i,'Parent',handles.tab_MCR.Children(3));
            htplotimage(model.concentrationmatrices{i});
            title( ['C = ' num2str(i) ' var(%) ' num2str(model.var(i))]);
            plot(wave,model.spectra(i,:));
            title(['Spectrum for C = ' num2str(i)]);
            axis('tight');
            xlabel('wavelengths');
            grid;
        end
    end
    
    % Statistical parameters
%     figure;
    subplot(1,1,1,'Parent',handles.tab_MCR.Children(1));
    plot(wave,model.spectra(1,:));
    title('Spectral profiles');
    axis('tight'); grid
    xlabel('wavelengths');
    
    subplot(1,2,1,'Parent',handles.tab_MCR.Children(2));
    bar(model.var);
    title(['Individual exp. variance %']);
    xlabel('N. of component');
    
    subplot(1,2,2,'Parent',handles.tab_MCR.Children(2));
    plot(model.diff(2:end),'linewidth',2);
    grid; axis('tight');
    title({['Lack of fit = ' num2str(model.lackoffit)];['Exp var = ' num2str(model.totalvar)]});
    xlabel('Iterations');
    
elseif plots == 0;
end

