

clear; close all; clc;


cd 'C:\Users\pvw793\Desktop\examle nmr data for sigma'
load('nmrdata.mat');
data=nmrdata.data;
ppm=nmrdata.ppm_mean;
data=data(:,45450:45700);
ppm=ppm(45450:45700);
x=ppm;

cd 'C:\Users\pvw793\Desktop\BekzonianMCR\BekzonianMCR'


% x = 1:100;
% x2 = 1:200;
% 
% y1 = gaussmf(x,[5 15]);
% y2 = gaussmf(x,[7 40])*2;
% y3 = gaussmf(x,[5 65]);
% 
% Y = y1 + y2 + y3;
% 
% dd = [0.1 0.2 0.3 0.5 0.01 0.05];
% 
% for i = 1:500    
%     a = randperm(length(dd));
%     c2 = rand(1,100)*a(1)*0.05;
%     data(i,:) = Y + c2;
% end 
%  
% vector = 1:0.01:5.99;
% vector=vector';
% vector=repmat(vector,1,size(data,2));
% data = data + vector;
% figure;
% plot(data(:,:)');

 
%
clc;
col={'r' 'b' 'g' 'c' 'm'}; col=repmat(col,1,100);


for i = 1:100
% model = htmcr(data(:,:),[],0,[data(1,:);data(end,:)],[1 1],0,500,0.001);
 model = htmcr(data(:,:),[],0,mean(data,1),[1 1],0,500,0.001);
% model = htmcr(data(:,:),[],0,1,[1 1],0,500,0.001);

subplot(4,3,1); plot(model.concentration,col{i});title('Jose');axis tight;
subplot(4,3,4); plot(x,model.spectra,col{i});axis tight;
e = data - model.concentration*model.spectra;
subplot(4,3,7); plot(x,model.concentration*model.spectra); axis tight;
subplot(4,3,10); plot(x,e,'r'); hold on;axis tight;
plot(x,model.concentration*model.spectra,'k');
title(i);
drawnow;

clear model e 
 mcr_model   = als_barc(data);
 model=mcr_model;
subplot(4,3,2); plot(model.scores,col{i}); title('Barcelone');axis tight;
subplot(4,3,5); plot(x,model.loadings,col{i});axis tight;
e = data - model.scores*model.loadings;
subplot(4,3,8); plot(x,model.scores*model.loadings);axis tight;
subplot(4,3,11); plot(x,e,'r'); hold on; plot(x,model.scores*model.loadings,'k');
title(i);axis tight;
drawnow;

clear mcr_model model e 
mcr_options = mcr('options');   
mcr_options.display='off';
mcr_options.plots='none';
mcr_options.waitbar='off'; 
mcr_options.preprocessing={ [] }; 
% initopt = [mean(x1,1);(zeros(1,size(x1,2))+rand(1,size(x1,2))-rand(1,size(x1,2))*0.05*mean(x1(:)))+mean(x1(:))];
initopt = 1;  % always One component model
mcr_model   = mcr(data,initopt,mcr_options);
model=mcr_model;
subplot(4,3,3); plot(model.loads{1,1},col{i}); title('PLStoolbox');axis tight;
subplot(4,3,6); plot(x,model.loads{2,1},col{i});axis tight;
e = data - model.loads{1,1}*model.loads{2,1}';
subplot(4,3,9); plot(x,model.loads{1,1}*model.loads{2,1}');axis tight;
subplot(4,3,12); plot(x,e,'r'); hold on; plot(x,model.loads{1,1}*model.loads{2,1}','k');
title(i);axis tight;
drawnow;

end
% 
% subplot(3,2,4); plot(mean([c1;c2]),mean(model.concentration(:,:),2)','o');
% a = corrcoef(mean(C,2),mean(model.concentration(:,:),2)');
% title(num2str(a(1,2)));

 
 
 
 

