%% sigma_manual_run_bkh 
%
%
% This script contains steps performed in SigMa  software.
% Each step (separated by %%) corresponds to one Tab in SigMa (e.g. Import data; Referense Alignment etc.
% User should ensure their options (handles.sigma_plasma_options) is correct, so if your samples are human blood plasma call for sigma_plasma_options1, ...
% if faecal call for handles.sigma_plasma_options=sigma_faecal_options1;)
% You can also manually change handles.sigma_plasma_options
%
%
% 08.06.2022
% 
% Bekzod Khakimov
% Associate Professor
% Department of Food Science
% University of Copenhagen
% Rolighedsvej 26 
% Frederiksberg C 1958, Denmark
% Office: +45 3532-8184
% Mobile: +45 2887-4454
% Email: bzo@food.ku.dk
% 
%



%% Import Data
clear
close all
clc
directory= 'C:\Users\pvw793\Dropbox\PC\Desktop\New folder (2)'; %replace with your directory where you ...
% saved your Bruker data files (which contains 1r, processed 1D 1H spectra);
pulse='noesy'; % if your spectra is recorded with PULSEPROG other than noesy, please chage, it does not have to be the exact name of PULSEPROG 
bruker_to_sigma_bkh(directory,pulse);
cd(directory);
load('nmrdata.mat');

% Get sigma_options and spectra under handles
handles.sigma_plasma_options=sigma_plasma_options1;% Note, you can change "handles.sigma_plasma_options" as you wish
handles.data=nmrdata;

% Checks 
% Run "sigma_CheckSize_bkh"
[handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
% RUN "sigma_Check_Intervals_bkh"
[handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);


%% Reference Alignment

[handles.data.data, handles.data.ppm_mean] = sigma_ref_align_bkh(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options);

%Pre-Alignment

[handles.data.data, ~] = sigma_pre_align_bkh(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options);


%% Interval Recognition

handles = sigma_ss_mapping_bkh(handles); 


%% Iterative ALignment


[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3...
    (handles.out_ss_map,handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options, handles);


%% Quantification

handles.all_intervals_parameters = sigma_quantification_bkh(handles.x_iterative_align,handles.sigma_plasma_options);


%% Generate Metabolite Table

handles.Generate_Report_outputs = sigma_generate_report(handles.all_intervals_parameters,handles.data.subjects,handles.data.ppm_mean,...
    0,0,handles.sigma_plasma_options,{[]});
folder_name = uigetdir;
handles.folder_name=folder_name;
SigMa_result=handles.Generate_Report_outputs;
save([folder_name '\SigMa_result.mat'],'SigMa_result');
sigma_import_excel(handles);
options = handles.sigma_plasma_options;
save([folder_name '\sigma_options.mat'],'options');




