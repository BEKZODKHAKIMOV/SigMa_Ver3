function [data1,sample_AcqPars,sample_ProcPars] =import_processed_bruker_nmr_data_bkh(dname)
%
% "import_processed_bruker_nmr_data_bkh"
% This function Imports Processed ONLY Bruker NMD data
%
% Please locate a directory where raw Bruker NMR data is
%
% OUTPUTS:
% data = data structure which contains raw NMR data, ppm scales for each sample and mean_ppm scale
% sample_AcqPars = NMR data Acqusition Parameters which also contains Sample Label
% sample_ProcPars = NMR data processing parameter.
%
% 11 Aug 2018
%
% Bekzod Khakimov
% Associate Professor
%
% University of Copenhagen
% Department of Food Science
% Chemometrics and Analytical Technology
% Rolighedsvej 26, Frederiksberg, 1958, Denmark
%
% DIR +45 3532-8184
% MOB +45 2887-4454
% bzo@food.ku.dk
% www.models.life.ku.dk

% Import Bruker's processed Data (1r or 1rr)
%dname = uigetdir('C:\');
cd(dname);
A = rbnmr_bkh;

% Find where data exist
for i=1:length(A);
    d1(i)=isfield(A{i},'Data');
end;
A(d1==0,:)=[];


A = rbnmr_check_bkh(A);

 
counter1=0;
counter2=0;

for ii=1:length(A);
    if isfield(A{ii},'XAxis');
        counter1=counter1+1;
        xaxis_exist(counter1)=ii;
    else
        counter2=counter2+1;
        xaxis_doesnot_exist(counter2)=ii;
    end
    %    sz(ii)=size(A{ii}.Data,1);
end;

if counter2~=0; 
     for k=1:counter2;
        n1=find(A{xaxis_doesnot_exist(k)}.Title=='/');
        m1=A{xaxis_doesnot_exist(k)}.Title;
        missing=m1(1,n1(end)+1:end);
        missing_n{k}=missing;
    end;
      msgbox(cat(2,{[num2str(counter2) ' of files do not contain data including ...']},missing_n));
    A=A(xaxis_exist);
end;

for ii=1:length(A);
    sz(ii)=size(A{ii}.Data,1);
end;


if length(unique(sz))==1;
    for i=1:length(A);
        data(i,:)=A{i}.Data';
        ppm(i,:)=A{i}.XAxis';
        
        data1.subjects{i,1}=A{i}.Info.Title;
        sample_AcqPars.sample_AcqPars_Title{i,1}=A{i}.Info.Title;
        sample_AcqPars.sample_AcqPars_AcqDateTime{i,1}=A{i}.Info.AcqDateTime;
        sample_AcqPars.sample_AcqPars_AcqSerialDate{i,1}=A{i}.Info.AcqSerialDate;
        sample_AcqPars.sample_AcqPars_Info{i,1}=A{i}.Info;
        sample_AcqPars.sample_AcqPars_FilePath{i,1}=A{i}.Info.FilePath;
        sample_AcqPars.sample_AcqPars_PlotLabel{i,1}=A{i}.Info.PlotLabel;
        sample_AcqPars.sample_AcqPars_AUNM{i,1}=A{i}.Acqus.AUNM;
        sample_AcqPars.sample_AcqPars_EXP{i,1}=A{i}.Acqus.EXP;
        sample_AcqPars.sample_AcqPars_PYNM{i,1}=A{i}.Acqus.PYNM;
        sample_AcqPars.sample_AcqPars_PULPROG{i,1}=A{i}.Acqus.PULPROG;
        sample_AcqPars.sample_AcqPars_SW_inPPM{i,1}=A{i}.Acqus.SW;
        sample_AcqPars.sample_AcqPars_SW_inHz{i,1}=A{i}.Acqus.SW_h;
        sample_AcqPars.sample_AcqPars_NS{i,1}= A{i}.Acqus.NS;
        sample_AcqPars.sample_AcqPars_RG{i,1}= A{i}.Acqus.RG;
        sample_AcqPars.sample_AcqPars_BF1_MHz{i,1}=A{i}.Acqus.BF1;
        sample_AcqPars.sample_AcqPars_LOCK_SOLVENT{i,1}= A{i}.Acqus.SOLVENT;
        sample_AcqPars.sample_AcqPars_TD_Size_of_FID{i,1}=A{i}.Acqus.TD;
        sample_AcqPars.sample_AcqPars_TE_RequestedProbeTemp{i,1}=A{i}.Acqus.TE;
        sample_AcqPars.sample_AcqPars_O1_TransmitterFreqOff_WaterSupp_ppm{i,1}=A{i}.Acqus.O1/A{i}.Acqus.SFO1;
        sample_AcqPars.sample_AcqPars_LOCKPPM{i,1}= A{i}.Acqus.LOCKPPM;
        sample_AcqPars.sample_AcqPars_MASR_RotationRate{i,1}=A{i}.Acqus.MASR;
        sample_AcqPars.sample_AcqPars_NUC1_AcqNuc{i,1}=A{i}.Acqus.NUC1;
        
        sample_ProcPars.sample_ProcPars_AUNMP_ProcessingPar{i,1}=A{i}.Procs.AUNMP;
        sample_ProcPars.sample_ProcPars_PYNMP{i,1}=A{i}.Procs.PYNMP;
        sample_ProcPars.sample_ProcPars_LB{i,1}=A{i}.Procs.LB;
        sample_ProcPars.sample_ProcPars_FTSIZE_Size_ofRealSpectrum{i,1}=A{i}.Procs.FTSIZE;
        sample_ProcPars.sample_ProcPars_SF_Spectrometer_Freq_inMHz{i,1}=A{i}.Procs.SF;
        sample_ProcPars.sample_ProcPars_SI_Size_of_Real_Spectrum{i,1}=A{i}.Procs.SI;
        sample_ProcPars.sample_ProcPars_SPECTYP{i,1}=A{i}.Procs.SPECTYP;
        sample_ProcPars.sample_ProcPars_F1P{i,1}=A{i}.Procs.F1P;
        sample_ProcPars.sample_ProcPars_F2P{i,1}=A{i}.Procs.F2P;
        sample_ProcPars.sample_ProcPars_FCOR{i,1}=A{i}.Procs.FCOR;
        sample_ProcPars.sample_ProcPars_FT_mod{i,1}=A{i}.Procs.FT_mod;
        sample_ProcPars.sample_ProcPars_OFFSET_LowFieldLimit_ofSpectrum{i,1}=A{i}.Procs.OFFSET;
        sample_ProcPars.sample_ProcPars_Phasing_PHC0{i,1}=A{i}.Procs.PHC0;
        sample_ProcPars.sample_ProcPars_Phasing_PHC1{i,1}=A{i}.Procs.PHC1;
        sample_ProcPars.sample_ProcPars_Phasing_PH_mod{i,1}=A{i}.Procs.PH_mod;
        sample_ProcPars.sample_ProcPars_Phasing_PKNL{i,1}=A{i}.Procs.PKNL;
        sample_ProcPars.sample_ProcPars_SREGLST{i,1}=A{i}.Procs.SREGLST;
        sample_ProcPars.sample_ProcPars_SW_p_SpectralWidth_inHZ{i,1}=A{i}.Procs.SW_p;
        sample_ProcPars.sample_ProcPars_TDeff_Siz_of_FID{i,1}=A{i}.Procs.TDeff;
        
    end;
    
    
    data1.data=data;
    data1.ppm=ppm;
    data1.ppm_mean=nanmean(ppm);
    
else
    for ii=1:length(A);
        max_ppm1(ii,1)=max(A{ii}.XAxis);
        min_ppm1(ii,1)=min(A{ii}.XAxis);
    end;
    % largest diff
    mx1=min(max_ppm1);%
    mx2=max(max_ppm1);%
    mn1=min(min_ppm1);%
    mn2=max(min_ppm1);%
    max_ppm1=min(max_ppm1);%
    min_ppm1=max(min_ppm1);%
    % Aks if user want to reduce the size of the data due to the inconsitant SW used for acquiring data
    text1=['SW [ppm] is not consistant,  high field chemical shift range from ' num2str(mn1) ' to ' num2str(mn2) ' ppm & down field chemical shift range from ' num2str(mx1) ' to ' num2str(mx2) ' ppm! ' ];
    reply = inputdlg([text1 ' If you want to reduce SW & make equal SW for all samples type 1 otherwise type 0 and press OK' ]);
    if str2num(cell2mat(reply))~=1;
        warndlg('No data imported due to inconsistant SW [ppm] of NMR data');
        return
    else
        % find out ppm range of the smallest SW sample
        for i=1:length(A);
            a1=abs(A{i}.XAxis-max_ppm1); p1b=find(a1==min(a1));
            if length(p1b)>1;
                p1b=p1b(1,1);
            end;
            a1=abs(A{i}.XAxis-min_ppm1); p2b=find(a1==min(a1));
            if length(p2b)>1;
                p2b=p2b(1,1);
            end;
            ppm3(i)=size(A{i}.XAxis(p1b:p2b,:),1);
        end;
        % extract equal size data
        min_size=min(ppm3);
        for i=1:length(A);
            a1=abs(A{i}.XAxis-max_ppm1); p1b=find(a1==min(a1));
            if length(p1b)>1;
                p1b=p1b(1,1);
            end;
            a1=abs(A{i}.XAxis-min_ppm1); p2b=find(a1==min(a1));
            if length(p2b)>1;
                p2b=p2b(1,1);
            end;
            ppm1=A{i}.XAxis(p1b:p2b,:)';
            ppm(i,:)=ppm1(:,1:min_size);
            data1=A{i}.Data(p1b:p2b,:)';
            data(i,:)=data1(:,1:min_size);
            
            data1.subjects{i,1}=A{i}.Info.Title;
            sample_AcqPars.sample_AcqPars_Title{i,1}=A{i}.Info.Title;
            sample_AcqPars.sample_AcqPars_AcqDateTime{i,1}=A{i}.Info.AcqDateTime;
            sample_AcqPars.sample_AcqPars_AcqSerialDate{i,1}=A{i}.Info.AcqSerialDate;
            sample_AcqPars.sample_AcqPars_Info{i,1}=A{i}.Info;
            sample_AcqPars.sample_AcqPars_FilePath{i,1}=A{i}.Info.FilePath;
            sample_AcqPars.sample_AcqPars_PlotLabel{i,1}=A{i}.Info.PlotLabel;
            sample_AcqPars.sample_AcqPars_AUNM{i,1}=A{i}.Acqus.AUNM;
            sample_AcqPars.sample_AcqPars_EXP{i,1}=A{i}.Acqus.EXP;
            sample_AcqPars.sample_AcqPars_PYNM{i,1}=A{i}.Acqus.PYNM;
            sample_AcqPars.sample_AcqPars_PULPROG{i,1}=A{i}.Acqus.PULPROG;
            sample_AcqPars.sample_AcqPars_SW_inPPM{i,1}=A{i}.Acqus.SW;
            sample_AcqPars.sample_AcqPars_SW_inHz{i,1}=A{i}.Acqus.SW_h;
            sample_AcqPars.sample_AcqPars_NS{i,1}= A{i}.Acqus.NS;
            sample_AcqPars.sample_AcqPars_RG{i,1}= A{i}.Acqus.RG;
            sample_AcqPars.sample_AcqPars_BF1_MHz{i,1}=A{i}.Acqus.BF1;
            sample_AcqPars.sample_AcqPars_LOCK_SOLVENT{i,1}= A{i}.Acqus.SOLVENT;
            sample_AcqPars.sample_AcqPars_TD_Size_of_FID{i,1}=A{i}.Acqus.TD;
            sample_AcqPars.sample_AcqPars_TE_RequestedProbeTemp{i,1}=A{i}.Acqus.TE;
            sample_AcqPars.sample_AcqPars_O1_TransmitterFreqOff_WaterSupp_ppm{i,1}=A{i}.Acqus.O1/A{i}.Acqus.SFO1;
            sample_AcqPars.sample_AcqPars_LOCKPPM{i,1}= A{i}.Acqus.LOCKPPM;
            sample_AcqPars.sample_AcqPars_MASR_RotationRate{i,1}=A{i}.Acqus.MASR;
            sample_AcqPars.sample_AcqPars_NUC1_AcqNuc{i,1}=A{i}.Acqus.NUC1;
            
            sample_ProcPars.sample_ProcPars_AUNMP_ProcessingPar{i,1}=A{i}.Procs.AUNMP;
            sample_ProcPars.sample_ProcPars_PYNMP{i,1}=A{i}.Procs.PYNMP;
            sample_ProcPars.sample_ProcPars_LB{i,1}=A{i}.Procs.LB;
            sample_ProcPars.sample_ProcPars_FTSIZE_Size_ofRealSpectrum{i,1}=A{i}.Procs.FTSIZE;
            sample_ProcPars.sample_ProcPars_SF_Spectrometer_Freq_inMHz{i,1}=A{i}.Procs.SF;
            sample_ProcPars.sample_ProcPars_SI_Size_of_Real_Spectrum{i,1}=A{i}.Procs.SI;
            sample_ProcPars.sample_ProcPars_SPECTYP{i,1}=A{i}.Procs.SPECTYP;
            sample_ProcPars.sample_ProcPars_F1P{i,1}=A{i}.Procs.F1P;
            sample_ProcPars.sample_ProcPars_F2P{i,1}=A{i}.Procs.F2P;
            sample_ProcPars.sample_ProcPars_FCOR{i,1}=A{i}.Procs.FCOR;
            sample_ProcPars.sample_ProcPars_FT_mod{i,1}=A{i}.Procs.FT_mod;
            sample_ProcPars.sample_ProcPars_OFFSET_LowFieldLimit_ofSpectrum{i,1}=A{i}.Procs.OFFSET;
            sample_ProcPars.sample_ProcPars_Phasing_PHC0{i,1}=A{i}.Procs.PHC0;
            sample_ProcPars.sample_ProcPars_Phasing_PHC1{i,1}=A{i}.Procs.PHC1;
            sample_ProcPars.sample_ProcPars_Phasing_PH_mod{i,1}=A{i}.Procs.PH_mod;
            sample_ProcPars.sample_ProcPars_Phasing_PKNL{i,1}=A{i}.Procs.PKNL;
            sample_ProcPars.sample_ProcPars_SREGLST{i,1}=A{i}.Procs.SREGLST;
            sample_ProcPars.sample_ProcPars_SW_p_SpectralWidth_inHZ{i,1}=A{i}.Procs.SW_p;
            sample_ProcPars.sample_ProcPars_TDeff_Siz_of_FID{i,1}=A{i}.Procs.TDeff;
            
            
        end;
        
        data1.data=data;
        data1.ppm=ppm;
        data1.ppm_mean=nanmean(ppm);
        
        figure, plot(data.ppm_mean,data.data); invertx;
        warndlg('Here we Gooo...! SW [ppm] of NMR data was reduced to make consistant SW for all samples!');
        
        
    end;
end;




