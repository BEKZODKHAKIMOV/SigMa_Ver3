function [ A ] = rbnmr_check_bkh(A)
% 
% "[ A ] = rbnmr_check_bkh(A)" 
% A = rbnmr_bkh; % output_of_rbnmr_bkh
% 
%

try
    
if isempty(A)
    f2 = errordlg('No NMR found - SigMa will exit now!');
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Check Numerical Acquisition papametrs 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% CHECK SIZES
for i=1:length(A)
    if isfield(A{i},'Data')
        size1{i,1}=size(A{i}.Data);
        size2(i,1)=length(A{i}.Data(:));
    else
        size1{i,1}=0;
        size2(i,1)=0;
    end;
end;

if sum(size2)==0
    f2 = errordlg('No NMR found - SigMa will exit now!');
elseif ~isempty(find(size2==0))
    A(find(size2==0),:)=[];
end;


[u1 pos_u1]=unique(size2);
u2=length(u1);
if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(size2==u1(lol1)));
        u4=size1(pos_u1(lol1));
        u4=u4{1};
        u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) '-by-' num2str(u4(2)) ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data has '];
    text2=[ num2str(u2) ' kinds of size ' u3 '. Please type correcponding (#) of set to select a data type or type "0" to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    else
        u5=str2num(cell2mat(reply));
        u6=u1(u5);
        A(size2~=u6,:)=[];
    end;
end;
clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u5 h1 text1 text2 reply f2


% CHECK BF1 (MHz magnet) - Acquisition  Magnet
for i=1:length(A)
    if isfield(A{i}.Acqus,'BF1')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
    for i=1:length(A)
        size1{i,1}=A{i}.Acqus.BF1;
        size2(i,1)=A{i}.Acqus.BF1;
    end;
    
    [u1 pos_u1]=unique(size2);
    u2=length(u1);
    if u2>1
        u3=[];
        for lol1=1:u2
            h1=length(find(size2==u1(lol1)));
            u4=size1(pos_u1(lol1));
            u4=u4{1};
            u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) ' MHz, ' num2str(h1) ' samples)'] ];
        end;
        text1=['Your data is recorded using '];
        text2=[ num2str(u2) ' kinds of Instruments ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
        reply = inputdlg([text1,text2]);
        if str2num(cell2mat(reply))==0
            f2 = errordlg('No data was imported - SigMa will exit now!');
        elseif str2num(cell2mat(reply))==-1
            A=A;
        else
            u5=str2num(cell2mat(reply));
            u6=u1(u5);
            A(find(size2~=u6),:)=[];
        end;
    end;
    clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u6 h1 text1 text2 reply f2
end;


    
% CHECK RG - Acquisition  Receiver Gain
for i=1:length(A)
    if isfield(A{i}.Acqus,'RG')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
    for i=1:length(A)
        size1{i,1}=A{i}.Acqus.RG;
        size2(i,1)=A{i}.Acqus.RG;
    end;
    
    [u1 pos_u1]=unique(size2);
    u2=length(u1);
    if u2>1
        u3=[];
        for lol1=1:u2
            h1=length(find(size2==u1(lol1)));
            u4=size1(pos_u1(lol1));
            u4=u4{1};
            u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) ', ' num2str(h1) ' samples)'] ];
        end;
        
        text1=['Your data is recorded using '];
        text2=[ num2str(u2) ' kinds of Receiver Gain ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
        reply = inputdlg([text1,text2]);
        if str2num(cell2mat(reply))==0
            f2 = errordlg('No data was imported - SigMa will exit now!');
        elseif str2num(cell2mat(reply))==-1
            A=A;
        else
            u5=str2num(cell2mat(reply));
            u6=u1(u5);
            A(find(size2~=u6),:)=[];
        end;
    end;
    clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u6 h1 text1 text2 reply f2
end;
        
 
% CHECK NS - Acquisition # of scans
for i=1:length(A)
    if isfield(A{i}.Acqus,'NS')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
    for i=1:length(A)
        size1{i,1}=A{i}.Acqus.NS;
        size2(i,1)=A{i}.Acqus.NS;
    end;
    
    [u1 pos_u1]=unique(size2);
    u2=length(u1);
    if u2>1
        u3=[];
        u3=[];
        u3=[];
        for lol1=1:u2
            h1=length(find(size2==u1(lol1)));
            u4=size1(pos_u1(lol1));
            u4=u4{1};
            u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) ', ' num2str(h1) ' samples)'] ];
        end;
        
        text1=['Your data is recorded using '];
        text2=[ num2str(u2) ' kinds of Number of Scans ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
        reply = inputdlg([text1,text2]);
        if str2num(cell2mat(reply))==0
            f2 = errordlg('No data was imported - SigMa will exit now!');
        elseif str2num(cell2mat(reply))==-1
            A=A;
        else
            u5=str2num(cell2mat(reply));
            u6=u1(u5);
            A(find(size2~=u6),:)=[];
        end;
    end;
    clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u6 h1 text1 text2 reply f2
end;
      
        
% CHECK AQ (sec) - Acquisition Time
for i=1:length(A)
    if isfield(A{i}.Acqus,'AQSEQ')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    size1{i,1}=A{i}.Acqus.AQSEQ;
    size2(i,1)=A{i}.Acqus.AQSEQ;
end;

[u1 pos_u1]=unique(size2);
u2=length(u1);
if u2>1
    u3=[];
    u3=[];
    for lol1=1:u2
        h1=length(find(size2==u1(lol1)));
        u4=size1(pos_u1(lol1));
        u4=u4{1};
        u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of Acquisition Time (sec) ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(u5);
        A(find(size2~=u6),:)=[];
    end;
end;
clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u6 h1 text1 text2 reply f2
end;


% CHECK TD - Size of FID
for i=1:length(A)
    if isfield(A{i}.Acqus,'TD')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    size1{i,1}=A{i}.Acqus.TD;
    size2(i,1)=A{i}.Acqus.TD;
end;

[u1 pos_u1]=unique(size2);
u2=length(u1);
if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(size2==u1(lol1)));
        u4=size1(pos_u1(lol1));
        u4=u4{1};
        u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of FID size ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(u5);
        A(find(size2~=u6),:)=[];
    end;
end;
clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u6 h1 text1 text2 reply f2
end;


% CHECK SW (ppm) - Acquisition Spectral Width
for i=1:length(A)
    if isfield(A{i}.Acqus,'SW')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    size1{i,1}=A{i}.Acqus.SW;
    size2(i,1)=A{i}.Acqus.SW;
end;

[u1 pos_u1]=unique(size2);
u2=length(u1);
if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(size2==u1(lol1)));
        u4=size1(pos_u1(lol1));
        u4=u4{1};
        u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of Acquisition Spectral Width (ppm) ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(u5);
        A(find(size2~=u6),:)=[];
    end;
end;
clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u6 h1 text1 text2 reply f2
end;


% CHECK D1 (sec) - Acquisition Delay Duration
for i=1:length(A)
    if isfield(A{i}.Acqus,'D')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    size1{i,1}=A{i}.Acqus.D(2);
    size2(i,1)=A{i}.Acqus.D(2);
end;

[u1 pos_u1]=unique(size2);
u2=length(u1);
if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(size2==u1(lol1)));
        u4=size1(pos_u1(lol1));
        u4=u4{1};
        u3=[u3,[' set-' num2str(lol1) ': (' num2str(u4(1)) ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of Acquisition Delay Duration (sec) ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(u5);
        A(find(size2~=u6),:)=[];
    end;
end;
clear size1 size2 u1 pos_u1 u2 u3 u4 u5 u6 h1 text1 text2 reply f2
end;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check Text Acqusition Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% CHECK PULPROG - Acquisition Pulse Prog.
for i=1:length(A)
    if isfield(A{i}.Acqus,'PULPROG')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    a1=A{i}.Acqus.PULPROG;
    a1(regexp(a1,'[<,>]'))=[];
    a2{i,1}=a1;
end;

[u1 pos_u1]=unique(a2);
u2=length(u1);
[s1 s2]=sort(pos_u1);
s3=u1(s2);

if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(strcmp(a2,s3{lol1})==1));
        u3=[u3,' set-' [num2str(lol1) ': (' u1{pos_u1(lol1)} ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of PULPROG  ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(pos_u1(u5));
        u7=find(strcmp(a2,u6)==0)
        A(u7,:)=[];
    end;
end;
clear a1 a2 s1 s2 s3 u1 pos_u1 u2 u3 u4 u5 u6 u7 h1 text1 text2 reply f2
end;



% CHECK SOLVENT - Acquisition SOLVENT
for i=1:length(A)
    if isfield(A{i}.Acqus,'SOLVENT')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    a1=A{i}.Acqus.SOLVENT;
    a1(regexp(a1,'[<,>]'))=[];
    a2{i,1}=a1;
end;

[u1 pos_u1]=unique(a2);
u2=length(u1);
[s1 s2]=sort(pos_u1);
s3=u1(s2);

if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(strcmp(a2,s3{lol1})==1));
        u3=[u3,' set-' [num2str(lol1) ': (' u1{pos_u1(lol1)} ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of SOLVENT  ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(pos_u1(u5));
        u7=find(strcmp(a2,u6)==0)
        A(u7,:)=[];
    end;
end;
clear a1 a2 s1 s2 s3 u1 pos_u1 u2 u3 u4 u5 u6 u7 h1 text1 text2 reply f2
end;



% CHECK AUNM - Acquisition AU program
for i=1:length(A)
    if isfield(A{i}.Acqus,'AUNM')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    a1=A{i}.Acqus.AUNM;
    a1(regexp(a1,'[<,>]'))=[];
    a2{i,1}=a1;
end;

[u1 pos_u1]=unique(a2);
u2=length(u1);
[s1 s2]=sort(pos_u1);
s3=u1(s2);

if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(strcmp(a2,s3{lol1})==1));
        u3=[u3,' set-' [num2str(lol1) ': (' u1{pos_u1(lol1)} ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of Acquisition AU program ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(pos_u1(u5));
        u7=find(strcmp(a2,u6)==0)
        A(u7,:)=[];
    end;
end;
clear a1 a2 s1 s2 s3 u1 pos_u1 u2 u3 u4 u5 u6 u7 h1 text1 text2 reply f2
end;



% CHECK AUNMP - Processing AU Program
for i=1:length(A)
    if isfield(A{i}.Procs,'AUNMP')
        pr1(i,1)=1;
    else
        pr1(i,1)=0;
    end;
end;

if sum(pr1)==length(A)
for i=1:length(A)
    a1=A{i}.Procs.AUNMP;
    a1(regexp(a1,'[<,>]'))=[];
    a2{i,1}=a1;
end;

[u1 pos_u1]=unique(a2);
u2=length(u1);
[s1 s2]=sort(pos_u1);
s3=u1(s2);

if u2>1
    u3=[];
    for lol1=1:u2
        h1=length(find(strcmp(a2,s3{lol1})==1));
        u3=[u3,' set-' [num2str(lol1) ': (' u1{pos_u1(lol1)} ', ' num2str(h1) ' samples)'] ];
    end;
    
    text1=['Your data is recorded using '];
    text2=[ num2str(u2) ' kinds of Processing AU program ' u3 '. Please type correcponding number (#) to select a data type, or type -1 to take all,  or type 0 to exit SigMa'];
    reply = inputdlg([text1,text2]);
    if str2num(cell2mat(reply))==0
        f2 = errordlg('No data was imported - SigMa will exit now!');
    elseif str2num(cell2mat(reply))==-1
        A=A;
    else
        u5=str2num(cell2mat(reply));
        u6=u1(pos_u1(u5));
        u7=find(strcmp(a2,u6)==0)
        A(u7,:)=[];
    end;
end;
clear a1 a2 s1 s2 s3 u1 pos_u1 u2 u3 u4 u5 u6 u7 h1 text1 text2 reply f2
end;



% CHECK WDW - Processing Window Function for trf
% CHECK LB - Processing Line Broadening for EM
% CHECK FCOR - Processing Weighting Factor for first fid point
% CHECK ABSG - Processing Degree of polynomial
% CHECK BC_mod - Processing Fid baseline mode
% CHECK PH_mod - Processing PHASING MODES FOR TRF

catch
    f2 = errordlg('rbnmr_check_bkh funtion error - SigMa will exit now!');
end;

end

