function [data1,sample_AcqPars,sample_ProcPars] =import_processed_matlab_nmr_data_bkh(nmrdata)
%
% "import_processed_matlab_nmr_data_bkh"
% This function Imports Processed ONLY MATLAB NMD data
%
% Please locate a directory where raw MATLAB NMR data is
%
% MATLAB NMR data has to be structure array and it has to be called "nmrdata" 
% where inside at least 2 nmrdata.data & nmrdata.ppm_mean must be there
%
% 11 Aug 2018
%
% Bekzod Khakimov
% Associate Professor
%
% University of Copenhagen
% Department of Food Science
% Chemometrics and Analytical Technology
% Rolighedsvej 26, Frederiksberg, 1958, Denmark
%
% DIR +45 3532-8184
% MOB +45 2887-4454
% bzo@food.ku.dk
% www.models.life.ku.dk

% Locate directory the nmrdata MATLAB file is
% dname = uigetdir;
% cd(dname);
% load('nmrdata')

% Check if there is any data
f1=fieldnames(nmrdata);     
if isempty(f1); error('Error: No MATLAB data was found'); end;

% Get NMR data
if sum(strcmp(f1,'data'))==0; 
    error('Error: No NMR data was found');
else
    data1.data=nmrdata.data;
end;

% Get ppm scale 
if sum(strcmp(f1,'ppm_mean'))==0; 
    error('Error: No NMR ppm scale was found');
else
    data1.ppm_mean=nmrdata.ppm_mean;
end;


% Get ppm scales 
if sum(strcmp(f1,'ppm'))==0; 
   % warning('No spectrum specific ppm scales were found. Mean ppm scale will be used');
    a1=size(nmrdata.data,1);
    ppm=repmat(nmrdata.ppm_mean,a1,1);
else
    data1.ppm=nmrdata.ppm;
end;

% Get subjects
if sum(strcmp(f1,'subjects'))==0 
    %warning('No Sample Acq Pars were found. Samples order will be used as samples names');
    a1=[1:size(nmrdata.data,1)];
    for i=1:size(nmrdata.data,1);
        data1.subjects{i,1}=['sample ' num2str(i)];
    end;
else
    data1.subjects=nmrdata.subjects;
end;


% Get sample_AcqPars
if sum(strcmp(f1,'sample_AcqPars'))==0 
    %warning('No Sample Acq Pars were found. Samples order will be used as samples names');
    a1=[1:size(nmrdata.data,1)];
    for i=1:size(nmrdata.data,1);
        sample_AcqPars.sample_AcqPars_Title{i,1}=['sample ' num2str(i)];
        %data1.subjects{i,1}=['sample ' num2str(i)];
    end;
else
    sample_AcqPars=nmrdata.sample_AcqPars;
    data1.subjects=nmrdata.sample_AcqPars.sample_AcqPars_Title
end;

% Get sample_ProcPars
if sum(strcmp(f1,'sample_ProcPars'))==0; 
   % warning('No Sample Proc Pars were found. Proc pars will be skipped ');
    a1=[1:size(nmrdata.data,1)];
    for i=1:size(nmrdata.data,1);
        sample_ProcPars.sample_ProcPars_FTSIZE_Size_ofRealSpectrum{i,1}=['sample_procs ' num2str(i)];
    end;
else
    sample_ProcPars=nmrdata.sample_ProcPars;
end;





