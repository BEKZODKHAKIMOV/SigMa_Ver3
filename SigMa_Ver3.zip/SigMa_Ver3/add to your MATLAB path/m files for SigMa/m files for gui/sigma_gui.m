function sigma_gui(varargin)

try
    % handles.sample = varargin{1};
    % handles.wavelengths = varargin{2};
    %
    % if isempty(handles.wavelengths)
    %     handles.wavelengths=(1:size(handles.sample,3));
    % end
    %
    % handles.mask = varargin{3};
    
    
    % For Stat of SigMa use
     

      

    % Objects Used to Create Tab Panels
    % =============================================================================================================================
%     dd = cd;
%     loc1 = find(dd=='\');
%     addpath(genpath(dd(1:loc1(end))))
    send_email_sigma
    


    
    handles.f = figure('Visible','off','Position',[140 110 1200 590], 'resize', 'on');
    handles.f.Name = 'SigMa Ver. 1.0';
    movegui(handles.f,'center')
    
       
        
    % warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
    % jframe=get(handles.f,'javaframe');
    % jIcon=javax.swing.ImageIcon('Icon.png');
    % jframe.setFigureIcon(jIcon);
    javaFrame = get(handle(handles.f), 'javaframe');
    where = which('Sigma_Icon.jpg');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(where));
    

    blit=[0 0.30 0.7];
    
    handles.tgroup = uitabgroup('Parent', handles.f);
    handles.tab_Import_Data = uitab('Parent', handles.tgroup, 'Title', 'Import Data','ForegroundColor',blit);
    handles.tab_Reference_alignment = uitab('Parent', handles.tgroup, 'Title', 'Reference Alignment','ForegroundColor',blit);
    handles.tab_Interval_Recognition = uitab('Parent', handles.tgroup, 'Title', 'Interval Recognition','ForegroundColor',blit);
    handles.tab_Interval_Alignment = uitab('Parent', handles.tgroup, 'Title', 'Interval Alignment','ForegroundColor',blit);
    handles.tab_Quantification = uitab('Parent', handles.tgroup, 'Title', 'Quantification','ForegroundColor',blit);
    handles.tab_Generate_Report = uitab('Parent', handles.tgroup, 'Title', 'Generate Metabolite Table','ForegroundColor',blit);
    handles.tab_Lp_Prediction = uitab('Parent', handles.tgroup, 'Title', 'Lipoprotein Prediction','ForegroundColor',blit);
    
    
    set(handles.tgroup,'SelectionChangedFcn',{@tabChangedCB,handles})
    % handles.ColorSet=[0 1 0;0 0 1;0.2737 0.1969 0.0384];
    handles.ColorSet=[0 1 0; 0 0 1; 1 0 0;];
    
    % Change Tabgroup and Tab Properties
    % =============================================================================================================================
    
    handles.tgroup.SelectedTab = handles.tab_Import_Data;
    
    % UIMenu
    % -------------------------------------------------------------------------------------------------------
    % allhandles = findall(FigureHandle);
    % menuhandles = findobj(allhandles,'type','uimenu');
    % edithandle = findobj(menuhandles,'tag','figMenuEdit');
    % delete(edithandle);
    
    allhandles = findall(handles.f);
    menuhandles = findobj(allhandles,'type','uimenu');
    delete(menuhandles);
    
        
    f1 = uimenu('Label','File');
    uimenu(f1,'Label','Import Bruker Data','Callback',@Import_Bruker_Data_File_Callback);
    uimenu(f1,'Label','Import MATLAB Data','Callback',@Import_MATLAB_Data_File_Callback);
    
    
    f2 = uimenu('Label','Edit');
    handles.Decrease_column_dimension_uimenu_Edit = uimenu(f2,'Label','Decrease column dimension','Callback',@Decrease_column_dimension_uimenu_Edit_Callback);
    % set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2,'Checked','on')
    handles.Decrease_column_dimension_uimenu_Edit_val = 0;
    
    
    f3 = uimenu('Label','SigMa Help');
    uimenu(f3,'Label','About SigMa','Callback',@About_SigMa_uimenu_help_Callback);
    uimenu(f3,'Label','Manual','Callback',@Manual_uimenu_help_Callback);
    uimenu(f3,'Label','Reference','Callback',@Reference_uimenu_help_Callback);
    uimenu(f3,'Label','Video tutorial','Callback',@Video_tutorial_uimenu_help_Callback);
    uimenu(f3,'Label','Contact developer','Callback',@Contact_developer_uimenu_help_Callback);
    
    
catch e
    errordlg(e.message)
end



    function Import_Bruker_Data_File_Callback(source,eventdata,handles)
        tab_Import_Data_Import_Bruker_Data_pushbutton_Callback
    end




    function Import_MATLAB_Data_File_Callback(source,eventdata,handles)
        tab_Import_Data_Import_MATLAB_Data_pushbutton_Callback
    end




    function Decrease_column_dimension_uimenu_Edit_Callback(source,eventdata,handles)
        
        handles = getappdata(0,'handles');
        
        try
            
            switch source.Label
                case 'Decrease column dimension'
                    if strcmp(get(gcbo,'Checked'),'on')
                        handles.Decrease_column_dimension_uimenu_Edit_val = 1;
                        set(gcbo,'Checked', 'off');
                        %             set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2, 'Checked', 'on');
                        
                        
                    else
                        handles.Decrease_column_dimension_uimenu_Edit_val = 0;
                        set(gcbo,'Checked', 'on');
                        %                     set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu1, 'Checked', 'on');
                        %                     set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2, 'Checked', 'off');
                        
                        
                        try
                            
                            %                         handles.data.ppm_mean
                            %                         handles.data.data
                            
                            [m,n]=size(handles.data.data);
                            
                            if n<10000
                                loc = 1:n;
                                
                            elseif n>10000
                                loc0 = ceil(n/10000);
                                loc = 1:loc0:n;
                            end
                            
                            handles.data.data = handles.data.data(:,loc);
                            handles.data.ppm_mean = handles.data.ppm_mean(loc);
                            
                            
                            tab_Import_Data_listbox_str = get(handles.tab_Import_Data_listbox,'String');
                            tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
                            
                            tab_Import_Data_plot_type_popupmenu_val = get(handles.tab_Import_Data_plot_type_popupmenu,'Value');
                            
                            subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
                            plot(0,0,'*w')
                            
                            switch tab_Import_Data_plot_type_popupmenu_val
                                case 1
                                    subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
                                    plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val,:)); xlabel('ppm');
                                    set(gca,'xdir','rev');
                                    axis tight
                                    hold off
                                    
                                    
                                    legend_name = {};
                                    for i = 1:length(tab_Import_Data_listbox_val)
                                        legend_name(i) = tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i));
                                    end
                                    legend(legend_name)
                                    
                                case 2
                                    [x , y] = subplot_x_y_size(length(tab_Import_Data_listbox_val));
                                    for i = 1:length(tab_Import_Data_listbox_val)
                                        ax(i) = subplot(x,y,i,'Parent',handles.tab_Import_Data_frame1);
                                        plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                                        set(gca,'xdir','rev');
                                        axis tight
                                        legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                                    end
                                    linkaxes(ax,'xy');
                                    hold off
                                    
                                case 3
                                    
                                    for i = 1:length(tab_Import_Data_listbox_val)
                                        ax(i) = subplot(length(tab_Import_Data_listbox_val),1,i,'Parent',handles.tab_Import_Data_frame1);
                                        plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                                        set(gca,'xdir','rev');
                                        axis tight
                                        legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                                    end
                                    linkaxes(ax,'xy');
                                    hold off
                                    
                            end
                            
                            
                            %msgbox(['Column dimension = ' num2str(length(loc))])
                            msgbox({['The column dimension of your data decreased from ' num2str(n) ' to '  num2str(length(loc)) '.'] ;''...
                                ; 'If you don''t want to decrease the column dimension, uncheck the "Decrease column dimension" item from the Edit menu and load your data again.'});
                            
                            
                        end
                        
                        
                        
                        
                        
                    end
                    
                    
                    
            end
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
        
        
        
    end




    function About_SigMa_uimenu_help_Callback(source,eventdata,handles)
        try
            About_SigMa
        catch e
            errordlg(e.message)
        end
        
    end





    function Manual_uimenu_help_Callback(source,eventdata,handles)
        try
            winopen('Manual.pdf')
        catch e
            errordlg(e.message)
        end
        
    end






    function Reference_uimenu_help_Callback(source,eventdata,handles)
        try
            winopen('Khakimov_ACA_2020.pdf')
        catch e
            errordlg(e.message)
        end
        
    end







    function Video_tutorial_uimenu_help_Callback(source,eventdata,handles)
        try
            %winopen('How to run SigMa.docx')
        catch e
            errordlg(e.message)
        end
        
    end







    function Contact_developer_uimenu_help_Callback(source,eventdata,handles)
        try
            web('https://food.ku.dk/english/staff/?pure=en/persons/388946')    
        catch e
            errordlg(e.message)
        end
        
    end








% Add Components to Tabs
% =============================================================================================================================
% =============================================================================================================================


% =============================================================================================================================
% Import Data
% =============================================================================================================================

[handles.h1_tab_Import_Data,handles.h2_tab_Import_Data,handles.hDivider1_tab_Import_Data] = uisplitpane(handles.tab_Import_Data);
set(handles.hDivider1_tab_Import_Data,'DividerColor','green')
handles.hDivider1_tab_Import_Data.DividerLocation = 0.15;

[handles.h3_tab_Import_Data,handles.h4_tab_Import_Data,handles.hDivider2_tab_Import_Data] = uisplitpane(handles.h2_tab_Import_Data,'Orientation','ver');
set(handles.hDivider2_tab_Import_Data,'DividerColor','green')
handles.hDivider2_tab_Import_Data.DividerLocation = 0.001;


handles.tab_Import_Data_Import_Bruker_Data_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Import Bruker Data ','Callback',{@tab_Import_Data_Import_Bruker_Data_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [25 566 130 22]) ;

handles.tab_Import_Data_Import_MATLAB_Data_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Import MATLAB Data ','Callback',{@tab_Import_Data_Import_MATLAB_Data_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [25 539 130 22]) ;


handles.tab_Import_Data_data_size_str = uicontrol('Parent', handles.h1_tab_Import_Data, 'Style', 'text', 'String',...
    'Data size:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [20 516 130 20]) ;



handles.tab_Import_Data_listbox_str = uicontrol('Parent', handles.h1_tab_Import_Data, 'Style', 'text', 'String',...
    'Samples:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 495 70 20]) ;

handles.tab_Import_Data_listbox = uicontrol('Parent', handles.h1_tab_Import_Data, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [5 395 170 100],'Visible','on','Callback',{@tab_Import_Data_listbox_Callback,handles}) ;

handles.tab_Import_Data_Delete_samp_and_var_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton', 'String',...
    'Delete samples & variables','Visible','on','Callback',{@tab_Import_Data_Delete_samp_and_var_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [10 367 160 25]) ;
% tab_Import_Data_Delete_samp_and_var_pb_UICntMn = uicontextmenu;
% handles.tab_Import_Data_Delete_samp_and_var_pushbutton.UIContextMenu = tab_Import_Data_Delete_samp_and_var_pb_UICntMn;
% IDM_UICntMn1 = uimenu(tab_Import_Data_Delete_samp_and_var_pb_UICntMn,'Label','Accept data','Callback',{@tab_Import_Data_Delete_samp_and_var_pb_UI_cm,handles});




handles.tab_Import_Data_plot_type_popupmenu_str = uicontrol('Parent', handles.h1_tab_Import_Data, 'Style', 'text', 'String',...
    'Plot:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [42 337 40 20]) ;

handles.tab_Import_Data_plot_type_popupmenu = uicontrol('Parent', handles.h1_tab_Import_Data, 'Style', 'popupmenu', 'String',[{'Overlay'} ; {'Subplot'} ; {'Sample-wise'}],...
    'Visible','on','FontSize',8,'Callback',{@tab_Import_Data_plot_type_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [75 337 90 25]) ;



handles.tab_Import_Data_sample_type_popupmenu_str = uicontrol('Parent', handles.h1_tab_Import_Data, 'Style', 'text', 'String',...
    'Sample type:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 310 75 20]) ;

handles.tab_Import_Data_sample_type_popupmenu = uicontrol('Parent', handles.h1_tab_Import_Data, 'Style', 'popupmenu', 'String',[{'Select ...'} ; {'Urine'} ; {'Plasma'} ; {'Faecal'} ; {'Milk'} ; {'Whey'} ; {'Wine'} ; {'Beer'} ; {'Oil'}; {'None'} ; {'Custom'}],...
    'Visible','on','FontSize',8,'Backgroundcolor',[1 0 0],'Callback',{@tab_Import_Data_sample_type_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [75 310 90 25]) ;


handles.tab_Import_Data_Load_options_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton', 'String',...
    'Load options','Visible','on','Callback',{@tab_Import_Data_Load_options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [75 289 90 20]) ;


handles.tab_Import_Data_RUN_by_default_settings_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton', 'String',...
    'One-Click SigMa','Visible','on','Callback',{@tab_Import_Data_RUN_by_default_settings_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [15 255 150 20]) ;



handles.tab_Import_Data_Apply_norm_uipanel = uipanel('Parent', handles.h1_tab_Import_Data, 'Position',[.01 .12 .98 .25],'Title','Normalize Data','Visible','on');

handles.tab_Import_Data_Normalization_method_popupmenu_str = uicontrol('Parent', handles.tab_Import_Data_Apply_norm_uipanel, 'Style', 'text', 'String',...
    'Normalization method:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 85 90 40]) ;

handles.tab_Import_Data_Normalization_method_popupmenu = uicontrol('Parent', handles.tab_Import_Data_Apply_norm_uipanel, 'Style', 'popupmenu', 'String',[{'1norm'} ; {'2norm'} ;{'infnorm'};{'pqn'};{'mfc'};{'refnorm'};{'msc'};{'snv'}],...
    'Visible','on','FontSize',8,'Callback',{@tab_Import_Data_Normalization_method_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [80 93 80 25]) ;

handles.tab_Import_Data_Apply_norm_start_of_the_region_str = uicontrol('Parent', handles.tab_Import_Data_Apply_norm_uipanel, 'Style', 'text', 'String',...
    'Start ppm:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [6 65 80 20]) ;

handles.tab_Import_Data_Apply_norm_start_of_the_region_edit = uicontrol('Parent', handles.tab_Import_Data_Apply_norm_uipanel, 'Style', 'edit','String','','Visible','off','Position', [70 65 50 20]) ;

handles.tab_Import_Data_Apply_norm_end_of_the_region_str = uicontrol('Parent', handles.tab_Import_Data_Apply_norm_uipanel, 'Style', 'text', 'String',...
    'End ppm:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [6 35 80 20]) ;

handles.tab_Import_Data_Apply_norm_end_of_the_region_edit = uicontrol('Parent', handles.tab_Import_Data_Apply_norm_uipanel, 'Style', 'edit','String','','Visible','off','Position', [70 35 50 20]) ;

handles.tab_Import_Data_Apply_norm_pushbutton = uicontrol('Parent',handles.tab_Import_Data_Apply_norm_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Apply norm','Callback',{@tab_Import_Data_Apply_norm_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [50 2 80 25]) ;



handles.tab_Import_Data_undo_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Undo','Callback',{@tab_Import_Data_undo_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [7 32 80 30]) ;

handles.tab_Import_Data_new_plot_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'New plot','Callback',{@tab_Import_Data_new_plot_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [90 32 80 30]) ;


handles.tab_Import_Data_save_pushbutton = uicontrol('Parent',handles.h1_tab_Import_Data, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Save','Enable','off','Callback',{@tab_Import_Data_save_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [45 2 80 30]) ;


handles.data = [];
handles.tab_Import_Data_index_for_plotting = 0;
handles.tab_Import_Data_frame1 = uipanel('Parent', handles.h4_tab_Import_Data, 'Position',[.000001 .0000001 .999 .999]);








    function tab_Import_Data_Import_Bruker_Data_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            %fdf=sdsdfsdf;
            GUI_dir = cd;
            cd ..
            temp_dir = cd;
            
            addpath(genpath([temp_dir '\m files of sigma']))
            dname = uigetdir;
            h = waitbar(0.5,'Please wait...');
            
            [handles.data,handles.sample_AcqPars,handles.sample_ProcPars]=import_processed_bruker_nmr_data_bkh(dname);
            close(h)
            
            cd(GUI_dir)
            
            
            
            Decrease_column_dimension_uimenu_Edit = get(handles.Decrease_column_dimension_uimenu_Edit,'Checked');
            msg_type = 0;
            switch Decrease_column_dimension_uimenu_Edit
                case 'on'
                    [m,n]=size(handles.data.data);
                    
                    if n<10000
                        loc = 1:n;
                        msg_type = 0;
                    elseif n>10000
                        loc0 = ceil(n/10000);
                        loc = 1:loc0:n;
                        msg_type = 1;
                    end
                    
                    handles.data.data = handles.data.data(:,loc);
                    handles.data.ppm_mean = handles.data.ppm_mean(loc);
                    
            end
            
            set(handles.tab_Import_Data_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
            
            
            
            
            hold off
            
            
            set(handles.tab_Import_Data_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Lp_Prediction_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Reference_Alignment_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Import_Data_listbox_str,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox_str,'Visible','on')
            set(handles.tab_Import_Data_listbox,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox,'Visible','on')
            set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Visible','on')
            
            set(handles.tab_Import_Data_Load_options_pushbutton,'Visible','on')
            
            set(handles.tab_Import_Data_Apply_norm_uipanel,'Visible','on')
            
            set(handles.tab_Import_Data_plot_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_plot_type_popupmenu,'Visible','on')
            
            set(handles.tab_Import_Data_sample_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_sample_type_popupmenu,'Visible','on')
            set(handles.tab_Import_Data_undo_pushbutton,'Visible','on')
            set(handles.tab_Import_Data_new_plot_pushbutton,'Visible','on')
            
            
            handles.tab_Import_Data_index_for_plotting = 1;
            legend off
            
            set(handles.tab_Import_Data_Import_Bruker_Data_pushbutton,'BackgroundColor',[0 1 0])
            set(handles.tab_Import_Data_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            
            set(handles.tab_Lp_Prediction_Import_Bruker_Data_pushbutton,'BackgroundColor',[0 1 0])
            set(handles.tab_Lp_Prediction_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            
            
            set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Backgroundcolor',[0.94 0.94 0.94],'Tooltipstring','')
            set(handles.tab_Import_Data_Apply_norm_pushbutton,'Backgroundcolor',[0.94 0.94 0.94],'Tooltipstring','')
            set(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'BackgroundColor',[0.94 0.94 0.94],'Tooltipstring','')
            set(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor',[0.94 0.94 0.94],'Tooltipstring','')
            
            
            
        catch e
            errordlg(e.message)
            close(h)
        end
        
        setappdata(0,'handles',handles)
        
    end





    function tab_Import_Data_Import_MATLAB_Data_pushbutton_Callback(source,eventdata,~)
        handles = getappdata(0,'handles');
        
        try
            
            [filename, pathname] = uigetfile( {'*.mat','MATLAB Files (*.mat)'; '*.*',  'All Files (*.*)'}, 'Pick a file');
            
            nmrdata_temp = load([pathname filename]);
            ff2 = fieldnames(nmrdata_temp);
            nmrdata = nmrdata_temp.(ff2{1});
            h = waitbar(0.5,'Please wait...');
            
            [handles.data,handles.sample_AcqPars,handles.sample_ProcPars] = import_processed_matlab_nmr_data_bkh(nmrdata);
            handles.sample_AcqPars.sample_AcqPars_Title = handles.data.subjects;
            close(h)
            
            
            Decrease_column_dimension_uimenu_Edit = get(handles.Decrease_column_dimension_uimenu_Edit,'Checked');
            msg_type = 0;
            switch Decrease_column_dimension_uimenu_Edit
                case 'on'
                    [m,n]=size(handles.data.data);
                    
                    if n<10000
                        loc = 1:n;
                        msg_type = 0;
                    elseif n>10000
                        loc0 = ceil(n/10000);
                        loc = 1:loc0:n;
                        msg_type = 1;
                    end
                    
                    handles.data.data = handles.data.data(:,loc);
                    handles.data.ppm_mean = handles.data.ppm_mean(loc);
                    
            end
            set(handles.tab_Import_Data_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
            
            set(handles.tab_Lp_Prediction_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
            
            
            
            set(handles.tab_Import_Data_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Lp_Prediction_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Reference_Alignment_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Import_Data_listbox_str,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox_str,'Visible','on')
            set(handles.tab_Import_Data_listbox,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox,'Visible','on')
            set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Visible','on')
            set(handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton,'Visible','on')
            set(handles.tab_Import_Data_Apply_norm_uipanel,'Visible','on')
            
            set(handles.tab_Import_Data_plot_type_popupmenu_str,'Visible','on')
            set(handles.tab_Lp_Prediction_plot_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_plot_type_popupmenu,'Visible','on')
            set(handles.tab_Lp_Prediction_plot_type_popupmenu,'Visible','on')
            
            set(handles.tab_Import_Data_Load_options_pushbutton,'Visible','on')
            
            set(handles.tab_Import_Data_sample_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_sample_type_popupmenu,'Visible','on')
            set(handles.tab_Import_Data_undo_pushbutton,'Visible','on')
            set(handles.tab_Import_Data_new_plot_pushbutton,'Visible','on')
            
            handles.tab_Import_Data_index_for_plotting = 1;
            
            
            
            legend off
            
            set(handles.tab_Import_Data_Import_Bruker_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            set(handles.tab_Import_Data_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0 1 0])
            
            set(handles.tab_Lp_Prediction_Import_Bruker_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            set(handles.tab_Lp_Prediction_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0 1 0])
            
            
            set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Backgroundcolor',[0.94 0.94 0.94],'Tooltipstring','')
            set(handles.tab_Import_Data_Apply_norm_pushbutton,'Backgroundcolor',[0.94 0.94 0.94],'Tooltipstring','')
            set(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'BackgroundColor',[0.94 0.94 0.94],'Tooltipstring','')
            set(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor',[0.94 0.94 0.94],'Tooltipstring','')
            
            
        catch e
            try
                close(h)
            end
            errordlg(e.message)
            
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Import_Data_listbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            tab_Import_Data_listbox_str = get(handles.tab_Import_Data_listbox,'String');
            tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
            
            tab_Import_Data_plot_type_popupmenu_val = get(handles.tab_Import_Data_plot_type_popupmenu,'Value');
            
            subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
            plot(0,0,'*w')
            
            
            tab_Import_Data_Delete_samp_and_var_pb_Bckcolor = get(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Backgroundcolor');
            if tab_Import_Data_Delete_samp_and_var_pb_Bckcolor == [0.9294 0.6902 0.1294]
                
                
                switch tab_Import_Data_plot_type_popupmenu_val
                    case 1
                        subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
                        plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val,:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        hold off
                        
                        legend_name = {};
                        for i = 1:length(tab_Import_Data_listbox_val)
                            legend_name(i) = tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i));
                        end
                        legend(legend_name)
                        %legend off
                    case 2
                        [x , y] = subplot_x_y_size(length(tab_Import_Data_listbox_val));
                        for i = 1:length(tab_Import_Data_listbox_val)
                            ax(i) = subplot(x,y,i,'Parent',handles.tab_Import_Data_frame1);
                            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                    case 3
                        
                        for i = 1:length(tab_Import_Data_listbox_val)
                            ax(i) = subplot(length(tab_Import_Data_listbox_val),1,i,'Parent',handles.tab_Import_Data_frame1);
                            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                end
                
            else
                
                switch tab_Import_Data_plot_type_popupmenu_val
                    case 1
                        subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
                        plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val,:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        hold off
                        
                        legend_name = {};
                        for i = 1:length(tab_Import_Data_listbox_val)
                            legend_name(i) = tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i));
                        end
                        legend(legend_name)
                        %legend off
                    case 2
                        [x , y] = subplot_x_y_size(length(tab_Import_Data_listbox_val));
                        for i = 1:length(tab_Import_Data_listbox_val)
                            ax(i) = subplot(x,y,i,'Parent',handles.tab_Import_Data_frame1);
                            plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                    case 3
                        
                        for i = 1:length(tab_Import_Data_listbox_val)
                            ax(i) = subplot(length(tab_Import_Data_listbox_val),1,i,'Parent',handles.tab_Import_Data_frame1);
                            plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                end
                
                
                
            end
            
            %legend off
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Import_Data_plot_type_popupmenu_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            tab_Import_Data_listbox_str = get(handles.tab_Import_Data_listbox,'String');
            tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
            
            tab_Import_Data_plot_type_popupmenu_val = get(handles.tab_Import_Data_plot_type_popupmenu,'Value');
            
            subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
            plot(0,0,'*w')
            
            switch tab_Import_Data_plot_type_popupmenu_val
                case 1
                    subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
                    plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val,:)); xlabel('ppm');
                    set(gca,'xdir','rev');
                    axis tight
                    hold off
                    
                    
                    legend_name = {};
                    for i = 1:length(tab_Import_Data_listbox_val)
                        legend_name(i) = tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i));
                    end
                    legend(legend_name)
                    
                case 2
                    [x , y] = subplot_x_y_size(length(tab_Import_Data_listbox_val));
                    for i = 1:length(tab_Import_Data_listbox_val)
                        ax(i) = subplot(x,y,i,'Parent',handles.tab_Import_Data_frame1);
                        plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                    end
                    linkaxes(ax,'xy');
                    hold off
                    
                case 3
                    
                    for i = 1:length(tab_Import_Data_listbox_val)
                        ax(i) = subplot(length(tab_Import_Data_listbox_val),1,i,'Parent',handles.tab_Import_Data_frame1);
                        plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                    end
                    linkaxes(ax,'xy');
                    hold off
                    
            end
            %legend off
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end








    function tab_Import_Data_Delete_samp_and_var_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
        
        tab_Import_Data_sample_type_popupmenu0 = get(handles.tab_Import_Data_sample_type_popupmenu,'Value');
        output = tab_Import_Data_Delete_samp_and_var_pb_gui(handles.data,handles.sample_AcqPars,handles.sample_ProcPars,handles.sigma_plasma_options,tab_Import_Data_sample_type_popupmenu0,'Import_Data');
        
        if isempty(output)
            return
        end
        handles.data_new = output{1}(:,1);
        handles.sample_AcqPars_new = output{2};
        handles.sample_ProcPars_new = output{3};
        handles.sigma_plasma_options_new =output{4};
        
        
        tab_Import_Data_sample_type_popupmenu = output{5};
        set(handles.tab_Import_Data_sample_type_popupmenu,'Value',tab_Import_Data_sample_type_popupmenu);
        
        
        
        
        hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
        data = [(1:length(handles.sigma_plasma_options_new.intervals_name))' handles.sigma_plasma_options_new.intervals_class...
            handles.sigma_plasma_options_new.intervals_ppm handles.sigma_plasma_options_new.VariablesIncluded handles.sigma_plasma_options_new.intervals_ppm_flex hihi_index];
        kk = ~isnan(data(:,3));
        kk2 = data(kk,:);
        kk2 = sortrows(kk2,2);
        unique_kk2 = unique(kk2(:,2));
        kk4 = [];
        for ii3 = 1:length(unique_kk2)
            unique_1 = (kk2(:,2) == unique_kk2(ii3));
            kk3 = sortrows(kk2(unique_1,:),3);
            kk4 = [kk4 ; kk3];
        end
        
 % hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end

        % handles.sigma_plasma_options_new.intervals_name = handles.sigma_plasma_options_new.intervals_name(kk4(:,1));
        % 
        % handles.sigma_plasma_options_new.intervals_class = kk4(:,2);
        % handles.sigma_plasma_options_new.intervals_ppm = kk4(:,3:4);
        % handles.sigma_plasma_options_new.VariablesIncluded = kk4(:,5);
        % handles.sigma_plasma_options_new.intervals_ppm_flex=kk4(:,6:7);


        kk4 = [(1:size(kk4,1))' kk4(:,2:5)];
        
        
              
        set(handles.Intervals_Selected_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options_new.intervals_name)
        set(handles.tab_Interval_Alignment_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options_new.intervals_name)





        set(handles.tab_Import_Data_listbox,'Value',1:length(handles.sample_AcqPars_new.sample_AcqPars_Title))
        set(handles.tab_Import_Data_listbox,'String',handles.sample_AcqPars_new.sample_AcqPars_Title);

        tab_Import_Data_listbox_str = get(handles.tab_Import_Data_listbox,'String');
        tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');

        tab_Import_Data_plot_type_popupmenu_val = get(handles.tab_Import_Data_plot_type_popupmenu,'Value');

        subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
        plot(0,0,'*w')

        switch tab_Import_Data_plot_type_popupmenu_val
            case 1
                subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val,:)); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                hold off


                legend_name = {};
                for i = 1:length(tab_Import_Data_listbox_val)
                    legend_name(i) = tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i));
                end
                legend(legend_name)

            case 2
                [x , y] = subplot_x_y_size(length(tab_Import_Data_listbox_val));
                for i = 1:length(tab_Import_Data_listbox_val)
                    ax(i) = subplot(x,y,i,'Parent',handles.tab_Import_Data_frame1);
                    plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                    set(gca,'xdir','rev');
                    axis tight
                    legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                end
                linkaxes(ax,'xy');
                hold off

            case 3

                for i = 1:length(tab_Import_Data_listbox_val)
                    ax(i) = subplot(length(tab_Import_Data_listbox_val),1,i,'Parent',handles.tab_Import_Data_frame1);
                    plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val(i),:)); xlabel('ppm');
                    set(gca,'xdir','rev');
                    axis tight
                    legend(tab_Import_Data_listbox_str(tab_Import_Data_listbox_val(i)))
                end
                linkaxes(ax,'xy');
                hold off

        end


        set(handles.tab_Import_Data_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data_new.data,1)) ' * ' num2str(size(handles.data_new.data,2))]);
        set(handles.tab_Lp_Prediction_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data_new.data,1)) ' * ' num2str(size(handles.data_new.data,2))]);

        set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Backgroundcolor',[0.9294 0.6902 0.1294],'Tooltipstring','Accept data by preesing mouse right click and then accept data')


        tab_Import_Data_Delete_samp_and_var_pb_UICntMn = uicontextmenu;
        handles.tab_Import_Data_Delete_samp_and_var_pushbutton.UIContextMenu = tab_Import_Data_Delete_samp_and_var_pb_UICntMn;
        IDM_UICntMn1 = uimenu(tab_Import_Data_Delete_samp_and_var_pb_UICntMn,'Label','Accept data','Callback',{@tab_Import_Data_Delete_samp_and_var_pb_UI_cm,handles});

        set(handles.tab_Import_Data_save_pushbutton,'Enable','on')
        legend off
        %         catch e
        %             errordlg(e.message)
        %         end

        setappdata(0,'handles',handles)
    end



    function tab_Import_Data_sample_type_popupmenu_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
        hh = waitbar(0.5,'Please wait...');

       tab_Import_Data_sample_type_popupmenu_val = get(handles.tab_Import_Data_sample_type_popupmenu,'Value');
        switch tab_Import_Data_sample_type_popupmenu_val
            case 1
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[1 0 0]) ;

            case 2
                handles.sigma_plasma_options = sigma_urine_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;

            case 3
                handles.sigma_plasma_options = sigma_plasma_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;

            case 4
                handles.sigma_plasma_options = sigma_faecal_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;

            case 5
                handles.sigma_plasma_options = sigma_milk_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;

            case 6
                handles.sigma_plasma_options = sigma_whey_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;

            case 7
                handles.sigma_plasma_options = sigma_wine_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;

            case 8
                handles.sigma_plasma_options = sigma_beer_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;


            case 9
                handles.sigma_plasma_options = sigma_oil_options1;
                [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
                    (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;
            
            case 10
                [ handles ] = create_sigma_options_bkh(handles);
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;

            case 11

                [file,path,indx] = uigetfile( {  '*.xls*','Excel file (*.xlsx)'; ...
                    '*.*',  'All Files (*.*)'},    'Select a File');
                switch file
                    case 0
                        return
                end
                [ handles ] = create_sigma_options_bkh(handles);
                
                [num,txt,raw] = xlsread([path file]);
                r1=raw(1,:);
                
                
                % USER MUST INCLUDE THESE VARIABLES IN THEIR CUSTOM EXCEL FILE 
                s1=find(strcmp('Interval_class',r1)==1);
                handles.sigma_plasma_options.intervals_class=[];
                handles.sigma_plasma_options.intervals_class=cell2mat(raw(2:end,s1));
                
                s1=find(strcmp('Interval_name',r1)==1);
                handles.sigma_plasma_options.intervals_name=[];
                handles.sigma_plasma_options.intervals_name=raw(2:end,s1);
                
                s1=find(strcmp('end_ppm',r1)==1);
                handles.sigma_plasma_options.intervals_ppm=[];
                handles.sigma_plasma_options.intervals_ppm=zeros(length(raw(2:end,1)),2);
                handles.sigma_plasma_options.intervals_ppm(:,1)=cell2mat(raw(2:end,s1));
                
                s1=find(strcmp('start_ppm',r1)==1);
                handles.sigma_plasma_options.intervals_ppm(:,2)=cell2mat(raw(2:end,s1));
                
                % OPTIONAL VARIABLES IN CUSTOM EXCEL FILE
                s1=find(strcmp('VartiableInclude (1=yes, 0=no)',r1)==1);
                handles.sigma_plasma_options.VariablesIncluded=[];
                if isempty(s1)
                    handles.sigma_plasma_options.VariablesIncluded=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1); % 1 means include, 2 means exclude
                else  handles.sigma_plasma_options.VariablesIncluded=cell2mat(raw(2:end,s1)); 
                end
                
                s1=find(strcmp('end_ppm_flex',r1)==1);
                handles.sigma_plasma_options.intervals_ppm_flex=[];
                handles.sigma_plasma_options.intervals_ppm_flex=zeros(length(raw(2:end,1)),2);
                if isempty(s1)
                    handles.sigma_plasma_options.intervals_ppm_flex(:,1)=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1)/999;
                else handles.sigma_plasma_options.intervals_ppm_flex(:,1)=cell2mat(raw(2:end,s1)); 
                end
                
                s1=find(strcmp('start_ppm_flex',r1)==1);
                if isempty(s1)
                    handles.sigma_plasma_options.intervals_ppm_flex(:,2)=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1)/999;
                else handles.sigma_plasma_options.intervals_ppm_flex(:,2)=cell2mat(raw(2:end,s1)); 
                end
                
                s1=find(strcmp('numer_of_Hs_in_SS',r1)==1);
                handles.sigma_plasma_options.intervals_SS_and_total_1H=[];
                handles.sigma_plasma_options.intervals_SS_and_total_1H=ones(length(raw(2:end,1)),2);
                if isempty(s1)
                    handles.sigma_plasma_options.intervals_SS_and_total_1H(:,1)=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1);
                else handles.sigma_plasma_options.intervals_SS_and_total_1H(:,1)=cell2mat(raw(2:end,s1));
                end
                
                s1=find(strcmp('numer_of_total_Hs',r1)==1);
                if isempty(s1)
                    handles.sigma_plasma_options.intervals_SS_and_total_1H(:,2)=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1);
                else handles.sigma_plasma_options.intervals_SS_and_total_1H(:,2)=cell2mat(raw(2:end,s1));
                end
                
                s1=find(strcmp('intervals_Interative_Align',r1)==1);
                handles.sigma_plasma_options.intervals_Interative_Align=[];
                if isempty(s1)
                    handles.sigma_plasma_options.intervals_Interative_Align=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1);% 1 means align, 2 means NOT align
                else handles.sigma_plasma_options.intervals_Interative_Align=cell2mat(raw(2:end,s1));
                end
                
                s1=find(strcmp('intervals_MCR_Components',r1)==1);
                handles.sigma_plasma_options.intervals_MCR_Components=[];
                if isempty(s1)
                    handles.sigma_plasma_options.intervals_MCR_Components=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1); % 1 means 1PC MCR, can be any number
                else handles.sigma_plasma_options.intervals_MCR_Components=cell2mat(raw(2:end,s1));
                end
                
                s1=find(strcmp('intervals_consistant_occasional',r1)==1);
                handles.sigma_plasma_options.intervals_consistant_occasional=[];
                if isempty(s1)
                    handles.sigma_plasma_options.intervals_consistant_occasional=ones(length(handles.sigma_plasma_options.intervals_ppm(:,2)),1); % 1 means consistant, 2 means occasional
                else handles.sigma_plasma_options.intervals_consistant_occasional=cell2mat(raw(2:end,s1));
                end       
                 
                
               
                [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
                
                
                set(handles.tab_Import_Data_sample_type_popupmenu ,'Backgroundcolor',[0 1 0]) ;
        end
     
        
        switch tab_Import_Data_sample_type_popupmenu_val
            case {2,3,4,5,6,7,8,9,10}
                hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
                data = [(1:length(handles.sigma_plasma_options.intervals_name))' handles.sigma_plasma_options.intervals_class ...
                    handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded handles.sigma_plasma_options.intervals_ppm_flex hihi_index];
                kk = ~isnan(data(:,3));
                kk2 = data(kk,:);
                kk2 = sortrows(kk2,2);
                unique_kk2 = unique(kk2(:,2));
                kk4 = [];
                for ii3 = 1:length(unique_kk2)
                    unique_1 = (kk2(:,2) == unique_kk2(ii3));
                    kk3 = sortrows(kk2(unique_1,:),3);
                    kk4 = [kk4 ; kk3];
                end
                

 %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
 hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end

                
                kk4 = [(1:size(kk4,1))' kk4(:,2:5)];
                
                
                
                set(handles.Intervals_Selected_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options.intervals_name);
               %get the row header
                t=handles.Intervals_Selected_intervals_uitable;
                jscroll=findjobj(t);
                rowHeaderViewport=jscroll.getComponent(4);
                rowHeader=rowHeaderViewport.getComponent(0);
                height=rowHeader.getSize;
                % rowHeader.setSize(80,360)
                %resize the row header
                newWidth=750; %100 pixels.
                rowHeaderViewport.setPreferredSize(java.awt.Dimension(newWidth,0));
                height=rowHeader.getHeight;
                rowHeader.setPreferredSize(java.awt.Dimension(newWidth,height));
                rowHeader.setSize(newWidth,height);
                % figPos = get(handles.f,'Position');
                % tableExtent = get(t,'Extent');
                % set(handles.f,'Position',[figPos(1:2), figPos(3:4).*tableExtent(3:4)]);


                set(handles.tab_Interval_Alignment_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options.intervals_name);
                %get the row header
                t=handles.tab_Interval_Alignment_intervals_uitable;
                jscroll=findjobj(t);
                rowHeaderViewport=jscroll.getComponent(4);
                rowHeader=rowHeaderViewport.getComponent(0);
                height=rowHeader.getSize;
                % rowHeader.setSize(80,360)
                %resize the row header
                % newWidth=750; %100 pixels.
                rowHeaderViewport.setPreferredSize(java.awt.Dimension(newWidth,0));
                height=rowHeader.getHeight;
                rowHeader.setPreferredSize(java.awt.Dimension(newWidth,height));
                rowHeader.setSize(newWidth,height);
                % figPos = get(handles.f,'Position');
                % tableExtent = get(t,'Extent');
                % set(handles.f,'Position',[figPos(1:2), figPos(3:4).*tableExtent(3:4)]);

                
                set(handles.tab_Import_Data_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
                
                set(handles.tab_Lp_Prediction_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
                

                legend off
                
        end
        close(hh)
        
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end








    function tab_Import_Data_Load_options_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        [filename, pathname] = uigetfile( {'*.mat','MATLAB Files (*.mat)'; '*.*',  'All Files (*.*)'}, 'Pick a file');
        switch  filename
            case 0
                return
        end
        sigma_plasma_options_temp = load([pathname filename]);
        fff = fieldnames(sigma_plasma_options_temp);
        handles.sigma_plasma_options = sigma_plasma_options_temp.(fff{1});
        
        
        
        
        hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
        data = [(1:length(handles.sigma_plasma_options.intervals_name))' ...
            handles.sigma_plasma_options.intervals_class ...
            handles.sigma_plasma_options.intervals_ppm ...
            handles.sigma_plasma_options.VariablesIncluded ...
            handles.sigma_plasma_options.intervals_ppm_flex hihi_index];

        kk = ~isnan(data(:,3));
        kk2 = data(kk,:);
        kk2 = sortrows(kk2,2);
        unique_kk2 = unique(kk2(:,2));
        kk4 = [];
        for ii3 = 1:length(unique_kk2)
            unique_1 = (kk2(:,2) == unique_kk2(ii3));
            kk3 = sortrows(kk2(unique_1,:),3);
            kk4 = [kk4 ; kk3];
        end
        
 %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
 hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end

        kk4 = [(1:size(kk4,1))' kk4(:,2:5)];
        
        
        
        set(handles.Intervals_Selected_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options.intervals_name);
        
        set(handles.tab_Interval_Alignment_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options.intervals_name);
        
        set(handles.tab_Import_Data_sample_type_popupmenu,'BackgroundColor',[1 1 1])
        legend off
        
        setappdata(0,'handles',handles)
    end








    function tab_Import_Data_RUN_by_default_settings_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        tab_Import_Data_sample_type_popupmenu_val = get(handles.tab_Import_Data_sample_type_popupmenu,'Value');
        tab_Import_Data_sample_type_popupmenu_str = get(handles.tab_Import_Data_sample_type_popupmenu,'String');
        sample_type_popupmenu_str = lower(tab_Import_Data_sample_type_popupmenu_str{tab_Import_Data_sample_type_popupmenu_val});
        
        %         sigma_nmr_default_run(handles.data.data,handles.data.ppm_mean,sample_type_popupmenu_str,handles.sample_AcqPars.sample_AcqPars_Title);
        sigma_nmr_default_run(handles);
        
        setappdata(0,'handles',handles)
    end






    function tab_Import_Data_Normalization_method_popupmenu_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        str = get(handles.tab_Import_Data_Normalization_method_popupmenu,'String');
        val = get(handles.tab_Import_Data_Normalization_method_popupmenu,'Value');
        
        
        %         handles.tab_Import_Data_Apply_norm_start_of_the_region_str
        %
        %         handles.tab_Import_Data_Apply_norm_start_of_the_region_edit
        %
        %         handles.tab_Import_Data_Apply_norm_end_of_the_region_str
        %
        %         handles.tab_Import_Data_Apply_norm_end_of_the_region_edit
        
        
        switch str{val}
            case '1norm'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Start ppm:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','on','String','End ppm:')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','on')
            case '2norm'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Start ppm:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','on','String','End ppm:')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','on')
                
            case 'infnorm'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Start ppm:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','on','String','End ppm:')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','on')
                
            case 'pqn'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Ref. sams:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','off')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','off')
                
            case 'mfc'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Ref. sams:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','off')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','off')
                
            case 'refnorm'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Start ppm:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','on','String','End ppm:')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','on')
                
            case 'msc'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Start ppm:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','on','String','End ppm:')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','on')
                
            case 'snv'
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_str,'Visible','on','String','Start ppm:')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_str,'Visible','on','String','End ppm:')
                set(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'Visible','on')
                set(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'Visible','on')
                
        end
        
        %fffff=1111
        %{'Norm1'} ; {'Norm2'} ;{'infnorm'};{'pqn'};{'mfc'};{'refnorm'}
        %if
        legend off
        setappdata(0,'handles',handles)
    end






    function tab_Import_Data_Apply_norm_pushbutton_Callback(source,eventdata,handles)
        
        h = waitbar(0.5,'Normalization in progress...please wait!');
        
        handles = getappdata(0,'handles');
        %         try
        
        tab_Import_Data_Normalization_method_popupmenu_str = get(handles.tab_Import_Data_Normalization_method_popupmenu,'String');
        tab_Import_Data_Normalization_method_popupmenu_val = get(handles.tab_Import_Data_Normalization_method_popupmenu,'Value');
        tab_Import_Data_Normalization_method_popupmenu_str2 = tab_Import_Data_Normalization_method_popupmenu_str(tab_Import_Data_Normalization_method_popupmenu_val);
        start_of_the_region_val = str2double(get(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'String'));
        end_of_the_region_val = str2double(get(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'String'));
        
        st1=start_of_the_region_val;
        en1=end_of_the_region_val;
        
        % If User Wrongly inserted Start & End ppm - correct
        if st1>en1
            start_of_the_region_val=end_of_the_region_val;
            end_of_the_region_val=st1;
        end;
        clear st1 en1
        
        %             if (start_of_the_region_val > max(handles.data.ppm_mean)) || (end_of_the_region_val < min(handles.data.ppm_mean))
        %                 warndlg('Your inputted data is out of range')
        %             end
        
        % If User Start & End ppm range is Outside org ppm range - correct
        if start_of_the_region_val > max(handles.data.ppm_mean)
            start_of_the_region_val = max(handles.data.ppm_mean);
        end;
        if end_of_the_region_val < min(handles.data.ppm_mean)
            end_of_the_region_val=min(handles.data.ppm_mean);
        end;
        
        
        a1=abs(handles.data.ppm_mean-end_of_the_region_val); p1b=find(a1==min(a1));  if length(p1b)>1; p1b=p1b(1,1); end;
        a1=abs(handles.data.ppm_mean-start_of_the_region_val); p2b=find(a1==min(a1));    if length(p2b)>1; p2b=p2b(1,1); end;
        
        
        tab_start_of_the_region_edit_val = str2num(get(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'String'));
        tab_end_of_the_region_edit_val = str2num(get(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'String'));
        
        handles.data_new = handles.data;
        %{'Norm1'} ; {'Norm2'} ;{'infnorm'};{'pqn'};{'mfc'};{'refnorm'}
        switch tab_Import_Data_Normalization_method_popupmenu_str2{1}
            case '1norm'
                handles.data_new.data = norm_bkh(handles.data.data, '1norm');
            case '2norm'
                handles.data_new.data = norm_bkh(handles.data.data, '2norm');
            case 'infnorm'
                handles.data_new.data = norm_bkh(handles.data.data, 'infnorm');
            case {'pqn','mfc'}
                handles.data_new.data = norm_bkh(handles.data.data, tab_Import_Data_Normalization_method_popupmenu_str2,tab_start_of_the_region_edit_val);
            case 'refnorm'
                num1=find_closest_index_bkh(handles.data_new.ppm_mean,tab_start_of_the_region_edit_val); 
                num2=find_closest_index_bkh(handles.data_new.ppm_mean,tab_end_of_the_region_edit_val); 
                if num1>num2
                    num1_org=num1; 
                    num1=num2; 
                    num2=num1_org; 
                end
                handles.data_new.data = norm_bkh(handles.data.data, 'refnorm',[num1:num2]);
            case 'mcs'
                handles.data_new.data = norm_bkh(handles.data.data, 'msc');
            case 'snv'
                handles.data_new.data = norm_bkh(handles.data.data, 'snv');
        end
        
        
        tab_Import_Data_listbox_str = get(handles.tab_Import_Data_listbox,'String');
        
        tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
        if isempty(tab_Import_Data_listbox_val)
            set(handles.tab_Import_Data_listbox,'Value',1);
            tab_Import_Data_listbox_val = 1;
        end

        
        tab_Import_Data_plot_type_popupmenu_val = get(handles.tab_Import_Data_plot_type_popupmenu,'Value');
        
        set(0, 'currentfigure', handles.f);
        
        subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
        plot(0,0,'*w')
        
        set(0, 'currentfigure', handles.f);
        switch tab_Import_Data_plot_type_popupmenu_val
            case 1
                subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val,:)); hold on;
                plot(handles.data_new.ppm_mean(p1b:p2b),handles.data_new.data(:,p1b:p2b),'Color',[0.8 0.2 0.1 0.3],'LineWidth',2);
                %plot(handles.data_new.ppm_mean(p1b:p2b),handles.data_new.data(tab_Import_Data_listbox_val,p1b:p2b),'k','LineWidth',2);
                set(gca,'xdir','rev');
                axis tight
                hold off
                
            case 2
                [x , y] = subplot_x_y_size(length(tab_Import_Data_listbox_val));
                for i = 1:length(tab_Import_Data_listbox_val)
                    ax(i) = subplot(x,y,i,'Parent',handles.tab_Import_Data_frame1);
                    plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val,:)); hold on;
                    %plot(handles.data.ppm_mean(p1b:p2b),handles.data.data(tab_Import_Data_listbox_val,p1b:p2b),'Color',[0.8 0.2 0.1 0.3],'LineWidth',2);
                    plot(handles.data_new.ppm_mean(p1b:p2b),handles.data_new.data(tab_Import_Data_listbox_val,p1b:p2b),'k','LineWidth',2);
                    set(gca,'xdir','rev');
                    axis tight
                end
                linkaxes(ax,'xy');
                hold off
                
            case 3
                
                for i = 1:length(tab_Import_Data_listbox_val)
                    ax(i) = subplot(length(tab_Import_Data_listbox_val),1,i,'Parent',handles.tab_Import_Data_frame1);
                    plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Import_Data_listbox_val,:)); hold on;
                    %plot(handles.data.ppm_mean(p1b:p2b),handles.data.data(tab_Import_Data_listbox_val,p1b:p2b),'Color',[0.8 0.2 0.1 0.3],'LineWidth',2);
                    plot(handles.data_new.ppm_mean(p1b:p2b),handles.data_new.data(tab_Import_Data_listbox_val,p1b:p2b),'k','LineWidth',2);
                    set(gca,'xdir','rev');
                    axis tight
                end
                linkaxes(ax,'xy');
                hold off
                
        end
        
        delete(h);
        
        handles.tab_Import_Data_index_for_plotting = 2;
        
        set(handles.tab_Import_Data_Apply_norm_pushbutton,'BackgroundColor',[0.9294 0.6902 0.1294],'Tooltipstring','Accept data by preesing mouse right click and then accept data')
        
        tab_Import_Data_Apply_norm_pb_UICntMn = uicontextmenu;
        handles.tab_Import_Data_Apply_norm_pushbutton.UIContextMenu = tab_Import_Data_Apply_norm_pb_UICntMn;
        IDM_UICntMn2 = uimenu(tab_Import_Data_Apply_norm_pb_UICntMn,'Label','Accept data','Callback',{@tab_Import_Data_Apply_norm_pb_UI_cm,handles});
        
        set(handles.tab_Import_Data_save_pushbutton,'Enable','on')
        legend off
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
        
    end






    function tab_Import_Data_undo_pushbutton_Callback(source,eventdata,handles)
%         try
            
            handles = getappdata(0,'handles');
            %handles.data = handles.data_ini;
            %handles.sample_AcqPars = handles.sample_AcqPars_ini;
            %handles.sample_ProcPars = handles.sample_ProcPars_ini;
            
            
            subplot(1,1,1,'Parent',handles.tab_Import_Data_frame1)
            plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');
            set(gca,'xdir','rev');
            axis tight
            hold off
            title('Raw Data')
            legend(handles.sample_AcqPars.sample_AcqPars_Title)
            
            set(handles.tab_Import_Data_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',1:size(handles.data.data,1))
            
            set(handles.tab_Import_Data_listbox_str,'Visible','on')
            set(handles.tab_Import_Data_listbox,'Visible','on')
            set(handles.tab_Import_Data_Apply_norm_uipanel,'Visible','on')
            
            set(handles.tab_Import_Data_plot_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_plot_type_popupmenu,'Visible','on')
            
            set(handles.tab_Import_Data_sample_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_sample_type_popupmenu,'Visible','on')
            
            handles.tab_Import_Data_index_for_plotting = 1;
            
            legend off
            
            set(handles.tab_Import_Data_Apply_norm_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
%         catch e
%             errordlg(e.message)
%         end
        
        setappdata(0,'handles',handles)
    end






    function tab_Import_Data_new_plot_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            fig = figure;
            new_handle = copyobj(handles.tab_Import_Data_frame1,fig);
            
        catch e
            errordlg(e.message)
        end
        
    end



    function tab_Import_Data_save_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            text1=['Choose data: '];
            reply = inputdlg([text1,' type 1 to save Just Imported Raw and 2 for processed data' ]);
            if str2num(cell2mat(reply))==1;
                dname = uigetdir;
                options=handles.sigma_plasma_options;
                save([dname '\' 'options'], 'options');
                clear options
                RawData=handles.data;
                save([dname '\' 'RawData'], 'RawData');
                clear RawData
            elseif str2num(cell2mat(reply))==2;
                dname = uigetdir;
                options=handles.sigma_plasma_options;
                save([dname '\' 'options'], 'options');
                clear options
                ProcessedData=handles.data_new;
                save([dname '\' 'ProcessedData'], 'ProcessedData');
                clear ProcessedData
            end;
        catch e
            errordlg(e.message)
        end
        
    end






% =============================================================================================================================
% Reference Alignment
% =============================================================================================================================

[handles.h1_tab_Reference_alignment,handles.h2_tab_Reference_alignment,handles.hDivider1_tab_Reference_alignment] = uisplitpane(handles.tab_Reference_alignment);
set(handles.hDivider1_tab_Reference_alignment,'DividerColor','green')
handles.hDivider1_tab_Reference_alignment.DividerLocation = 0.15;

[handles.h3_tab_Reference_alignment,handles.h4_tab_Reference_alignment,handles.hDivider2_tab_Reference_alignment] = uisplitpane(handles.h2_tab_Reference_alignment,'Orientation','ver');
set(handles.hDivider2_tab_Reference_alignment,'DividerColor','green')
handles.hDivider2_tab_Reference_alignment.DividerLocation = 0.001;

handles.tab_Reference_frame1 = uipanel('Parent', handles.h4_tab_Reference_alignment, 'Position',[.000001 .0000001 .999 .999]);


handles.tab_Reference_Alignment_Align_Reference_Signal_uipanel = uipanel('Parent', handles.h1_tab_Reference_alignment, 'Position',[.01 .74 .98 .25],'Title','Align Reference Signal','Visible','on');



handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton = uicontrol('Parent',handles.tab_Reference_Alignment_Align_Reference_Signal_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Align Reference Signal','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Align_Ref_Signal_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 80 166 30]) ;



handles.tab_Reference_Alignment_Align_Ref_Sig_undo_pushbutton = uicontrol('Parent',handles.tab_Reference_Alignment_Align_Reference_Signal_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Undo','Visible','off','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Align_Ref_Sig_undo_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [50 50 70 30]) ;

handles.tab_Reference_Alignment_Align_Ref_Sig_options_pb = uicontrol('Parent',handles.tab_Reference_Alignment_Align_Reference_Signal_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Options','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Align_Ref_Sig_options_pb_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [41 20 90 30]) ;



handles.tab_Reference_Alignment_Pre_Align_Spectra_uipanel = uipanel('Parent', handles.h1_tab_Reference_alignment, 'Position',[.01 .48 .98 .25],'Title','Pre-Align Spectra','Visible','on');

handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton = uicontrol('Parent',handles.tab_Reference_Alignment_Pre_Align_Spectra_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Pre-Align Spectra','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Pre_Align_Spectra_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 80 166 30]) ;

handles.tab_Reference_Alignment_Pre_Align_undo_pushbutton = uicontrol('Parent',handles.tab_Reference_Alignment_Pre_Align_Spectra_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Undo','Visible','off','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Pre_Align_undo_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [50 50 70 30]) ;

handles.tab_Reference_Alignment_Pre_Align_options_pushbutton = uicontrol('Parent',handles.tab_Reference_Alignment_Pre_Align_Spectra_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Options','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Pre_Align_options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [41 20 90 30]) ;



handles.tab_Reference_Alignment_Intervals_uipanel = uipanel('Parent', handles.h1_tab_Reference_alignment, 'Position',[.01 .35 .98 .1],'Title','Intervals','Visible','on');

% handles.tab_Reference_Alignment_Intervals_pushbutton = uicontrol('Parent',handles.h1_tab_Reference_alignment, 'Style', 'pushbutton','FontWeight','bold', 'String',...
%     'Intervals','FontSize',10,'FontWeight','bold','Enable','off','Callback',{@tab_Reference_Alignment_Intervals_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [20 240 140 30]) ;

handles.tab_Reference_Alignment_Show_pushbutton = uicontrol('Parent',handles.tab_Reference_Alignment_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Show','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Show_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [20 7 70 30]) ;

handles.tab_Reference_Alignment_Hide_pushbutton = uicontrol('Parent',handles.tab_Reference_Alignment_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Hide','FontSize',10,'FontWeight','bold','Callback',{@tab_Reference_Alignment_Hide_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [90 7 70 30]) ;



handles.tab_Reference_Alignment_listbox_str = uicontrol('Parent', handles.h1_tab_Reference_alignment, 'Style', 'text', 'String',...
    'Samples:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 170 70 20]) ;

handles.tab_Reference_Alignment_listbox = uicontrol('Parent', handles.h1_tab_Reference_alignment, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [5 40 170 130],'Visible','on','Callback',{@tab_Reference_Alignment_listbox_Callback,handles}) ;

handles.tab_Reference_Alignment_plot_type_popupmenu_str = uicontrol('Parent', handles.h1_tab_Reference_alignment, 'Style', 'text', 'String',...
    'Plot:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [20 5 40 20]) ;

handles.tab_Reference_Alignment_plot_type_popupmenu = uicontrol('Parent', handles.h1_tab_Reference_alignment, 'Style', 'popupmenu', 'String',[{'Overlay'} ; {'Subplot'} ; {'Sample-wise'}],...
    'Visible','off','FontSize',8,'Callback',{@tab_Reference_Alignment_plot_type_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [48 5 90 25]) ;


handles.tab_Reference_Alignment_save_pushbutton = uicontrol('Parent',handles.h1_tab_Reference_alignment, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Save','Enable','off','Callback',{@tab_Reference_Alignment_save_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [45 2 80 30]) ;




handles.tab_Reference_Alignment_index_for_plotting = 0;





handles.Reference_Alignment_tab_data = [];
handles.Reference_Alignment_tab_ppm_ref_align = [];
handles.Reference_Alignment_tab_ppm_mean = [];
handles.tab_Reference_Alignment_Align_current_plot = {};


    function tab_Reference_Alignment_Align_Ref_Signal_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            hh = waitbar(0.5,'Please wait...');
            
            set(0, 'currentfigure', handles.f);
            set(handles.tab_Reference_Alignment_listbox,'Value',1);
            
            delete(handles.tab_Reference_frame1.Children)
            if handles.tab_Import_Data_index_for_plotting == 1
                [handles.data_new.data, handles.data_new.ppm_mean] = sigma_ref_align_bkh(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options);
            elseif handles.tab_Import_Data_index_for_plotting == 2
                %                 [handles.data_new.data, handles.data_new.ppm_mean] = sigma_ref_align_bkh(handles.data_new.data,handles.data.ppm_mean,handles.sigma_plasma_options);
                [handles.data_new.data, handles.data_new.ppm_mean] = sigma_ref_align_bkh(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options);
            end
            
            ax1(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
            if size(handles.data.data,1) < 3
                plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');
                set(handles.tab_Reference_Alignment_listbox,'Value',1:size(handles.data.data,1));
            else
                plot_bkh(handles.data.ppm_mean,handles.data.data(1:2,:)); xlabel('ppm');
                set(handles.tab_Reference_Alignment_listbox,'Value',1:2);
            end
            set(gca,'xdir','rev');
            axis tight
            title('Raw Data')
            hold off
            
            
            %         handles.tab_Reference_Alignment_Align_current_plot = {};
            %         handles.tab_Reference_Alignment_Align_current_plot_bkh(1,1) = {'handles.data.ppm_mean'};
            %         handles.tab_Reference_Alignment_Align_current_plot_bkh(1,2) = {'handles.data.data'};
            %         handles.tab_Reference_Alignment_Align_current_plot_bkh(1,3) = {'axx(1) = subplot(2,1,1,''Parent'',handles.tab_Reference_frame1);'};
            %         handles.tab_Reference_Alignment_Align_current_plot(1,4) = {'plot(handles.data.ppm_mean,handles.data.data);'};
            %         handles.tab_Reference_Alignment_Align_current_plot(1,5) = {'xlabel(''ppm'');'};
            %         handles.tab_Reference_Alignment_Align_current_plot(1,6) = {'set(gca,''xdir'',''rev'');'};
            %         handles.tab_Reference_Alignment_Align_current_plot(1,7) = {'axis tight'};
            %         handles.tab_Reference_Alignment_Align_current_plot(1,8) = {'title(''Raw Data'')'};
            %         handles.tab_Reference_Alignment_Align_current_plot(1,9) = {'hold off'};
            
            ax1(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(1:2,:)); xlabel('ppm');
            set(gca,'xdir','rev');
            axis tight
            title('Aligned data')
            hold off
            linkaxes(ax1,'xy');
            
            %         handles.tab_Reference_Alignment_Align_current_plot(2,1) = {'handles.data_new.ppm_mean'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,2) = {'handles.data_new.data'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,3) = {'axx(2) = subplot(2,1,2,''Parent'',handles.tab_Reference_frame1);'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,4) = {'plot(handles.data_new.ppm_mean,handles.data_new.data);'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,5) = {'xlabel(''ppm'');'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,6) = {'set(gca,''xdir'',''rev'');'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,7) = {'axis tight'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,8) = {'title(''Aligned data'')'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,9) = {'hold off'};
            %         handles.tab_Reference_Alignment_Align_current_plot(2,10) = {'linkaxes(ax1,''xy'');'};
            
            close(hh)
            
            handles.tab_Reference_Alignment_index_for_plotting = 1;
            
            set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
            set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
            
            set(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'Backgroundcolor',[0.9294 0.6902 0.1294],'Tooltipstring','Accept data by preesing mouse right click and then accept data')
            set(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor',[0.94 0.94 0.94],'Tooltipstring','','Enable','on')

            
            tab_Reference_Alignment_Align_Ref_Signal_pb_UICntMn = uicontextmenu;
            handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton.UIContextMenu = tab_Reference_Alignment_Align_Ref_Signal_pb_UICntMn;
            m1 = uimenu(tab_Reference_Alignment_Align_Ref_Signal_pb_UICntMn,'Label','Accept data','Callback',{@Reference_Alignment_Align_Ref_Signal_pushbutton_cm,handles});
            
            set(handles.tab_Reference_Alignment_save_pushbutton,'Enable','on')
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Reference_Alignment_Align_Ref_Sig_undo_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            clear handles.data_new.data handles.data_new.ppm_mean
            
            subplot(1,1,1,'Parent',handles.tab_Reference_frame1);
            plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');
            set(gca,'xdir','rev');
            axis tight
            title('Raw Data')
            hold off
            
            handles.tab_Reference_Alignment_index_for_plotting = 0;
            
            set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
            set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
            
            set(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'Backgroundcolor',[0.94 0.94 0.94])
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Reference_Alignment_Align_Ref_Sig_options_pb_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            prompt = {'End ppm:','Start ppm:'};
            dlg_title = 'Reference Signal Regions';
            num_lines = 1;
            defaultans = {num2str(handles.sigma_plasma_options.refAlignment.region(1)),num2str(handles.sigma_plasma_options.refAlignment.region(2))};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            if isempty(answer)
                return
            else
                handles.sigma_plasma_options.refAlignment.region=[str2double(answer{1}) str2double(answer{2})];
            end
            
            set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
            set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end




% =======================================================================================================================


    function tab_Reference_Alignment_Pre_Align_Spectra_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        %         try
        
        %delete(handles.tab_Reference_frame1.Children)
        h = waitbar(0.5,'Please wait...');
        set(0, 'currentfigure', handles.f);
        
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            [handles.data_new.data, handles.shift_in_ppm] = sigma_pre_align_bkh(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options);
            
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            [handles.data_new.data, handles.shift_in_ppm] = sigma_pre_align_bkh(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options);
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1 || handles.tab_Reference_Alignment_index_for_plotting == 3
            [handles.data_new.data, handles.shift_in_ppm] = sigma_pre_align_bkh(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options);
        end
        
        %close(h)
        
        %             if handles.tab_Reference_Alignment_index_for_plotting == 1 || handles.tab_Reference_Alignment_index_for_plotting == 3
        ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
        
        ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        plot_bkh(handles.data.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %                  plot(handles.data.ppm_mean,handles.data.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 0
        %                 ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        %                 plot(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
        %
        %                 ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        %                 plot(handles.data.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %
        %             end
        linkaxes(ax2,'xy');
        
        
        %             if handles.tab_Reference_Alignment_index_for_plotting == 0
        %                 handles.tab_Reference_Alignment_index_for_plotting = 2;
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 1
        %                 handles.tab_Reference_Alignment_index_for_plotting = 3;
        %             end
        
        handles.tab_Reference_Alignment_index_for_plotting = 2;
        
        close(h)
        
        set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
        set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
        
        
        
        set(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'Backgroundcolor',[0.9294 0.6902 0.1294],'Tooltipstring','Accept data by preesing mouse right click and then accept data')
        
        tab_Reference_Alignment_Pre_Align_Spectra_pb_UICntMn = uicontextmenu;
        handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton.UIContextMenu = tab_Reference_Alignment_Pre_Align_Spectra_pb_UICntMn;
        m1 = uimenu(tab_Reference_Alignment_Pre_Align_Spectra_pb_UICntMn,'Label','Accept data','Callback',{@Reference_Alignment_Pre_Align_Spectra_pb_cm,handles});
        
        set(handles.tab_Reference_Alignment_save_pushbutton,'Enable','on')
        
        
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end





    function tab_Reference_Alignment_Pre_Align_undo_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            clear handles.data_new.data handles.shift_in_ppm
            delete(handles.tab_Reference_frame1.Children)
            subplot(1,1,1,'Parent',handles.tab_Reference_frame1);
            %             if handles.tab_Reference_Alignment_index_for_plotting == 3
            %                 handles.tab_Reference_Alignment_index_for_plotting = 1;
            % %                 plot(handles.data_new.ppm_mean,handles.data_new.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
            %                   plot(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
            %             elseif handles.tab_Reference_Alignment_index_for_plotting == 2
            %                 handles.tab_Reference_Alignment_index_for_plotting = 0;
            plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
            
            %             end
            
            set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
            set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
            set(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundCOlor',[0.94 0.94 0.94])
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Reference_Alignment_Pre_Align_options_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            temp = pre_aligned_data_options(handles.sigma_plasma_options.preAlignment);
            if isempty(temp)
                return
            else
                handles.sigma_plasma_options.preAlignment.max_allowed_ppm_shift = temp{1};
                handles.sigma_plasma_options.preAlignment.regions = temp{2};
            end
            
            set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
            set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Reference_Alignment_Intervals_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
        set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
        
        setappdata(0,'handles',handles)
    end






    function tab_Reference_Alignment_Show_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            reg=handles.sigma_plasma_options.preAlignment.regions;
            %             if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            %                 ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
            %                 plot(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
            %                 axis tight
            %                 hold on;
            %
            %                 ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
            %                 plot(handles.data.ppm_mean,handles.data_new.data,'k');
            %                 axis tight
            %                 hold on;
            %
            %
            %                 %                 plot_preAligned_intervals(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options )
            %
            %             elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
            tab_Reference_Alignment_Align_Ref_pb_val = get(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'BackgroundColor');
            tab_Reference_Alignment_Pre_Align_Spectra_pb_val = get(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor');
            
            if (tab_Reference_Alignment_Align_Ref_pb_val==[0.9294 0.6902 0.1294]) | (tab_Reference_Alignment_Pre_Align_Spectra_pb_val==[0.9294 0.6902 0.1294])
                ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
                axis tight
                hold on;
                
                ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data);
                axis tight
                hold on;
                
            else
                ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
                axis tight
                hold on;
                
                ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data.ppm_mean,handles.data.data);
                axis tight
                hold on;
                
            end
            
            
            % plot_preAligned_intervals(handles.data_new.data,handles.data.ppm_mean,handles.sigma_plasma_options )
            
            %             elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            %                 ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
            %                 plot(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
            %                 axis tight
            %                 hold on;
            %
            %                 ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
            %                 plot(handles.data_new.ppm_mean,handles.data_new.data,'k');
            %                 axis tight
            %                 hold on;
            %
            %                 % plot_preAligned_intervals(handles.data_new.data,handles.data_new.ppm_mean,handles.sigma_plasma_options )
            %
            %             elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            %                 ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
            %                 plot(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
            %                 axis tight
            %                 hold on;
            %
            %                 ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
            %                 plot(handles.data_new.ppm_mean,handles.data_new.data,'k');
            %                 axis tight
            %                 hold on;
            %
            %                 %plot_preAligned_intervals(handles.data_new.data,handles.data_new.ppm_mean,handles.sigma_plasma_options )
            %
            %             end
            linkaxes(ax2,'xy');
            
            set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data Intervals');
            
            
            
            subplot(2,1,2,'Parent',handles.tab_Reference_frame1)
            
            
            
            
            
            
            
            ColorSet=varycolor(size(reg,1));
            yy = get(gca,'ylim');
            y1 = yy(1);
            y2 = yy(2);
            
            for i=1:size(reg,1)
                
                if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                    msg='';
                    filled=[[y1 y1],fliplr([y2 y2])];
                    xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                    handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(i,:));%plot the data
                    set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(i,:),...
                        'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                    
                    %                     cont.(['i_raw' num2str(i)]) = uicontextmenu;
                    
                else
                    msg='Error: Must use the same number of points in each vector';
                end
                hold on
            end
            hold off
            
            
            
            
            %             for i=1:size(reg,1)
            %                 if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
            %                     handles.fillhandle.(['i_raw' num2str(i)]).UIContextMenu = cont.(['i_raw' num2str(i)]);
            %
            %                     m1 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
            %                     m2 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
            %                 end
            %             end
            %
            %             hold off
            
            %             handles.Intervals_ylim = get(handles.tab_Interval_Recognition_frame1.Children,'ylim');
            %             handles.Intervals_xlim = get(handles.tab_Interval_Recognition_frame1.Children,'xlim');
            %
            %             cont.('A') = uicontextmenu;
            %             handles.tab_Interval_Recognition_frame1.Children.UIContextMenu = cont.('A');
            %             m1 = uimenu(cont.('A'),'Label','Add new interval','Callback',{@Add_new_interval,handles,handles.Intervals_ylim,ColorSet});
            %
            %
            %             close(hh)
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
            set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Reference_Alignment_Hide_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            tab_Reference_Alignment_Align_Ref_pb_val = get(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'BackgroundColor');
            tab_Reference_Alignment_Pre_Align_Spectra_pb_val = get(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor');
            
            if (tab_Reference_Alignment_Align_Ref_pb_val==[0.9294 0.6902 0.1294]) | (tab_Reference_Alignment_Pre_Align_Spectra_pb_val==[0.9294 0.6902 0.1294])
                ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
                plot(0,0,'.w')
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
                
                
                ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
                plot(0,0,'.w')
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data');axis tight;
                
            else
                ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
                plot(0,0,'.w')
                plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
                
                
                ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
                plot(0,0,'.w')
                plot_bkh(handles.data.ppm_mean,handles.data.data);set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data');axis tight;
            end
            linkaxes(ax2,'xy');
            
            set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
            set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
            
%             set(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'BackgroundColor',[0.94 0.94 0.94],'Tooltipstring','')
%             set(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor',[0.94 0.94 0.94],'Tooltipstring','')
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Reference_Alignment_listbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
        
        tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        tab_Reference_Alignment_listbox_str = get(handles.tab_Reference_Alignment_listbox,'String');
        
        legend_name = {};
        for i = 1:length(tab_Reference_Alignment_listbox_val)
            legend_name(i) = tab_Reference_Alignment_listbox_str(tab_Reference_Alignment_listbox_val(i));
        end
        legend(legend_name)
        
        legend off
        
        delete(handles.tab_Reference_frame1.Children)
        
        
        
        if handles.tab_Reference_Alignment_index_for_plotting == 1
            
            val = get(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'BackgroundColor');
            if val == [0.9294    0.6902    0.1294]
                tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
                %tab_Reference_Alignment_listbox_str = get(handles.tab_Reference_Alignment_listbox,'String');
                
                
                ax1(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                title('Raw Data')
                hold off
                legend(legend_name)
                legend off
                
                ax1(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                title('Aligned data')
                hold off
                linkaxes(ax1,'xy');
                legend(legend_name)
                legend off
                
                
            elseif val == [0 1 0]
                tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
                
                ax1(1) = subplot(1,1,1,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                title('Refrence Aligned data')
                hold off
                legend(legend_name)
                legend off
                
            end
            
            
            
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2
            
            %[handles.data_new.data, handles.shift_in_ppm]
            
            val = get(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor');
            if val == [0.9294    0.6902    0.1294]
                tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
                %tab_Reference_Alignment_listbox_str = get(handles.tab_Reference_Alignment_listbox,'String');
                
                
                %                 ax1(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
                
                ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
                
                ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
                %                 plot(handles.data_new.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
                plot_bkh(handles.data.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:));set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
                
                
                %                 plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
                %                 set(gca,'xdir','rev');
                %                 axis tight
                %                 title('Raw Data')
                %                 hold off
                legend(legend_name)
                legend off
                
                %                 ax1(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
                %                 plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
                %                 set(gca,'xdir','rev');
                %                 axis tight
                %                 title('Aligned data')
                %                 hold off
                linkaxes(ax2,'xy');
                %                 legend(legend_name)
                %                 legend off
                
                
            elseif val == [0 1 0]
                tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
                
                ax1(1) = subplot(1,1,1,'Parent',handles.tab_Reference_frame1);
                plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:));set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
                
                %                 plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
                %                 set(gca,'xdir','rev');
                %                 axis tight
                %                 title('Refrence Aligned data')
                hold off
                legend(legend_name)
                legend off
                
            end
            
            
            
            
            
        end
        
        
        
        %             if handles.tab_Reference_Alignment_index_for_plotting == 0
        %
        %
        %
        %                 switch handles.tab_Import_Data_index_for_plotting
        %                     case 0
        %
        %                     case {1,2}
        %
        %                         if handles.tab_Import_Data_index_for_plotting == 1
        %                             p1b = 1;
        %                             p2b = length(handles.data_Reference_Alignment_ini.ppm_mean);
        %                         elseif handles.tab_Import_Data_index_for_plotting == 2
        %                             handles.data_Reference_Alignment_ini.data = handles.data_new.data;
        %
        %                             start_of_the_region_val = str2double(get(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'String'));
        %                             end_of_the_region_val = str2double(get(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'String'));
        %                             a1=abs(handles.data.ppm_mean-end_of_the_region_val); p1b=find(a1==min(a1));  if length(p1b)>1; p1b=p1b(1,1); end;
        %                             a1=abs(handles.data.ppm_mean-start_of_the_region_val); p2b=find(a1==min(a1));    if length(p2b)>1; p2b=p2b(1,1); end;
        %
        %                         end
        %
        %                         subplot(1,1,1,'Parent',handles.tab_Reference_frame1)
        %                         plot_bkh(handles.data_Reference_Alignment_ini.ppm_mean,handles.data_Reference_Alignment_ini.data(tab_Reference_Alignment_listbox_val,p1b:p2b)); xlabel('ppm');
        %                         set(gca,'xdir','rev');
        %                         axis tight
        %                         hold off
        %                         legend(legend_name)
        %                         legend off
        %                         tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
        %                         set(handles.tab_Reference_Alignment_listbox,'Value',tab_Import_Data_listbox_val);
        %                         legend off
        %                 end
        %
        %                 legend off
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 1
        %
        %                 tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %                 tab_Reference_Alignment_listbox_str = get(handles.tab_Reference_Alignment_listbox,'String');
        %
        %
        %                 ax1(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        %                 plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
        %                 set(gca,'xdir','rev');
        %                 axis tight
        %                 title('Raw Data')
        %                 hold off
        %                 legend(legend_name)
        %                 legend off
        %
        %                 ax1(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        %                 plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
        %                 set(gca,'xdir','rev');
        %                 axis tight
        %                 title('Aligned data')
        %                 hold off
        %                 linkaxes(ax1,'xy');
        %                 legend(legend_name)
        %                 legend off
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 2
        %                 tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %
        %                 ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        %                 plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
        %                 legend(legend_name)
        %                 legend off
        %
        %                 ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        %                 plot_bkh(handles.data.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:));set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %                 legend(legend_name)
        %                 linkaxes(ax2,'xy');
        %                 legend off
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 3
        %                 tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %                 ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        %                 plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
        %                 legend(legend_name)
        %                 legend off
        %
        %                 ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        %                 plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:));set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %                 legend(legend_name)
        %                 linkaxes(ax2,'xy');
        %                 legend off
        %             end
        
        
        set(handles.tab_Reference_Alignment_plot_type_popupmenu_str,'Visible','off')
        set(handles.tab_Reference_Alignment_plot_type_popupmenu,'Visible','off')
        legend off
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end






    function tab_Reference_Alignment_plot_type_popupmenu_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            syms axx
            tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
            
            tab_Reference_Alignment_plot_type_popupmenu_val = get(handles.tab_Reference_Alignment_plot_type_popupmenu,'Value');
            
            if size(handles.tab_Reference_Alignment_Align_current_plot,1) == 1
                switch tab_Reference_Alignment_plot_type_popupmenu_val
                    case 1
                        eval(handles.tab_Reference_Alignment_Align_current_plot{1,3})
                        eval(['plot_bkh(' handles.tab_Reference_Alignment_Align_current_plot{1,1} ',' handles.tab_Reference_Alignment_Align_current_plot{1,2} ');'])
                        for i = 5:size(handles.tab_Reference_Alignment_Align_current_plot,2)
                            eval(handles.tab_Reference_Alignment_Align_current_plot{1,i})
                        end
                    case 2
                        
                    case 3
                        
                end
            elseif size(handles.tab_Reference_Alignment_Align_current_plot,1) == 2
                switch tab_Reference_Alignment_plot_type_popupmenu_val
                    case 1
                        eval(handles.tab_Reference_Alignment_Align_current_plot{1,3})
                        eval(['plot_bkh(' handles.tab_Reference_Alignment_Align_current_plot{1,1} ',' handles.tab_Reference_Alignment_Align_current_plot{1,2} ');'])
                        for i = 5:size(handles.tab_Reference_Alignment_Align_current_plot,2)
                            eval(handles.tab_Reference_Alignment_Align_current_plot{1,i})
                        end
                        
                        eval(handles.tab_Reference_Alignment_Align_current_plot{2,3})
                        eval(['plot_bkh(' handles.tab_Reference_Alignment_Align_current_plot{2,1} ',' handles.tab_Reference_Alignment_Align_current_plot{2,2} ');'])
                        for i = 5:size(handles.tab_Reference_Alignment_Align_current_plot,2)
                            eval(handles.tab_Reference_Alignment_Align_current_plot{2,i})
                        end
                        
                    case 2
                        
                    case 3
                        
                end
                
            end
            
            
            
            switch handles.tab_Reference_Alignment_index_for_plotting
                case 0
                    
                case 1
                    
                case 2
                    
                case 3
                    
            end
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end



    function tab_Reference_Alignment_save_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            %            if handles.tab_Reference_Alignment_index_for_plotting==0
            %           text1=['Choose data: '];
            %             reply = inputdlg([text1,' type 1 to save Just Imported Raw and 2 for processed data' ]);
            %             if str2num(cell2mat(reply))==1;
            %                 dname = uigetdir;
            %                 RawData=handles.data_ini;
            %                 save([dname '\' 'RawData'], 'RawData');
            %                 clear RawData
            %             elseif str2num(cell2mat(reply))==2;
            %                 dname = uigetdir;
            %                 ProcessedData=handles.data;
            %                 save([dname '\' 'ProcessedData'], 'ProcessedData');
            %                 clear ProcessedData
            %             end;
            %
            %            elseif handles.tab_Reference_Alignment_index_for_plotting==1
            %
            %                 dname = uigetdir;
            %                 ReferenceAlignedData.data_new.data=handles.data_new.data;
            %                 ReferenceAlignedData.x_ref_align_ppm=handles.data_new.ppm_mean;
            %                 save([dname '\' 'ReferenceAlignedData'], 'ReferenceAlignedData');
            %                 clear ReferenceAlignedData
            %
            %            elseif handles.tab_Reference_Alignment_index_for_plotting==2
            %
            %                dname = uigetdir;
            %                 PreAlignedData.x_pre_align=handles.data_new.data;
            %                 PreAlignedData.x_ref_align_ppm=handles.data_new.ppm_mean;
            %                 save([dname '\' 'PreAlignedData'], 'PreAlignedData');
            %                 clear PreAlignedData
            %
            %             elseif handles.tab_Reference_Alignment_index_for_plotting==3
            %
            %                dname = uigetdir;
            %                 ReferenceAlignedData.data_new.data=handles.data_new.data;
            %                 ReferenceAlignedData.x_ref_align_ppm=handles.data_new.ppm_mean;
            %                 save([dname '\' 'ReferenceAlignedData'], 'ReferenceAlignedData');
            %                 clear ReferenceAlignedData
            %                 PreAlignedData.x_pre_align=handles.data_new.data;
            %                 PreAlignedData.x_ref_align_ppm=handles.data_new.ppm_mean;
            %                 save([dname '\' 'PreAlignedData'], 'PreAlignedData');
            %                 clear PreAlignedData
            %            end
            
            text1=['Choose data: '];
            reply = inputdlg([text1,' type 1 to save Just Imported Raw and 2 for processed data' ]);
            if str2num(cell2mat(reply))==1;
                dname = uigetdir;
                options=handles.sigma_plasma_options;
                save([dname '\' 'options'], 'options');
                clear options
                RawData=handles.data;
                save([dname '\' 'RawData'], 'RawData');
                clear RawData
            elseif str2num(cell2mat(reply))==2;
                dname = uigetdir;
                options=handles.sigma_plasma_options;
                save([dname '\' 'options'], 'options');
                clear options
                ProcessedData=handles.data_new;
                save([dname '\' 'ProcessedData'], 'ProcessedData');
                clear ProcessedData
            end;
            
            
        catch e
            errordlg(e.message)
        end
        setappdata(0,'handles',handles)
    end






% =============================================================================================================================
% Interval Recognition
% =============================================================================================================================

[handles.h1_tab_Interval_Recognition,handles.h2_tab_Interval_Recognition,handles.hDivider1_tab_Interval_Recognition] = uisplitpane(handles.tab_Interval_Recognition);
set(handles.hDivider1_tab_Interval_Recognition,'DividerColor','green')
handles.hDivider1_tab_Interval_Recognition.DividerLocation = 0.15;

[handles.h3_tab_Interval_Recognition,handles.h4_tab_Interval_Recognition,handles.hDivider2_tab_Interval_Recognition] = uisplitpane(handles.h2_tab_Interval_Recognition,'Orientation','ver');
set(handles.hDivider2_tab_Interval_Recognition,'DividerColor','green')
handles.hDivider2_tab_Interval_Recognition.DividerLocation = 0.5;


handles.tab_Interval_Recognition_frame1 = uipanel('Parent', handles.h4_tab_Interval_Recognition, 'Position',[.000001 .0000001 .999 .999]);



handles.tab_Interval_Recognition_Identify_Intervals_uipanel = uipanel('Parent', handles.h1_tab_Interval_Recognition, 'Position',[.01 .805 .98 .19],'Title','','Visible','on');

handles.tab_Interval_Recognition_Identify_Intervals_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_Identify_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Identify Intervals','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Recognition_Identify_Intervals_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 74 166 30]) ;

handles.tab_Interval_Recognition_undo_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_Identify_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Undo','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Recognition_undo_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [50 37 70 30]) ;

handles.tab_Interval_Recognition_options_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_Identify_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Options','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Recognition_options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [41 2 90 30]) ;



handles.tab_Interval_Recognition_Intervals_uipanel = uipanel('Parent', handles.h1_tab_Interval_Recognition, 'Position',[.01 .71 .98 .09],'Title','Intervals','Visible','on');

% handles.tab_Interval_Recognition_Intervals_pushbutton = uicontrol('Parent',handles.h1_tab_Interval_Recognition, 'Style', 'pushbutton','FontWeight','bold', 'String',...
%     'Intervals','FontSize',10,'FontWeight','bold','Enable','off','Callback',{@tab_Interval_Recognition_Intervals_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [20 440 140 30]) ;

handles.tab_Interval_Recognition_Show_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Show','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Recognition_Show_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [20 5 70 30]) ;

handles.tab_Interval_Recognition_Hide_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Hide','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Recognition_Hide_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [90 5 70 30]) ;




handles.tab_Interval_Recognition_table_str = uicontrol('Parent', handles.h3_tab_Interval_Recognition, 'Style', 'text', 'String',...
    'Intervals Table:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [10 258 90 20]) ;

% data = [(1:length(handles.sigma_plasma_options.intervals_class))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded];
%
% handles.Intervals_Selected_intervals_uitable = uitable('Parent',handles.h3_tab_Interval_Recognition,'Data',data,'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0'},'RowName',handles.sigma_plasma_options.intervals_name,...
%     'CellEditCallback',{@Interval_Recognition_uitable_CellEditCallback,handles},'Position', [100 2 830 280],'ColumnEditable',[false false true true true],'BackgroundColor',[.4 .4 .4; .4 .4 .8],'ForegroundColor', [1 1 1]);

handles.Intervals_Selected_intervals_uitable = uitable('Parent',handles.h3_tab_Interval_Recognition,'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0'},...
    'CellEditCallback',{@Interval_Recognition_uitable_CellEditCallback,handles},'Position', [100 2 830 280],'ColumnEditable',[false false true true true],'BackgroundColor',[.4 .4 .4; .4 .4 .8],'ForegroundColor', [1 1 1]);
% handles.Intervals_Selected_intervals_uitable = uitable('Parent',handles.h3_tab_Interval_Recognition,'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0'},'RowName',handles.sigma_plasma_options.intervals_name,...
%     'CellEditCallback',{@Interval_Recognition_uitable_CellEditCallback,handles},'Position', [100 2 830 280],'ColumnEditable',[false false true true true],'BackgroundColor',[.4 .4 .4; .4 .4 .8],'ForegroundColor', [1 1 1]);



handles.tab_Interval_Recognition_class1_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Recognition, 'Style', 'checkbox', 'String',...
    'Class 1','FontSize',8,'ForegroundColor',handles.ColorSet(1,:),'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Recognition_class1_checkbox_Callback,handles}, 'Position', [937 180 60 20]) ;

handles.tab_Interval_Recognition_class2_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Recognition, 'Style', 'checkbox', 'String',...
    'Class 2','FontSize',8,'ForegroundColor',handles.ColorSet(2,:),'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Recognition_class2_checkbox_Callback,handles}, 'Position', [937 130 60 20]) ;

handles.tab_Interval_Recognition_class3_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Recognition, 'Style', 'checkbox', 'String',...
    'Class 3','FontSize',8,'ForegroundColor',handles.ColorSet(3,:),'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Recognition_class3_checkbox_Callback,handles}, 'Position', [937 80 60 20]) ;







handles.tab_Interval_Recognition_Identify_Intervals_listbox_str = uicontrol('Parent', handles.h1_tab_Interval_Recognition, 'Style', 'text', 'String',...
    'Recognized intervals:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 393 120 25]) ;

handles.tab_Interval_Recognition_Identify_Intervals_listbox = uicontrol('Parent', handles.h1_tab_Interval_Recognition, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [5 330 170 70],'Visible','off') ;










handles.tab_Interval_Recognition_validation_uipanel = uipanel('Parent', handles.h1_tab_Interval_Recognition, 'Position',[.005 .117 .99 .43],'FontWeight','bold','FontSize',11,'Title','Validation','Visible','on');

handles.tab_Interval_Recognition_Import_Bruker_Data_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Import Bruker Data ','Callback',{@tab_Interval_Recognition_Import_Bruker_Data_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [13 205 150 30]) ;

handles.tab_Interval_Recognition_Import_MATLAB_Data_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Import MATLAB Data ','Callback',{@tab_Interval_Recognition_Import_MATLAB_Data_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [13 170 150 30]) ;






handles.tab_Interval_Recognition_validation_uipanel_listbox_str = uicontrol('Parent', handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'text', 'String',...
    'Data:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [3 137 70 25]) ;

handles.tab_Interval_Recognition_validation_uipanel_listbox = uicontrol('Parent', handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [3 32 82 110],'Visible','off','Callback',{@tab_Interval_Recognition_validation_uipanel_listbox_Callback,handles}) ;


handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data_str = uicontrol('Parent', handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'text', 'String',...
    'Ref. Data:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [85 137 70 25]) ;

handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data = uicontrol('Parent', handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [86 32 82 110],'Visible','off','Callback',{@tab_Interval_Recognition_val_uipanel_lsb_real_data_Callback,handles}) ;




handles.tab_Interval_Recognition_validation_uipanel_Show_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Show','FontSize',10,'FontWeight','bold','Visible','off','Callback',{@tab_Interval_Recognition_validation_uipanel_Show_pb_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [15 2 70 25]) ;

handles.tab_Interval_Recognition_validation_uipanel_Hide_pushbutton = uicontrol('Parent',handles.tab_Interval_Recognition_validation_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Hide','FontSize',10,'FontWeight','bold','Visible','off','Callback',{@tab_Interval_Recognition_validation_uipanel_Hide_pb_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [90 2 70 25]) ;




handles.tab_Interval_Recognition_Evaluate_Intervals_pb = uicontrol('Parent',handles.h1_tab_Interval_Recognition, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Evaluate Intervals','FontSize',10,'Enable','off','FontWeight','bold','Callback',{@tab_Interval_Recognition_Evaluate_Intervals_pb_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [10 35 150 30]) ;


handles.tab_Interval_Recognition_save_pushbutton = uicontrol('Parent',handles.h1_tab_Interval_Recognition, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Save','Enable','off','Callback',{@tab_Interval_Recognition_save_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [45 2 80 30]) ;


% handles.tab_Interval_Recognition_Experimental_spectrum_pb = uicontrol('Parent',handles.h1_tab_Interval_Recognition, 'Style', 'pushbutton','FontWeight','bold', 'String',...
%     'Experimental spectrum','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Recognition_Experimental_spectrum_pb_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [5 20 170 30]) ;


handles.tab_Interval_Recognition_index_for_plotting = 0;

handles.tab_Interval_Recognition_Identify_Intervals_pushbutton_counter = 0;


    function tab_Interval_Recognition_Identify_Intervals_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
        
        [handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);
        
        handles = sigma_ss_mapping_bkh(handles);
        
        
        handles.tab_Interval_Recognition_index_for_plotting = 1;
        
        hh = waitbar(0.5,'Please wait...');
        set(0, 'currentfigure', handles.f);
        
        handles.tab_Interval_Recognition_Identify_Intervals_pushbutton_counter = handles.tab_Interval_Recognition_Identify_Intervals_pushbutton_counter + 1;
        if handles.tab_Interval_Recognition_Identify_Intervals_pushbutton_counter == 1
            handles.sigma_plasma_options_for_Interval_Recognition_undo_pb = handles.sigma_plasma_options;
        end
        %             if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
        [ handles.sigma_plasma_options_new ] = sigma_interval_recognition_bkh(handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options);
        
        ss_corr=mean(handles.out_ss_map.ss_corr,2);
        %             elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
        %
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 1
        %                 [ handles.sigma_plasma_options ] = sigma_interval_recognition_bkh(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options );
        %
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
        %                 [ handles.sigma_plasma_options ] = sigma_interval_recognition_bkh(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options );
        %
        %             end
        
        m0=[num2str(size(handles.sigma_plasma_options_new.intervals_class,1)) ' intervals are recognized'];
        m1=[num2str(size(find(handles.sigma_plasma_options_new.intervals_class==1),1)) ' SS of metabolites (Class 1)'];
        m2=[num2str(size(find(handles.sigma_plasma_options_new.intervals_class==2),1)) ' SUS of unknowns (Class 2)'];
        m3=[num2str(size(find(handles.sigma_plasma_options_new.intervals_class==3),1)) ' BINS (Class 3)'];
        
        set(handles.tab_Interval_Recognition_Identify_Intervals_listbox,'String',{m0;m1; m2;m3})
        
        set(handles.tab_Interval_Recognition_Identify_Intervals_listbox_str,'Visible','on')
        set(handles.tab_Interval_Recognition_Identify_Intervals_listbox,'Visible','on')
        
        
        [f1 f2 ]=size(handles.sigma_plasma_options_new.intervals_ppm);
        f3=abs(f1-length(ss_corr));
        ss_corr_all=cat(1,ss_corr,zeros(f3,1));
        shift_per_sample_per_int=range(handles.out_ss_map.shift_per_sample_per_int,2);
        shift_per_sample_per_int_all=cat(1,shift_per_sample_per_int,zeros(f3,1));
        
        hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
        data = [(1:length(handles.sigma_plasma_options_new.intervals_name))' handles.sigma_plasma_options_new.intervals_class ...
            handles.sigma_plasma_options_new.intervals_ppm handles.sigma_plasma_options_new.VariablesIncluded ...
            handles.sigma_plasma_options_new.intervals_ppm_flex ss_corr_all shift_per_sample_per_int_all hihi_index];
        kk = ~isnan(data(:,3));
        kk2 = data(kk,:);
        kk2 = sortrows(kk2,2);
        unique_kk2 = unique(kk2(:,2));
        kk4 = [];
        for ii3 = 1:length(unique_kk2)
            unique_1 = (kk2(:,2) == unique_kk2(ii3));
            kk3 = sortrows(kk2(unique_1,:),3);
            kk4 = [kk4 ; kk3];
        end
        
 %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
 hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end

        kk4 = [(1:size(kk4,1))' kk4(:,[2:5 8:9])];  
        
        set(handles.Intervals_Selected_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options_new.intervals_name, ...
            'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0', 'SS Mapping Score' 'Shift'});

% 
%         rowName={'<font color=''white'' bgcolor="rgb(0,0,255)">Thing1</font>',...
%             '<font color=''white'' bgcolor="rgb(255,0,0)">Thing2</font>',...
%             '<font color=''white'' bgcolor="rgb(0,255,0)">Thing3</font>'};
%         set(handles.Intervals_Selected_intervals_uitable,'RowName',rowName)



% % % styleIndices = ismissing(data);
% % % [row,col] = find(styleIndices);
% % % 
% % % s = uistyle('BackgroundColor','yellow');
% % % addStyle(uit,s,'cell',[row,col]);
% % % 
% % % s3 = uistyle;
% % % s3.BackgroundColor = 'red';
% % % addStyle(handles.Intervals_Selected_intervals_uitable,s3,'row',[3 4])
% addStyle(handles.Intervals_Selected_intervals_uitable,s1,'column',7)
        
        
        set(handles.tab_Interval_Alignment_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options_new.intervals_name, ...
            'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0', 'SS Mapping Score' 'Shift'})
        
        close(hh)
        
        set(handles.tab_Interval_Recognition_Identify_Intervals_pushbutton,'Backgroundcolor',[0.9294 0.6902 0.1294],'Tooltipstring','Accept data by preesing mouse right click and then accept data')
        
        tab_Interval_Recognition_Identify_Intervals_pb_UICntMn = uicontextmenu;
        handles.tab_Interval_Recognition_Identify_Intervals_pushbutton.UIContextMenu = tab_Interval_Recognition_Identify_Intervals_pb_UICntMn;
        m1 = uimenu(tab_Interval_Recognition_Identify_Intervals_pb_UICntMn,'Label','Accept data','Callback',{@Interval_Recognition_Identify_Intervals_pb_cm,handles});
        
        set(handles.tab_Interval_Recognition_save_pushbutton,'Enable','on')
        
        
        
        set(handles.tab_Interval_Recognition_Evaluate_Intervals_pb,'Enable','on')
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_undo_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        handles.tab_Interval_Recognition_Identify_Intervals_pushbutton_counter = 0;
        handles.sigma_plasma_options = handles.sigma_plasma_options_for_Interval_Recognition_undo_pb;
        
        
        
        hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
        data = [(1:length(handles.sigma_plasma_options.intervals_name))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded handles.sigma_plasma_options.intervals_ppm_flex hihi_index];
        kk = ~isnan(data(:,3));
        kk2 = data(kk,:);
        kk2 = sortrows(kk2,2);
        unique_kk2 = unique(kk2(:,2));
        kk4 = [];
        for ii3 = 1:length(unique_kk2)
            unique_1 = (kk2(:,2) == unique_kk2(ii3));
            kk3 = sortrows(kk2(unique_1,:),3);
            kk4 = [kk4 ; kk3];
        end
        
 %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
 hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end

        kk4 = [(1:size(kk4,1))' kk4(:,2:5)];
        
        
            
        set(handles.Intervals_Selected_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options.intervals_name)
        
        set(handles.tab_Interval_Alignment_intervals_uitable,'Data',kk4,'RowName',handles.sigma_plasma_options.intervals_name)
        
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            if handles.tab_Reference_Alignment_index_for_plotting == 2
                plot_bkh(handles.data.ppm_mean,handles.data.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
            elseif handles.tab_Reference_Alignment_index_for_plotting == 3
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            end
            
        end
        
        set(handles.tab_Interval_Recognition_Identify_Intervals_listbox,'String',[])
        set(handles.tab_Interval_Recognition_Identify_Intervals_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_options_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %try
        color = get(handles.tab_Interval_Recognition_Identify_Intervals_pushbutton,'BackgroundColor');
        if color == [0.9294 0.6902 0.1294]
            output = tab_Interval_Recognition_Identified_intervals(handles.sigma_plasma_options_new);

            if isempty(output)
                return
            end
            
             handles.sigma_plasma_options_new=output{6};


            hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
            data = [(1:length(handles.sigma_plasma_options_new.intervals_name))' ...
                handles.sigma_plasma_options_new.intervals_class ...
                handles.sigma_plasma_options_new.intervals_ppm ...
                handles.sigma_plasma_options_new.VariablesIncluded ...
                handles.sigma_plasma_options_new.intervals_ppm_flex hihi_index];
            kk = ~isnan(data(:,3));
            kk2 = data(kk,:);
            kk2 = sortrows(kk2,2);
            unique_kk2 = unique(kk2(:,2));
            kk4 = [];
            for ii3 = 1:length(unique_kk2)
                unique_1 = (kk2(:,2) == unique_kk2(ii3));
                kk3 = sortrows(kk2(unique_1,:),3);
                kk4 = [kk4 ; kk3];
            end

 %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
 hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end

            kk4 = [(1:size(kk4,1))' kk4(:,2:5)];


            data = [(1:length(handles.sigma_plasma_options_new.intervals_name))' ...
                handles.sigma_plasma_options_new.intervals_class ...
                handles.sigma_plasma_options_new.intervals_ppm ...
                handles.sigma_plasma_options_new.VariablesIncluded ...
                handles.sigma_plasma_options_new.intervals_ppm_flex];
            



           
            set(handles.Intervals_Selected_intervals_uitable,'Data',data,'RowName',handles.sigma_plasma_options_new.intervals_name,...
                'CellEditCallback',{@Interval_Recognition_uitable_CellEditCallback,handles});


            handles.sigma_plasma_options_new.automatic_interval_selection.status = output{2}(1);
            handles.sigma_plasma_options_new.automatic_interval_selection.mode = output{2}(2);
            handles.sigma_plasma_options_new.automatic_interval_selection.std_value = output{2}(3);
            handles.sigma_plasma_options_new.automatic_interval_selection.peak_width = output{2}(4);
            handles.sigma_plasma_options_new.automatic_interval_selection.space_between_two_intervals = output{2}(5);

            handles.sigma_plasma_options_new.should_left_out_ppm_regions_be_included.status = output{3}(1);
            handles.sigma_plasma_options_new.should_left_out_ppm_regions_be_included.min_ppm = output{3}(2);


        else


            output = tab_Interval_Recognition_Identified_intervals(handles.sigma_plasma_options);

            if isempty(output)
                return
            end
            handles.sigma_plasma_options=output{6};
%             handles.sigma_plasma_options.intervals_class = output{1}(:,1);
%             handles.sigma_plasma_options.intervals_ppm = output{1}(:,2:3);
%             handles.sigma_plasma_options.VariablesIncluded = output{1}(:,4);
%             handles.sigma_plasma_options.intervals_name = output{4};
%             handles.sigma_plasma_options.intervals_ppm_flex = output{5};




            %             data = [ (1:length(handles.sigma_plasma_options.intervals_name))' handles.sigma_plasma_options.intervals_class ...
            %                 handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded ...
            %                 handles.sigma_plasma_options.intervals_ppm_flex];
            hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
            data = [(1:length(handles.sigma_plasma_options.intervals_name))' ...
               handles.sigma_plasma_options.intervals_class ...
                handles.sigma_plasma_options.intervals_ppm ...
                handles.sigma_plasma_options.VariablesIncluded ...
                handles.sigma_plasma_options.intervals_ppm_flex hihi_index];

            kk = ~isnan(data(:,3));
            kk2 = data(kk,:);
            kk2 = sortrows(kk2,2);
            unique_kk2 = unique(kk2(:,2));
            kk4 = [];
            for ii3 = 1:length(unique_kk2)
                unique_1 = (kk2(:,2) == unique_kk2(ii3));
                kk3 = sortrows(kk2(unique_1,:),3);
                kk4 = [kk4 ; kk3];
            end

 %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
 hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end

            kk4 = [(1:size(kk4,1))' kk4(:,2:5)];




            
            set(handles.Intervals_Selected_intervals_uitable,'Data',data,'RowName',handles.sigma_plasma_options.intervals_name,...
                'CellEditCallback',{@Interval_Recognition_uitable_CellEditCallback,handles});

            handles.sigma_plasma_options.automatic_interval_selection.status = output{2}(1);
            handles.sigma_plasma_options.automatic_interval_selection.mode = output{2}(2);
            handles.sigma_plasma_options.automatic_interval_selection.std_value = output{2}(3);
            handles.sigma_plasma_options.automatic_interval_selection.peak_width = output{2}(4);
            handles.sigma_plasma_options.automatic_interval_selection.space_between_two_intervals = output{2}(5);

            handles.sigma_plasma_options.should_left_out_ppm_regions_be_included.status = output{3}(1);
            handles.sigma_plasma_options.should_left_out_ppm_regions_be_included.min_ppm = output{3}(2);

        end



        assignin('base','output',output)

        %         catch e
        %             errordlg(e.message)
        %         end

        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_Intervals_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Recognition_Show_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            hh = waitbar(0.5,'Please wait...');
            
            set(0, 'currentfigure', handles.f);
            
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            
            reg = plot_selected_intervals2(handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options);
            handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
            
            
            reg = handles.sigma_plasma_options.intervals_ppm;
            handles.tab_Interval_Recognition_Show_reg = reg;
            
            ColorSet=handles.ColorSet;
            
            class1_val = get(handles.tab_Interval_Recognition_class1_checkbox,'Value');
            class2_val = get(handles.tab_Interval_Recognition_class2_checkbox,'Value');
            class3_val = get(handles.tab_Interval_Recognition_class3_checkbox,'Value');
            class_val = [class1_val class2_val class3_val];
            
            
            % classes_size
            temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
            classe1_size = length(temp1);
            temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
            classe2_size = length(temp1);
            temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
            classe3_size = length(temp1);
            classes_size = [classe1_size classe2_size classe3_size];
            
            reg3 = reg;
            reg4 = {};
            for ii = 1:3
                if class_val(ii) == 1
                    reg4(ii) = {reg3(1:classes_size(ii),:)};
                    reg3(1:classes_size(ii),:) = [];
                else
                    reg4(ii) = {[]};
                    reg3(1:classes_size(ii),:) = [];
                end
            end
            
            reg5 = [];
            for ii = 1:3
                if isempty(reg4{ii})
                    reg5 = [reg5 ; nan(classes_size(ii),2)];
                else
                    reg5 = [reg5 ; reg4{ii}];
                end
            end
            reg = reg5;
            
            
            
            set(0, 'currentfigure', handles.f);
            hold on
            subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            yy = get(gca,'ylim');
            y1 = yy(1);
            y2 = yy(2);
            
            text_y_location = 0;
            
            for i=1:size(reg,1)
                if ~isnan(reg(i))
                    if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                        if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                            msg='';
                            filled=[[y1 y1],fliplr([y2 y2])];
                            xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                            handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                            set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                                'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                            
                            cont.(['i_raw' num2str(i)]) = uicontextmenu;
                            text(mean(reg(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                        else
                            msg='Error: Must use the same number of points in each vector';
                        end
                        hold on
                    end
                end
            end
            hold off
            
            for i=1:size(reg,1)
                if ~isnan(reg(i))
                    if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                        if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                            handles.fillhandle.(['i_raw' num2str(i)]).UIContextMenu = cont.(['i_raw' num2str(i)]);
                            
                            m1 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
                            m2 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
                        end
                    end
                end
            end
            
            hold off
            
            handles.Intervals_ylim = get(handles.tab_Interval_Recognition_frame1.Children,'ylim');
            handles.Intervals_xlim = get(handles.tab_Interval_Recognition_frame1.Children,'xlim');
            
            cont.('A') = uicontextmenu;
            handles.tab_Interval_Recognition_frame1.Children.UIContextMenu = cont.('A');
            m1 = uimenu(cont.('A'),'Label','Add new interval','Callback',{@Add_new_interval,handles,handles.Intervals_ylim,ColorSet});
            
            
            close(hh)
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end







    function tab_Interval_Recognition_Hide_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            try
                delete(handles.fillhandle)
            end
            try
                delete(handles.him)
            end
            
            %             plot_bkh(handles.data_new.ppm_mean ,handles.data_new.data); set(gca,'xdir','rev'); xlabel('ppm'); title('Pre-Aligned Data');
            plot_bkh(handles.data.ppm_mean ,handles.data.data); set(gca,'xdir','rev'); xlabel('ppm'); title('Pre-Aligned Data');
            
            axis tight
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Recognition_listbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Recognition_plot_type_popupmenu_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Recognition_Experimental_spectrum_pb_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_Import_Bruker_Data_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            
            GUI_dir = cd;
            cd ..
            temp_dir = cd;
            
            addpath(genpath([temp_dir '\m files of sigma']))
            dname = uigetdir;
            h = waitbar(0.5,'Please wait...');
            
            [handles.data_for_Interval_Recognition_tab,handles.sample_AcqPars_for_Interval_Recognition_tab,handles.sample_ProcPars_for_Interval_Recognition_tab]=import_processed_bruker_nmr_data_bkh(dname);
            close(h)
            
            cd(GUI_dir)
            
            
            set(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'String',handles.sample_AcqPars_for_Interval_Recognition_tab.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox_str,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data_str,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_Show_pushbutton,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_Hide_pushbutton,'Visible','on')
            
            set(handles.tab_Interval_Recognition_Import_Bruker_Data_pushbutton,'BackgroundColor',[0 1 0])
            set(handles.tab_Interval_Recognition_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
        catch e
            try
                close(h)
            end
            errordlg(e.message)
            
        end
        
        setappdata(0,'handles',handles)
    end




    function tab_Interval_Recognition_Import_MATLAB_Data_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        try
            
            [filename, pathname] = uigetfile( {'*.mat','MATLAB Files (*.mat)'; '*.*',  'All Files (*.*)'}, 'Pick a file');
            
            nmrdata_temp = load([pathname filename]);
            ff2 = fieldnames(nmrdata_temp);
            nmrdata = nmrdata_temp.(ff2{1});
            h = waitbar(0.5,'Please wait...');
            
            [handles.data_for_Interval_Recognition_tab,handles.sample_AcqPars_for_Interval_Recognition_tab,handles.sample_ProcPars_for_Interval_Recognition_tab] = import_processed_matlab_nmr_data_bkh(nmrdata);
            close(h)
            handles.sample_AcqPars.sample_AcqPars_Title = handles.data.subjects;
          
            
            set(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'String',handles.sample_AcqPars_for_Interval_Recognition_tab.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox_str,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data_str,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_Show_pushbutton,'Visible','on')
            set(handles.tab_Interval_Recognition_validation_uipanel_Hide_pushbutton,'Visible','on')
            
            set(handles.tab_Interval_Recognition_Import_Bruker_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            set(handles.tab_Interval_Recognition_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0 1 0])
            
        catch e
            try
                close(h)
            end
            errordlg(e.message)
            
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Recognition_validation_uipanel_Show_pb_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
        
        hh = waitbar(0.5,'Please wait...');
        try
            delete(handles.fillhandle)
        end
        try
            delete(handles.him)
        end
        
        set(0, 'currentfigure', handles.f);
        hold on
        %             if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
        %                 ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        %                 reg = plot_selected_intervals2(handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options );
        %                 handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
        %
        %             elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
        %                 ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        %
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 1
        %                 ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        %                 reg = plot_selected_intervals2(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options);
        %                 handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
        %                 ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        %                 reg = plot_selected_intervals2(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options);
        %
        %                 handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
        %             end
        reg = handles.sigma_plasma_options.intervals_ppm;
        ColorSet=varycolor(size(reg,1));
        
        %resetplotview(gca,'InitializeCurrentView');
        
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        
        for i=1:size(reg,1)
            
            if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                msg='';
                filled=[[y1 y1],fliplr([y2 y2])];
                xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(i,:));%plot the data
                set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(i,:),...
                    'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                
                cont.(['i_raw' num2str(i)]) = uicontextmenu;
                
            else
                msg='Error: Must use the same number of points in each vector';
            end
            hold on
        end
        hold off
        
        for i=1:size(reg,1)
            if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                handles.fillhandle.(['i_raw' num2str(i)]).UIContextMenu = cont.(['i_raw' num2str(i)]);
                
                m1 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals_for_validation,handles,i,[y1 y2],ColorSet});
                m2 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
            end
        end
        
        hold off
        
        %             handles.Intervals_ylim = get(handles.tab_Interval_Recognition_frame1.Children,'ylim');
        %             handles.Intervals_xlim = get(handles.tab_Interval_Recognition_frame1.Children,'xlim');
        %
        %             cont.('A') = uicontextmenu;
        %             handles.tab_Interval_Recognition_frame1.Children.UIContextMenu = cont.('A');
        %             m1 = uimenu(cont.('A'),'Label','Add new interval','Callback',{@Add_new_interval,handles,handles.Intervals_ylim,ColorSet});
        
        legend(handles.legend_name_for_Interval_Recognition_tab)
        close(hh)
        
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Recognition_validation_uipanel_Hide_pb_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            hh = waitbar(0.5,'Please wait...');
            try
                delete(handles.fillhandle)
            end
            try
                delete(handles.him)
            end
            
            set(0, 'currentfigure', handles.f);
            
            tab_Import_Data_listbox_str = get(handles.tab_Interval_Recognition_validation_uipanel_listbox,'String');
            legend_name = {};
            tab_Interval_Recognition_validation_uipanel_listbox_val = get(handles.tab_Interval_Recognition_validation_uipanel_listbox,'Value');
            if ~isempty(tab_Interval_Recognition_validation_uipanel_listbox_val)
                subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1)
                plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Interval_Recognition_validation_uipanel_listbox_val,:),'k'); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                hold on
                
                %legend_name = {};
                for i = 1:length(tab_Interval_Recognition_validation_uipanel_listbox_val)
                    legend_name = [legend_name ;tab_Import_Data_listbox_str(tab_Interval_Recognition_validation_uipanel_listbox_val(i))];
                end
                %legend(legend_name)
                
            end
            
            
            
            tab_Import_Data_listbox_str_for_Interval_Recognition_tab = get(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'String');
            tab_Interval_Recognition_val_uipanel_lsb_real_data_val = get(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'Value');
            if ~isempty(tab_Interval_Recognition_val_uipanel_lsb_real_data_val)
                subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1)
                plot_bkh(handles.data_for_Interval_Recognition_tab.ppm_mean,handles.data_for_Interval_Recognition_tab.data(tab_Interval_Recognition_val_uipanel_lsb_real_data_val,:),'LineWidth',2); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                hold off
                
                %legend_name = {};
                for i = 1:length(tab_Interval_Recognition_val_uipanel_lsb_real_data_val)
                    legend_name = [legend_name ; tab_Import_Data_listbox_str_for_Interval_Recognition_tab(tab_Interval_Recognition_val_uipanel_lsb_real_data_val(i))];
                end
                %legend(legend_name)
                
            end
            legend(legend_name)
            handles.legend_name_for_Interval_Recognition_tab = legend_name;
            close(hh)
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_validation_uipanel_listbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
        hh = waitbar(0.5,'Please wait...');
        try
            delete(handles.fillhandle)
        end
        try
            delete(handles.him)
        end
        set(0, 'currentfigure', handles.f);
        
        tab_Import_Data_listbox_str = get(handles.tab_Interval_Recognition_validation_uipanel_listbox,'String');
        legend_name = {};
        tab_Interval_Recognition_validation_uipanel_listbox_val = get(handles.tab_Interval_Recognition_validation_uipanel_listbox,'Value');
        if ~isempty(tab_Interval_Recognition_validation_uipanel_listbox_val)
            subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1)
            plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Interval_Recognition_validation_uipanel_listbox_val,:)); xlabel('ppm');
            set(gca,'xdir','rev');
            axis tight
            hold on
            
            %legend_name = {};
            for i = 1:length(tab_Interval_Recognition_validation_uipanel_listbox_val)
                legend_name = [legend_name ;tab_Import_Data_listbox_str(tab_Interval_Recognition_validation_uipanel_listbox_val(i))];
            end
            %legend(legend_name)
            
        end
        
        
        
        tab_Import_Data_listbox_str_for_Interval_Recognition_tab = get(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'String');
        tab_Interval_Recognition_val_uipanel_lsb_real_data_val = get(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'Value');
        if ~isempty(tab_Interval_Recognition_val_uipanel_lsb_real_data_val)
            subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1)
            plot_bkh(handles.data_for_Interval_Recognition_tab.ppm_mean,handles.data_for_Interval_Recognition_tab.data(tab_Interval_Recognition_val_uipanel_lsb_real_data_val,:)); xlabel('ppm');
            set(gca,'xdir','rev');
            axis tight
            hold off
            
            %legend_name = {};
            for i = 1:length(tab_Interval_Recognition_val_uipanel_lsb_real_data_val)
                legend_name = [legend_name ; tab_Import_Data_listbox_str_for_Interval_Recognition_tab(tab_Interval_Recognition_val_uipanel_lsb_real_data_val(i))];
            end
            %legend(legend_name)
            
        end
        legend(legend_name)
        handles.legend_name_for_Interval_Recognition_tab = legend_name;
        close(hh)
        
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end







    function tab_Interval_Recognition_val_uipanel_lsb_real_data_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            hh = waitbar(0.5,'Please wait...');
            try
                delete(handles.fillhandle)
            end
            try
                delete(handles.him)
            end
            set(0, 'currentfigure', handles.f);
            
            tab_Import_Data_listbox_str = get(handles.tab_Interval_Recognition_validation_uipanel_listbox,'String');
            legend_name = {};
            tab_Interval_Recognition_validation_uipanel_listbox_val = get(handles.tab_Interval_Recognition_validation_uipanel_listbox,'Value');
            if ~isempty(tab_Interval_Recognition_validation_uipanel_listbox_val)
                subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1)
                plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Interval_Recognition_validation_uipanel_listbox_val,:)); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                hold on
                
                %legend_name = {};
                for i = 1:length(tab_Interval_Recognition_validation_uipanel_listbox_val)
                    legend_name = [legend_name ;tab_Import_Data_listbox_str(tab_Interval_Recognition_validation_uipanel_listbox_val(i))];
                end
                %legend(legend_name)
                
            end
            
            
            
            tab_Import_Data_listbox_str_for_Interval_Recognition_tab = get(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'String');
            tab_Interval_Recognition_val_uipanel_lsb_real_data_val = get(handles.tab_Interval_Recognition_validation_uipanel_lsb_real_data,'Value');
            if ~isempty(tab_Interval_Recognition_val_uipanel_lsb_real_data_val)
                subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1)
                plot_bkh(handles.data_for_Interval_Recognition_tab.ppm_mean,handles.data_for_Interval_Recognition_tab.data(tab_Interval_Recognition_val_uipanel_lsb_real_data_val,:)); xlabel('ppm');
                set(gca,'xdir','rev');
                axis tight
                hold off
                
                %legend_name = {};
                for i = 1:length(tab_Interval_Recognition_val_uipanel_lsb_real_data_val)
                    legend_name = [legend_name ; tab_Import_Data_listbox_str_for_Interval_Recognition_tab(tab_Interval_Recognition_val_uipanel_lsb_real_data_val(i))];
                end
                %legend(legend_name)
                
            end
            legend(legend_name)
            handles.legend_name_for_Interval_Recognition_tab = legend_name;
            close(hh)
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_class1_checkbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
              
        
        data_t = get(handles.Intervals_Selected_intervals_uitable,'Data');
        if source.Value == 0
            hh = waitbar(0.5,'Removing Class 1 SS...');
            n1 = find(data_t(:,2) == 1);
            data_t(n1,5) = 0;
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 1);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 0;
            set(handles.tab_Interval_Alignment_class1_checkbox,'Value',0)
        elseif source.Value == 1
            hh = waitbar(0.5,'Including Class 1 SS...');
            n1 = find(data_t(:,2) == 1);
            data_t(n1,5) = 1;
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 1);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 1;
            set(handles.tab_Interval_Alignment_class1_checkbox,'Value',1)
        end
        set(0, 'currentfigure', handles.f);
        
        hold off
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            if handles.tab_Reference_Alignment_index_for_plotting == 2
                plot_bkh(handles.data.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
            elseif handles.tab_Reference_Alignment_index_for_plotting == 3
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            end
            
        end
        
        
        
        
        reg = handles.sigma_plasma_options.intervals_ppm;
        %handles.tab_Interval_Recognition_Show_reg = reg;
        
        ColorSet=handles.ColorSet;
        
        class1_val = get(handles.tab_Interval_Recognition_class1_checkbox,'Value');
        class2_val = get(handles.tab_Interval_Recognition_class2_checkbox,'Value');
        class3_val = get(handles.tab_Interval_Recognition_class3_checkbox,'Value');
        class_val = [class1_val class2_val class3_val];
        
        
        % classes_size
        temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
        classe1_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
        classe2_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
        classe3_size = length(temp1);
        classes_size = [classe1_size classe2_size classe3_size];
        
        reg3 = reg;
        reg4 = {};
        for ii = 1:3
            if class_val(ii) == 1
                reg4(ii) = {reg3(1:classes_size(ii),:)};
                reg3(1:classes_size(ii),:) = [];
            else
                reg4(ii) = {[]};
                reg3(1:classes_size(ii),:) = [];
            end
        end
        
        reg5 = [];
        for ii = 1:3
            if isempty(reg4{ii})
                reg5 = [reg5 ; nan(classes_size(ii),2)];
            else
                reg5 = [reg5 ; reg4{ii}];
            end
        end
        reg = reg5;
        
        
        
        set(0, 'currentfigure', handles.f);
        hold on
        subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        
        
        
        
        
        
        
        
        
        %         try
        %             delete(handles.fillhandle)
        %         end
        %         try
        %             delete(handles.him)
        %         end
        %         hold on
        %
        %         class1_val = get(handles.tab_Interval_Recognition_class1_checkbox,'Value');
        %         class2_val = get(handles.tab_Interval_Recognition_class2_checkbox,'Value');
        %         class3_val = get(handles.tab_Interval_Recognition_class3_checkbox,'Value');
        %         class_val = [class1_val class2_val class3_val];
        %         %ColorSet=varycolor(size(reg,1));
        %         ColorSet=handles.ColorSet;
        %         yy = get(gca,'ylim');
        %         y1 = yy(1);
        %         y2 = yy(2);
        %         y_loc = 0.25 * mean(yy);
        %         reg = handles.tab_Interval_Recognition_Show_reg;
        text_y_location = 0;
        
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        msg='';
                        filled=[[y1 y1],fliplr([y2 y2])];
                        xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                        handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                        set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                        
                        cont.(['i_raw' num2str(i)]) = uicontextmenu;
                        text(mean(reg(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                    else
                        msg='Error: Must use the same number of points in each vector';
                    end
                    hold on
                end
            end
        end
        hold off
        
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        handles.fillhandle.(['i_raw' num2str(i)]).UIContextMenu = cont.(['i_raw' num2str(i)]);
                        
                        m1 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
                        m2 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
                    end
                end
            end
        end
        
        hold off
        
        handles.Intervals_ylim = get(handles.tab_Interval_Recognition_frame1.Children,'ylim');
        handles.Intervals_xlim = get(handles.tab_Interval_Recognition_frame1.Children,'xlim');
        
        cont.('A') = uicontextmenu;
        handles.tab_Interval_Recognition_frame1.Children.UIContextMenu = cont.('A');
        m1 = uimenu(cont.('A'),'Label','Add new interval','Callback',{@Add_new_interval,handles,handles.Intervals_ylim,ColorSet});
        
        
        close(hh)
        
        
        
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Recognition_class2_checkbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        
        
        
        data_t = get(handles.Intervals_Selected_intervals_uitable,'Data');
        if source.Value == 0
            hh = waitbar(0.5,'Removing Class 2 SS...');
            n1 = find(data_t(:,2) == 2);
            data_t(n1,5) = 0;
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 2);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 0;
            set(handles.tab_Interval_Alignment_class2_checkbox,'Value',0)
        elseif source.Value == 1
            hh = waitbar(0.5,'Including Class 2 SS...');
            n1 = find(data_t(:,2) == 2);
            data_t(n1,5) = 1;
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 2);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 1;
            set(handles.tab_Interval_Alignment_class2_checkbox,'Value',1)
        end
        set(0, 'currentfigure', handles.f);
        
        
        
        
        hold off
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            if handles.tab_Reference_Alignment_index_for_plotting == 2
                plot_bkh(handles.data.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
            elseif handles.tab_Reference_Alignment_index_for_plotting == 3
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            end
            
        end
        
        
        
        
        
        
        
        
        reg = handles.sigma_plasma_options.intervals_ppm;
        %handles.tab_Interval_Recognition_Show_reg = reg;
        
        ColorSet=handles.ColorSet;
        
        class1_val = get(handles.tab_Interval_Recognition_class1_checkbox,'Value');
        class2_val = get(handles.tab_Interval_Recognition_class2_checkbox,'Value');
        class3_val = get(handles.tab_Interval_Recognition_class3_checkbox,'Value');
        class_val = [class1_val class2_val class3_val];
        
        
        % classes_size
        temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
        classe1_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
        classe2_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
        classe3_size = length(temp1);
        classes_size = [classe1_size classe2_size classe3_size];
        
        reg3 = reg;
        reg4 = {};
        for ii = 1:3
            if class_val(ii) == 1
                reg4(ii) = {reg3(1:classes_size(ii),:)};
                reg3(1:classes_size(ii),:) = [];
            else
                reg4(ii) = {[]};
                reg3(1:classes_size(ii),:) = [];
            end
        end
        
        reg5 = [];
        for ii = 1:3
            if isempty(reg4{ii})
                reg5 = [reg5 ; nan(classes_size(ii),2)];
            else
                reg5 = [reg5 ; reg4{ii}];
            end
        end
        reg = reg5;
        
        
        
        set(0, 'currentfigure', handles.f);
        hold on
        subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        
        
        
        
        
        
        
        
        
        %         try
        %             delete(handles.fillhandle)
        %         end
        %         try
        %             delete(handles.him)
        %         end
        %         hold on
        %
        %         class1_val = get(handles.tab_Interval_Recognition_class1_checkbox,'Value');
        %         class2_val = get(handles.tab_Interval_Recognition_class2_checkbox,'Value');
        %         class3_val = get(handles.tab_Interval_Recognition_class3_checkbox,'Value');
        %         class_val = [class1_val class2_val class3_val];
        %         %ColorSet=varycolor(size(reg,1));
        %         ColorSet=handles.ColorSet;
        %         yy = get(gca,'ylim');
        %         y1 = yy(1);
        %         y2 = yy(2);
        %         y_loc = 0.25 * mean(yy);
        %         reg = handles.tab_Interval_Recognition_Show_reg;
        text_y_location = 0;
        
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        msg='';
                        filled=[[y1 y1],fliplr([y2 y2])];
                        xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                        handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                        set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                        
                        cont.(['i_raw' num2str(i)]) = uicontextmenu;
                        text(mean(reg(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                    else
                        msg='Error: Must use the same number of points in each vector';
                    end
                    hold on
                end
            end
        end
        hold off
        
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        handles.fillhandle.(['i_raw' num2str(i)]).UIContextMenu = cont.(['i_raw' num2str(i)]);
                        
                        m1 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
                        m2 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
                    end
                end
            end
        end
        
        hold off
        
        handles.Intervals_ylim = get(handles.tab_Interval_Recognition_frame1.Children,'ylim');
        handles.Intervals_xlim = get(handles.tab_Interval_Recognition_frame1.Children,'xlim');
        
        cont.('A') = uicontextmenu;
        handles.tab_Interval_Recognition_frame1.Children.UIContextMenu = cont.('A');
        m1 = uimenu(cont.('A'),'Label','Add new interval','Callback',{@Add_new_interval,handles,handles.Intervals_ylim,ColorSet});
        
        
        
        close(hh)
        
        
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_class3_checkbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        
        
        
        data_t = get(handles.Intervals_Selected_intervals_uitable,'Data');
        if source.Value == 0
            hh = waitbar(0.5,'Removing Class 3 SS...');
            n1 = find(data_t(:,2) == 3);
            data_t(n1,5) = 0;
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 3);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 0;
            set(handles.tab_Interval_Alignment_class3_checkbox,'Value',0)
        elseif source.Value == 1
            hh = waitbar(0.5,'Including Class 3 SS...');
            n1 = find(data_t(:,2) == 3);
            data_t(n1,5) = 1;
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 3);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 1;
            set(handles.tab_Interval_Alignment_class3_checkbox,'Value',1)
        end
        set(0, 'currentfigure', handles.f);
        
        
        
        hold off
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
            handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            
            ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
            if handles.tab_Reference_Alignment_index_for_plotting == 2
                plot_bkh(handles.data.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
            elseif handles.tab_Reference_Alignment_index_for_plotting == 3
                plot_bkh(handles.data_new.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data');axis tight;
                handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
            end
            
        end
        
        
        
        reg = handles.sigma_plasma_options.intervals_ppm;
        %handles.tab_Interval_Recognition_Show_reg = reg;
        
        ColorSet=handles.ColorSet;
        
        class1_val = get(handles.tab_Interval_Recognition_class1_checkbox,'Value');
        class2_val = get(handles.tab_Interval_Recognition_class2_checkbox,'Value');
        class3_val = get(handles.tab_Interval_Recognition_class3_checkbox,'Value');
        class_val = [class1_val class2_val class3_val];
        
        
        % classes_size
        temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
        classe1_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
        classe2_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
        classe3_size = length(temp1);
        classes_size = [classe1_size classe2_size classe3_size];
        
        reg3 = reg;
        reg4 = {};
        for ii = 1:3
            if class_val(ii) == 1
                reg4(ii) = {reg3(1:classes_size(ii),:)};
                reg3(1:classes_size(ii),:) = [];
            else
                reg4(ii) = {[]};
                reg3(1:classes_size(ii),:) = [];
            end
        end
        
        reg5 = [];
        for ii = 1:3
            if isempty(reg4{ii})
                reg5 = [reg5 ; nan(classes_size(ii),2)];
            else
                reg5 = [reg5 ; reg4{ii}];
            end
        end
        reg = reg5;
        
        
        
        set(0, 'currentfigure', handles.f);
        hold on
        subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        
        
        
        
        
        
        
        
        
        %         try
        %             delete(handles.fillhandle)
        %         end
        %         try
        %             delete(handles.him)
        %         end
        %         hold on
        %
        %         class1_val = get(handles.tab_Interval_Recognition_class1_checkbox,'Value');
        %         class2_val = get(handles.tab_Interval_Recognition_class2_checkbox,'Value');
        %         class3_val = get(handles.tab_Interval_Recognition_class3_checkbox,'Value');
        %         class_val = [class1_val class2_val class3_val];
        %         %ColorSet=varycolor(size(reg,1));
        %         ColorSet=handles.ColorSet;
        %         yy = get(gca,'ylim');
        %         y1 = yy(1);
        %         y2 = yy(2);
        %         y_loc = 0.25 * mean(yy);
        %         reg = handles.tab_Interval_Recognition_Show_reg;
        text_y_location = 0;
        
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        msg='';
                        filled=[[y1 y1],fliplr([y2 y2])];
                        xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                        handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                        set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                        
                        cont.(['i_raw' num2str(i)]) = uicontextmenu;
                        text(mean(reg(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                    else
                        msg='Error: Must use the same number of points in each vector';
                    end
                    hold on
                end
            end
        end
        hold off
        
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        handles.fillhandle.(['i_raw' num2str(i)]).UIContextMenu = cont.(['i_raw' num2str(i)]);
                        
                        m1 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
                        m2 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
                    end
                end
            end
        end
        
        hold off
        
        handles.Intervals_ylim = get(handles.tab_Interval_Recognition_frame1.Children,'ylim');
        handles.Intervals_xlim = get(handles.tab_Interval_Recognition_frame1.Children,'xlim');
        
        cont.('A') = uicontextmenu;
        handles.tab_Interval_Recognition_frame1.Children.UIContextMenu = cont.('A');
        m1 = uimenu(cont.('A'),'Label','Add new interval','Callback',{@Add_new_interval,handles,handles.Intervals_ylim,ColorSet});
        
        
        
        close(hh)
        
        
        
        
        setappdata(0,'handles',handles)
    end







    function tab_Interval_Recognition_Evaluate_Intervals_pb_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        try
            plot_experimental_spectra_of_urine_metabolites_int_recog_tab(handles.data.data,handles.data.ppm_mean,handles.sigma_plasma_options,handles.out_ss_map)
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Recognition_save_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        try
            dname = uigetdir;
            options=handles.sigma_plasma_options;
            save([dname '\' 'options'], 'options');
            clear options
            MappedIntervals.out_ss_map=handles.out_ss_map;
            MappedIntervals.options=handles.sigma_plasma_options;
            save([dname '\' 'MappedIntervals'], 'MappedIntervals');
            clear MappedIntervals
        catch e
            errordlg(e.message)
        end
        setappdata(0,'handles',handles)
    end









% =============================================================================================================================
% Interval Alignment
% =============================================================================================================================

[handles.h1_tab_Interval_Alignment,handles.h2_tab_Interval_Alignment,handles.hDivider1_tab_Interval_Alignment] = uisplitpane(handles.tab_Interval_Alignment);
set(handles.hDivider1_tab_Interval_Alignment,'DividerColor','green')
handles.hDivider1_tab_Interval_Alignment.DividerLocation = 0.15;

[handles.h3_tab_Interval_Alignment,handles.h4_tab_Interval_Alignment,handles.hDivider2_tab_Interval_Alignment] = uisplitpane(handles.h2_tab_Interval_Alignment,'Orientation','ver');
set(handles.hDivider2_tab_Interval_Alignment,'DividerColor','green')
handles.hDivider2_tab_Interval_Alignment.DividerLocation = 0.15;


handles.tab_Interval_Alignment_frame1 = uipanel('Parent', handles.h4_tab_Interval_Alignment, 'Position',[.000001 .0000001 .999 .999]);




handles.tab_Interval_Alignment_Align_Intervals_uipanel = uipanel('Parent', handles.h1_tab_Interval_Alignment, 'Position',[.01 .7 .98 .25],'Title','','Visible','on');

handles.tab_Interval_Alignment_Align_Intervals_pushbutton = uicontrol('Parent',handles.tab_Interval_Alignment_Align_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Align Intervals','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Alignment_Align_Intervals_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 100 166 30]) ;

handles.tab_Interval_Alignment_undo_pushbutton = uicontrol('Parent',handles.tab_Interval_Alignment_Align_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Undo','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Alignment_undo_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [50 50 70 30]) ;

handles.tab_Interval_Alignment_options_pushbutton = uicontrol('Parent',handles.tab_Interval_Alignment_Align_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Options','FontSize',10,'FontWeight','bold','visible','off','Callback',{@tab_Interval_Alignment_options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [41 5 90 30]) ;



% handles.tab_Interval_Alignment_Intervals_pushbutton = uicontrol('Parent',handles.h1_tab_Interval_Alignment, 'Style', 'pushbutton','FontWeight','bold', 'String',...
%     'Intervals','FontSize',10,'FontWeight','bold','Visible','off', 'HorizontalAlignment', 'left','Visible','on', 'Position', [20 360 140 30]) ;

handles.tab_Interval_Alignment_Show_pushbutton = uicontrol('Parent',handles.h1_tab_Interval_Alignment, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Show','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Alignment_Show_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [20 330 70 30]) ;

handles.tab_Interval_Alignment_Hide_pushbutton = uicontrol('Parent',handles.h1_tab_Interval_Alignment, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Hide','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Alignment_Hide_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [90 330 70 30]) ;






handles.tab_Interval_Alignment_Evaluate_Iterative_A_I_pb = uicontrol('Parent',handles.h1_tab_Interval_Alignment, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Evaluate Alignment','FontSize',10,'FontWeight','bold','Callback',{@tab_Interval_Alignment_Evaluate_Iterative_A_I_pb_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [10 45 160 50]) ;


handles.tab_Interval_Alignment_save_pushbutton = uicontrol('Parent',handles.h1_tab_Interval_Alignment, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Save','Callback',{@tab_Interval_Alignment_save_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [45 5 80 30]) ;







handles.tab_Interval_Alignment_table_str = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'text', 'String',...
    'Intervals Table:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [10 60 90 20]) ;

% data = [(1:length(handles.sigma_plasma_options.intervals_class))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded];
%
% handles.tab_Interval_Alignment_intervals_uitable = uitable('Parent',handles.h3_tab_Interval_Alignment,'Data',data,'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0'},'RowName',handles.sigma_plasma_options.intervals_name,...
%     'CellEditCallback',{@tab_Interval_Alignment_intervals_uitable_CellEditCallback,handles},'Position', [100 2 830 90],'ColumnEditable',[false false false false true],'BackgroundColor',[.4 .4 .4; .4 .4 .8],'ForegroundColor', [1 1 1]);

handles.tab_Interval_Alignment_intervals_uitable = uitable('Parent',handles.h3_tab_Interval_Alignment,'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0'},...
    'CellEditCallback',{@tab_Interval_Alignment_intervals_uitable_CellEditCallback,handles},'Position', [100 2 830 90],'ColumnEditable',[false false false false true],'BackgroundColor',[.4 .4 .4; .4 .4 .8],'ForegroundColor', [1 1 1]);

handles.tab_Interval_Alignment_class1_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'checkbox', 'String',...
    'Class 1','FontSize',8,'ForegroundColor',handles.ColorSet(1,:),'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Alignment_class1_checkbox_Callback,handles}, 'Position', [937 55 60 20]) ;

handles.tab_Interval_Alignment_class2_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'checkbox', 'String',...
    'Class 2','FontSize',8,'ForegroundColor',handles.ColorSet(2,:),'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Alignment_class2_checkbox_Callback,handles}, 'Position', [937 30 60 20]) ;

handles.tab_Interval_Alignment_class3_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'checkbox', 'String',...
    'Class 3','FontSize',8,'ForegroundColor',handles.ColorSet(3,:),'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Alignment_class3_checkbox_Callback,handles}, 'Position', [937 5 60 20]) ;



handles.x_iterative_align = [];



    function tab_Interval_Alignment_Align_Intervals_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %   try
        
        delete(handles.tab_Interval_Alignment_frame1.Children)
        
        handles.sigma_plasma_options_for_Interval_Alignment = handles.sigma_plasma_options;
        
               
        hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
        data = [(1:length(handles.sigma_plasma_options.intervals_name))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded handles.sigma_plasma_options.intervals_ppm_flex hihi_index];
        kk = ~isnan(data(:,3));
        kk2 = data(kk,:);
        kk2 = sortrows(kk2,2);
        unique_kk2 = unique(kk2(:,2));
        kk4 = [];
        for ii3 = 1:length(unique_kk2)
            unique_1 = (kk2(:,2) == unique_kk2(ii3));
            kk3 = sortrows(kk2(unique_1,:),3);
            kk4 = [kk4 ; kk3];
        end
        
        %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
        hihi_index=kk4(:,end);
        kk4(:,end)=[];
        % Sort sigma_plasma_options Variable Parameters acording to above sorting
        h2=fieldnames(handles.sigma_plasma_options);
        name_size=size(handles.sigma_plasma_options.intervals_name,1);
        for hihi=1:length(fieldnames(handles.sigma_plasma_options))
            if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
                handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
            end
        end
        
        handles.sigma_plasma_options_for_Interval_Alignment.intervals_name = handles.sigma_plasma_options.intervals_name(kk4(:,1));
        handles.sigma_plasma_options_for_Interval_Alignment.intervals_class = kk4(:,2);
        handles.sigma_plasma_options_for_Interval_Alignment.intervals_ppm = kk4(:,3:4);
        handles.sigma_plasma_options_for_Interval_Alignment.VariablesIncluded = kk4(:,5);
        handles.sigma_plasma_options_for_Interval_Alignment.intervals_ppm_flex=kk4(:,6:7);
        
        kk4 = [(1:size(kk4,1))' kk4(:,2:5)];
        
        
        
        %hh = waitbar(0.5,'Please wait...');
        
        set(0, 'currentfigure', handles.f);
        
        % if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
        ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        axis tight
        [handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide, ...
            handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3...
            (handles.out_ss_map,handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment);
        handles.ppm_scale_tab_Interval_Alignment_for_show_and_hide = handles.data.ppm_mean;
        %         elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
        %
        %         elseif handles.tab_Reference_Alignment_index_for_plotting == 1
        %             ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        %             axis tight
        %             [handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3...
        %                 (handles.out_ss_map,handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
        %             handles.ppm_scale_tab_Interval_Alignment_for_show_and_hide = handles.data_new.ppm_mean;
        %         elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
        %             ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        %             axis tight
        %             [handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.out_ss_map,handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
        %             handles.ppm_scale_tab_Interval_Alignment_for_show_and_hide = handles.data_new.ppm_mean;
        %         end
        
        set(handles.tab_Interval_Alignment_Align_Intervals_pushbutton,'BackgroundColor',[0 1 0])
        %                 catch e
        %                     errordlg(e.message)
        %                 end
        setappdata(0,'handles',handles)
    end







    function tab_Interval_Alignment_undo_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        handles.x_iterative_align = [];
        delete(handles.tab_Interval_Alignment_frame1.Children)
        set(handles.tab_Interval_Alignment_Align_Intervals_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
        
        setappdata(0,'handles',handles)
    end








    function tab_Interval_Alignment_options_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        % try
        
        prompt = {'�b� = best possible (default) ; �f� = fast alignment ; 0.001 = max shift allowed'};
        title = 'Iterative Alignment Mode';
        dims = [1 85];
        definput = {handles.sigma_plasma_options.preAlignment.inter};
        
        answer = inputdlg(prompt,title,dims,definput);
        if isempty(answer)
            return
        else
            answer = answer{1};
            switch answer
                case 'b'
                    handles.sigma_plasma_options.preAlignment.inter = 'b';
                case 'f'
                    handles.sigma_plasma_options.preAlignment.inter = 'f';
                otherwise
                    handles.sigma_plasma_options.preAlignment.inter = str2double(answer);
            end
            
        end
        
        % catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Alignment_Show_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');


        % ===============================================================================Edited
        plot_interatively_aligned_intervals(handles.x_iterative_align,handles)
        % ===============================================================================


        

        %         try
        wait_h = waitbar(0.5,'Please wait...');

        
        %reg = handles.x_iterative_align.ppm_intervals;
        
        
        %plot_experimental_spectra_of_urine_metabolites(handles.x_iterative_align,handles.sigma_plasma_options)
        %ColorSet=varycolor(size(reg,2));
        
        %         for i=1:size(reg,2)
        %             reg2(i,:) = [reg{i}(1) reg{i}(end)];
        %         end
        reg2 = handles.sigma_plasma_options.intervals_ppm;
        
        
        ColorSet=handles.ColorSet;
        
        class1_val = get(handles.tab_Interval_Alignment_class1_checkbox,'Value');
        class2_val = get(handles.tab_Interval_Alignment_class2_checkbox,'Value');
        class3_val = get(handles.tab_Interval_Alignment_class3_checkbox,'Value');
        class_val = [class1_val class2_val class3_val];
        
        
        % classes_size
        temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
        classe1_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
        classe2_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
        classe3_size = length(temp1);
        classes_size = [classe1_size classe2_size classe3_size];
        
        reg3 = reg2;
        reg4 = {};
        for ii = 1:3
            if class_val(ii) == 1
                reg4(ii) = {reg3(1:classes_size(ii),:)};
                reg3(1:classes_size(ii),:) = [];
            else
                reg4(ii) = {[]};
                reg3(1:classes_size(ii),:) = [];
            end
        end
        
        reg5 = [];
        for ii = 1:3
            if isempty(reg4{ii})
                reg5 = [reg5 ; nan(classes_size(ii),2)];
            else
                reg5 = [reg5 ; reg4{ii}];
            end
        end
        reg2 = reg5;
        
        
        
        set(0, 'currentfigure', handles.f);
        hold on
        subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        
        
        for i=1:size(reg2,1)
            if ~isnan(reg2(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg2(i,1) reg2(i,2)])
                        msg='';
                        filled=[[y1 y1],fliplr([y2 y2])];
                        xpoints=[[reg2(i,1) reg2(i,2)],fliplr([reg2(i,1) reg2(i,2)])];
                        handles.fillhandle_I_A_T.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                        set(handles.fillhandle_I_A_T.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg2(i,:));%set edge color
                        
                    else
                        msg='Error: Must use the same number of points in each vector';
                    end
                    hold on
                end
            end
        end
        hold off
        
        
        
        subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        %text_y_location = y1+abs(y2-y1)*0.05;
        text_y_location = 0;
        
        hold on
        
        for i=1:size(reg2,1)
            if ~isnan(reg2(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg2(i,1) reg2(i,2)])
                        msg='';
                        filled=[[y1 y1],fliplr([y2 y2])];
                        xpoints=[[reg2(i,1) reg2(i,2)],fliplr([reg2(i,1) reg2(i,2)])];
                        handles.fillhandle_I_A_T.(['i_aligned' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                        set(handles.fillhandle_I_A_T.(['i_aligned' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg2(i,:));%set edge color
                        text(mean(reg2(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                    else
                        msg='Error: Must use the same number of points in each vector';
                    end
                    hold on
                end
            end
        end
        hold off
        
        delete(wait_h)
        
        
        
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end




    function tab_Interval_Alignment_Hide_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            plot_interatively_aligned_intervals(handles.x_iterative_align,handles)
            %             wait_h = waitbar(0.5,'Please wait...');
            %             set(0, 'currentfigure', handles.f);
            %
            %             hh1(1) = subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
            %             plot(handles.ppm_scale_tab_Interval_Alignment_for_show_and_hide,handles.x_preAlignedData_for_show_and_hide)
            %             set(gca,'xdir','rev'); xlabel('ppm');    title('Raw Intervals'); hold on;
            %             axis tight
            %
            %             hh1(2) = subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
            %             plot(handles.ppm_scale_tab_Interval_Alignment_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide)
            %             set(gca,'xdir','rev'); xlabel('ppm');    title('Raw Intervals'); hold on;
            %             axis tight
            %
            %             linkaxes(hh1,'xy');
            %             delete(wait_h)
            %plot_experimental_spectra_of_urine_metabolites(handles.x_iterative_align,handles.sigma_plasma_options)
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Interval_Alignment_Evaluate_Iterative_A_I_pb_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            plot_experimental_spectra_of_urine_metabolites(handles.x_iterative_align,handles.sigma_plasma_options)
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





% handles.tab_Interval_Alignment_table_str = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'text', 'String',...
%     'Intervals Table:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [10 60 90 20]) ;
%
% data = [(1:length(handles.sigma_plasma_options.intervals_class))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded];
%
% handles.tab_Interval_Alignment_intervals_uitable = uitable('Parent',handles.h3_tab_Interval_Alignment,'Data',data,'ColumnName',{'Region No.' 'Class','End ppm','Start ppm','Include=1;Exclude=0'},'RowName',handles.sigma_plasma_options.intervals_name,...
%     'CellEditCallback',{@tab_Interval_Alignment_intervals_uitable_CellEditCallback,handles},'Position', [100 2 830 90],'ColumnEditable',[false false true true true],'BackgroundColor',[.4 .4 .4; .4 .4 .8],'ForegroundColor', [1 1 1]);
%
% handles.tab_Interval_Alignment_class1_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'checkbox', 'String',...
%     'Class 1','FontSize',8,'ForegroundColor',[0 0.75 0],'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Alignment_class1_checkbox_Callback,handles}, 'Position', [937 55 60 20]) ;
%
% handles.tab_Interval_Alignment_class2_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'checkbox', 'String',...
%     'Class 2','FontSize',8,'ForegroundColor',[0 0 0.75],'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Alignment_class2_checkbox_Callback,handles}, 'Position', [937 30 60 20]) ;
%
% handles.tab_Interval_Alignment_class3_checkbox = uicontrol('Parent', handles.h3_tab_Interval_Alignment, 'Style', 'checkbox', 'String',...
%     'Class 3','FontSize',8,'ForegroundColor',[0.2737 0.1969 0.0384],'Visible','on','Value',1, 'HorizontalAlignment', 'left','Callback',{@tab_Interval_Alignment_class3_checkbox_Callback,handles}, 'Position', [937 5 60 20]) ;
%
%
%



    function tab_Interval_Alignment_intervals_uitable_CellEditCallback(source,callbackdata,handles)
        handles = getappdata(0,'handles');
        
        try
            if callbackdata.Indices(2) == 5
                Rowname1 = get(handles.tab_Interval_Alignment_intervals_uitable,'Rowname');
                for jjj = 1 : length(handles.sigma_plasma_options.intervals_name)
                    switch Rowname1{callbackdata.Indices(1)}
                        case handles.sigma_plasma_options.intervals_name{jjj}
                            loc_jjj = jjj;
                            break
                    end
                end
                data = get(handles.tab_Interval_Alignment_intervals_uitable,'Data');
                
                set(handles.Intervals_Selected_intervals_uitable,'Data',data);
                
                handles.sigma_plasma_options.VariablesIncluded(loc_jjj) = data(callbackdata.Indices(1),callbackdata.Indices(2));
            end
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
        
    end








    function tab_Interval_Alignment_class1_checkbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        data_t = get(handles.tab_Interval_Alignment_intervals_uitable,'Data');
        if source.Value == 0
            hh = waitbar(0.5,'Removing Class 1 SS...');
            n1 = find(data_t(:,2) == 1);
            data_t(n1,5) = 0;
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 1);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 0;
            set(handles.tab_Interval_Recognition_class1_checkbox,'Value',0);
        elseif source.Value == 1
            hh = waitbar(0.5,'Including Class 1 SS...');
            n1 = find(data_t(:,2) == 1);
            data_t(n1,5) = 1;
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 1);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 1;
            set(handles.tab_Interval_Recognition_class1_checkbox,'Value',1);
        end
        set(0, 'currentfigure', handles.f);
        
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data.ppm_mean;
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data_new.ppm_mean;
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data_new.ppm_mean;
        end
        
        
        hh1(1) = subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        plot_bkh(ppm_scale,handles.x_preAlignedData_for_show_and_hide)
        set(gca,'xdir','rev'); xlabel('ppm');    title('Raw Intervals'); hold on;
        axis tight
        hold on
        
        hh1(2) = subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
        plot_bkh(ppm_scale,handles.x_tab_Interval_Alignment_for_show_and_hide)
        set(gca,'xdir','rev'); xlabel('ppm');    title('Aligned Intervals'); hold on;
        axis tight
        hold on
        
        
        
        reg = handles.sigma_plasma_options.intervals_ppm;
        
        ColorSet=handles.ColorSet;
        
        class1_val = get(handles.tab_Interval_Alignment_class1_checkbox,'Value');
        class2_val = get(handles.tab_Interval_Alignment_class2_checkbox,'Value');
        class3_val = get(handles.tab_Interval_Alignment_class3_checkbox,'Value');
        class_val = [class1_val class2_val class3_val];
        
        
        % classes_size
        temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
        classe1_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
        classe2_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
        classe3_size = length(temp1);
        classes_size = [classe1_size classe2_size classe3_size];
        
        reg3 = reg;
        reg4 = {};
        for ii = 1:3
            if class_val(ii) == 1
                reg4(ii) = {reg3(1:classes_size(ii),:)};
                reg3(1:classes_size(ii),:) = [];
            else
                reg4(ii) = {[]};
                reg3(1:classes_size(ii),:) = [];
            end
        end
        
        reg5 = [];
        for ii = 1:3
            if isempty(reg4{ii})
                reg5 = [reg5 ; nan(classes_size(ii),2)];
            else
                reg5 = [reg5 ; reg4{ii}];
            end
        end
        reg = reg5;
        
        
        
        set(0, 'currentfigure', handles.f);
        hold on
        subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        text_y_location = 0;
        
        
        
        hh1(1) = subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        hold on
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        msg='';
                        filled=[[y1 y1],fliplr([y2 y2])];
                        xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                        handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                        set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                        
                        cont.(['i_raw' num2str(i)]) = uicontextmenu;
                    else
                        msg='Error: Must use the same number of points in each vector';
                    end
                    hold on
                end
            end
        end
        hold off
        
        
        hh1(1) = subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
        hold on
        for i=1:size(reg,1)
            if ~isnan(reg(i))
                if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                        msg='';
                        filled=[[y1 y1],fliplr([y2 y2])];
                        xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                        handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                        set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                        
                        cont.(['i_raw' num2str(i)]) = uicontextmenu;
                        text(mean(reg(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                    else
                        msg='Error: Must use the same number of points in each vector';
                    end
                    hold on
                end
            end
        end
        hold off
        
        linkaxes(hh1,'xy');
        close(hh)
        
        setappdata(0,'handles',handles)
    end







    function tab_Interval_Alignment_class2_checkbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        data_t = get(handles.tab_Interval_Alignment_intervals_uitable,'Data');
        if source.Value == 0
            hh = waitbar(0.5,'Removing Class 2 SS...');
            n1 = find(data_t(:,2) == 2);
            data_t(n1,5) = 0;
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 2);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 0;
            set(handles.tab_Interval_Recognition_class2_checkbox,'Value',0);
        elseif source.Value == 1
            hh = waitbar(0.5,'Including Class 2 SS...');
            n1 = find(data_t(:,2) == 2);
            data_t(n1,5) = 1;
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 2);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 1;
            set(handles.tab_Interval_Recognition_class2_checkbox,'Value',1);
        end
        set(0, 'currentfigure', handles.f);
        
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data.ppm_mean;
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data_new.ppm_mean;
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data_new.ppm_mean;
        end
        
        
        hh1(1) = subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        plot_bkh(ppm_scale,handles.x_preAlignedData_for_show_and_hide)
        set(gca,'xdir','rev'); xlabel('ppm');    title('Raw Intervals'); hold on;
        axis tight
        hold on
        
        hh1(2) = subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
        plot_bkh(ppm_scale,handles.x_tab_Interval_Alignment_for_show_and_hide)
        set(gca,'xdir','rev'); xlabel('ppm');    title('Aligned Intervals'); hold on;
        axis tight
        hold on
        
        
        
        
        
        
        reg = handles.sigma_plasma_options.intervals_ppm;
        
        ColorSet=handles.ColorSet;
        
        class1_val = get(handles.tab_Interval_Alignment_class1_checkbox,'Value');
        class2_val = get(handles.tab_Interval_Alignment_class2_checkbox,'Value');
        class3_val = get(handles.tab_Interval_Alignment_class3_checkbox,'Value');
        class_val = [class1_val class2_val class3_val];
        
        
        % classes_size
        temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
        classe1_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
        classe2_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
        classe3_size = length(temp1);
        classes_size = [classe1_size classe2_size classe3_size];
        
        reg3 = reg;
        reg4 = {};
        for ii = 1:3
            if class_val(ii) == 1
                reg4(ii) = {reg3(1:classes_size(ii),:)};
                reg3(1:classes_size(ii),:) = [];
            else
                reg4(ii) = {[]};
                reg3(1:classes_size(ii),:) = [];
            end
        end
        
        reg5 = [];
        for ii = 1:3
            if isempty(reg4{ii})
                reg5 = [reg5 ; nan(classes_size(ii),2)];
            else
                reg5 = [reg5 ; reg4{ii}];
            end
        end
        reg = reg5;
        
        
        
        set(0, 'currentfigure', handles.f);
        hold on
        subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        
        text_y_location = 0;
        
        
        
        hh1(1) = subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        hold on
        for i=1:size(reg,1)
            if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                    msg='';
                    filled=[[y1 y1],fliplr([y2 y2])];
                    xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                    handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                    set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                        'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                    
                    cont.(['i_raw' num2str(i)]) = uicontextmenu;
                else
                    msg='Error: Must use the same number of points in each vector';
                end
                hold on
            end
        end
        hold off
        
        
        hh1(1) = subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
        hold on
        for i=1:size(reg,1)
            if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                    msg='';
                    filled=[[y1 y1],fliplr([y2 y2])];
                    xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                    handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                    set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                        'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                    
                    cont.(['i_raw' num2str(i)]) = uicontextmenu;
                    text(mean(reg(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                else
                    msg='Error: Must use the same number of points in each vector';
                end
                hold on
            end
        end
        hold off
        
        linkaxes(hh1,'xy');
        close(hh)
        
        setappdata(0,'handles',handles)
    end







    function tab_Interval_Alignment_class3_checkbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        data_t = get(handles.tab_Interval_Alignment_intervals_uitable,'Data');
        if source.Value == 0
            hh = waitbar(0.5,'Removing Class 3 SS...');
            n1 = find(data_t(:,2) == 3);
            data_t(n1,5) = 0;
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 3);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 0;
            set(handles.tab_Interval_Recognition_class3_checkbox,'Value',0);
        elseif source.Value == 1
            hh = waitbar(0.5,'Including Class 3 SS...');
            n1 = find(data_t(:,2) == 3);
            data_t(n1,5) = 1;
            set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data_t)
            set(handles.Intervals_Selected_intervals_uitable,'Data',data_t)
            n2 = find(handles.sigma_plasma_options.intervals_class == 3);
            handles.sigma_plasma_options.VariablesIncluded(n2) = 1;
            set(handles.tab_Interval_Recognition_class3_checkbox,'Value',1);
        end
        set(0, 'currentfigure', handles.f);
        
        
        if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data.ppm_mean;
        elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
        elseif handles.tab_Reference_Alignment_index_for_plotting == 1
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data_new.ppm_mean;
        elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
            %[handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data_new.data,handles.data_new.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            ppm_scale = handles.data_new.ppm_mean;
        end
        
        
        hh1(1) = subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        plot_bkh(ppm_scale,handles.x_preAlignedData_for_show_and_hide)
        set(gca,'xdir','rev'); xlabel('ppm');    title('Raw Intervals'); hold on;
        axis tight
        hold on
        
        hh1(2) = subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
        plot_bkh(ppm_scale,handles.x_tab_Interval_Alignment_for_show_and_hide)
        set(gca,'xdir','rev'); xlabel('ppm');    title('Aligned Intervals'); hold on;
        axis tight
        hold on
        
        
        
        
        
        reg = handles.sigma_plasma_options.intervals_ppm;
        
        ColorSet=handles.ColorSet;
        
        class1_val = get(handles.tab_Interval_Alignment_class1_checkbox,'Value');
        class2_val = get(handles.tab_Interval_Alignment_class2_checkbox,'Value');
        class3_val = get(handles.tab_Interval_Alignment_class3_checkbox,'Value');
        class_val = [class1_val class2_val class3_val];
        
        
        % classes_size
        temp1 = find(handles.sigma_plasma_options.intervals_class == 1);
        classe1_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 2);
        classe2_size = length(temp1);
        temp1 = find(handles.sigma_plasma_options.intervals_class == 3);
        classe3_size = length(temp1);
        classes_size = [classe1_size classe2_size classe3_size];
        
        reg3 = reg;
        reg4 = {};
        for ii = 1:3
            if class_val(ii) == 1
                reg4(ii) = {reg3(1:classes_size(ii),:)};
                reg3(1:classes_size(ii),:) = [];
            else
                reg4(ii) = {[]};
                reg3(1:classes_size(ii),:) = [];
            end
        end
        
        reg5 = [];
        for ii = 1:3
            if isempty(reg4{ii})
                reg5 = [reg5 ; nan(classes_size(ii),2)];
            else
                reg5 = [reg5 ; reg4{ii}];
            end
        end
        reg = reg5;
        
        
        set(0, 'currentfigure', handles.f);
        hold on
        subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        yy = get(gca,'ylim');
        y1 = yy(1);
        y2 = yy(2);
        
        text_y_location = 0;
        
        hh1(1) = subplot(2,1,1,'Parent',handles.tab_Interval_Alignment_frame1);
        hold on
        for i=1:size(reg,1)
            if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                    msg='';
                    filled=[[y1 y1],fliplr([y2 y2])];
                    xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                    handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                    set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                        'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                    
                    cont.(['i_raw' num2str(i)]) = uicontextmenu;
                else
                    msg='Error: Must use the same number of points in each vector';
                end
                hold on
            end
        end
        hold off
        
        
        hh1(1) = subplot(2,1,2,'Parent',handles.tab_Interval_Alignment_frame1);
        hold on
        for i=1:size(reg,1)
            if class_val(handles.sigma_plasma_options.intervals_class(i)) == 1
                if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([reg(i,1) reg(i,2)])
                    msg='';
                    filled=[[y1 y1],fliplr([y2 y2])];
                    xpoints=[[reg(i,1) reg(i,2)],fliplr([reg(i,1) reg(i,2)])];
                    handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(handles.sigma_plasma_options.intervals_class(i),:));%plot the data
                    set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),...
                        'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',reg(i,:));%set edge color
                    
                    cont.(['i_raw' num2str(i)]) = uicontextmenu;
                    text(mean(reg(i,:)),text_y_location,num2str(i),'Color',[0.2 0.2 0.2 0.6],'FontSize',10)
                else
                    msg='Error: Must use the same number of points in each vector';
                end
                hold on
            end
        end
        hold off
        
        linkaxes(hh1,'xy');
        close(hh)
        
        setappdata(0,'handles',handles)
    end





    function tab_Interval_Alignment_save_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        try
            dname = uigetdir;
            options=handles.sigma_plasma_options;
            save([dname '\' 'options'], 'options');
            clear options
            AlignedIntervals.AlignedIntervals=handles.x_iterative_align;
            AlignedIntervals.options=handles.sigma_plasma_options;
            save([dname '\' 'AlignedIntervals'], 'AlignedIntervals');
            clear AlignedIntervals
        catch e
            errordlg(e.message)
        end
        setappdata(0,'handles',handles)
    end







% =============================================================================================================================
% Quantification
% =============================================================================================================================

[handles.h1_tab_Quantification,handles.h2_tab_Quantification,handles.hDivider1_tab_Quantification] = uisplitpane(handles.tab_Quantification);
set(handles.hDivider1_tab_Quantification,'DividerColor','green')
handles.hDivider1_tab_Quantification.DividerLocation = 0.15;

[handles.h3_tab_Quantification,handles.h4_tab_Quantification,handles.hDivider2_tab_Quantification] = uisplitpane(handles.h2_tab_Quantification,'Orientation','ver');
set(handles.hDivider2_tab_Quantification,'DividerColor','green')
handles.hDivider2_tab_Quantification.DividerLocation = 0.001;


handles.tab_Quantification_frame1 = uipanel('Parent', handles.h4_tab_Quantification, 'Position',[.000001 .0000001 .999 .999]);




handles.tab_Quantification_Quantify_Intervals_uipanel = uipanel('Parent', handles.h1_tab_Quantification, 'Position',[.01 .7 .98 .25],'Title','','Visible','on');

handles.tab_Quantification_Quantify_Intervals_pushbutton = uicontrol('Parent',handles.tab_Quantification_Quantify_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Quantify Intervals','FontSize',10,'FontWeight','bold','Callback',{@tab_Quantification_Quantify_Intervals_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 100 166 30]) ;

handles.tab_Quantification_undo_pushbutton = uicontrol('Parent',handles.tab_Quantification_Quantify_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Undo','FontSize',10,'FontWeight','bold','Callback',{@tab_Quantification_undo_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [50 50 70 30]) ;

handles.tab_Quantification_options_pushbutton = uicontrol('Parent',handles.tab_Quantification_Quantify_Intervals_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Options','FontSize',10,'FontWeight','bold','Callback',{@tab_Quantification_options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [41 5 90 30]) ;


% handles.tab_Quantification_quantified_intervals_str1 = uicontrol('Parent', handles.h1_tab_Quantification, 'Style', 'text', 'String',...
%     'Quatified signature signals:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [10 350 160 25]) ;

handles.tab_Quantification_quantified_intervals_str2 = uicontrol('Parent', handles.h1_tab_Quantification, 'Style', 'text', 'String',...
    '0','FontSize',8,'Visible','off', 'Position', [10 325 160 60]) ;




handles.tab_Quantification_Evaluate_Quantification_pb = uicontrol('Parent',handles.h1_tab_Quantification, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    '<html>Evaluate<br>Quantification','FontSize',10,'FontWeight','bold','Callback',{@tab_Quantification_Evaluate_Quantification_pb_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [10 45 160 50]) ;


handles.tab_Quantification_save_pushbutton = uicontrol('Parent',handles.h1_tab_Quantification, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Save','Callback',{@tab_Quantification_save_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left','Visible','on', 'Position', [45 5 80 30]) ;




    function tab_Quantification_Quantify_Intervals_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
         handles.Included_PC={};
        
        handles.sigma_plasma_options.BaseLineRemove
        if isempty(handles.x_iterative_align)
            %                 if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
            
            % [handles.x_iterative_align,handles.x_preAlignedData_for_show_and_hide,handles.x_tab_Interval_Alignment_for_show_and_hide] = sigma_iterative_align_bkh3(handles.data.data,handles.data.ppm_mean, handles.sigma_plasma_options_for_Interval_Alignment, handles);
            handles.all_intervals_parameters = sigma_quantification_bkh(handles.data.data,handles.sigma_plasma_options,handles);
            
               
            
        else
            %             try
            
            set(0, 'currentfigure', handles.f);
            
            handles.all_intervals_parameters = sigma_quantification_bkh(handles.x_iterative_align,handles.sigma_plasma_options,handles);
            %                         catch ex
            %                             errordlg(ex.message)
            %                         end
            
        end
        
        
        set(handles.tab_Quantification_quantified_intervals_str2,'Visible','on',...
            'String',[num2str(length(handles.all_intervals_parameters)) '-' 'Quantified Signature Signals'],'FontWeight','bold')
        blink(handles.tab_Quantification_quantified_intervals_str2)
        
        set(handles.tab_Quantification_Quantify_Intervals_pushbutton,'BackgroundColor',[0 1 0])
        
        %close(hh)
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end





    function tab_Quantification_undo_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        clear handles.all_intervals_parameters
        set(handles.tab_Quantification_Quantify_Intervals_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
        setappdata(0,'handles',handles)
    end





    function tab_Quantification_options_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try

            output = Quantification_tab_options(handles.sigma_plasma_options);
            if isempty(output)
                return
            end

            handles.sigma_plasma_options.intervals_MCR_Components = output{1}(:,5);


            handles.sigma_plasma_options.intervals_class = output{1}(:,1);
            handles.sigma_plasma_options.intervals_ppm = output{1}(:,2:3);
            handles.sigma_plasma_options.VariablesIncluded = output{1}(:,4);
            
            handles.sigma_plasma_options.BaseLineRemove = output{2}(1);
            
            assignin('base','output',handles.sigma_plasma_options)
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Generate_Report_Quantify_Metabolite_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            prompt = {'Please insert variable number to be be used for quantification:','Please insert concentration (e.g. mM):'};
            title = 'Input';
            dims = [1 35];
            definput = {'1','10'};
            answer = inputdlg(prompt,title,dims,definput);
            
            data1=handles.Generate_Report_outputs.data;
            op1=handles.sigma_plasma_options.intervals_SS_and_total_1H;
            op1(isnan(op1))=1;

            for i=1:size(data1,1)

                Crf=str2num(answer{2,1});
                Irf=data1(i,str2num(answer{1,1}));

                for ki=1:size(data1,2)
                    Ix=data1(i,ki);
                    Nx=op1(ki,1);
                    Nx_tot=op1(ki,1);
                
                    Cx(i,ki) = nmr_quant_bkh(Crf, Irf, Ix, Nx, Nx_tot);
                    
                end

            end

            handles.Generate_Report_outputs.data_quant=Cx;

            
        catch e
            errordlg(e.message)
        end
        set(handles.tab_Generate_Report_Quantify_Metabolite_pushbutton,'BackgroundColor',[0 1 0])
        setappdata(0,'handles',handles)
    end





    function tab_Quantification_Evaluate_Quantification_pb_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %         try
        
        %tab_quantification_plot_experimental_spectra_metabolites(handles.all_intervals_parameters , handles.sigma_plasma_options)
        tab_quant_plot_exp_spectra_metabolites(handles.all_intervals_parameters , handles.sigma_plasma_options)
        
        %         catch e
        %             errordlg(e.message)
        %         end
        
        setappdata(0,'handles',handles)
    end




    function tab_Quantification_save_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            dname = uigetdir;
            options=handles.sigma_plasma_options;
            save([dname '\' 'options'], 'options');
            clear options
            QuantifiedIntervals.QuantifiedIntervals=handles.all_intervals_parameters;
            QuantifiedIntervals.options=handles.sigma_plasma_options;
            save([dname '\' 'QuantifiedIntervals'], 'QuantifiedIntervals');
            clear QuantifiedIntervals
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end




% =============================================================================================================================
% Generate Report
% =============================================================================================================================

[handles.h1_tab_Generate_Report,handles.h2_tab_Generate_Report,handles.hDivider1_tab_Generate_Report] = uisplitpane(handles.tab_Generate_Report);
set(handles.hDivider1_tab_Generate_Report,'DividerColor','green')
handles.hDivider1_tab_Generate_Report.DividerLocation = 0.15;

[handles.h3_tab_Generate_Report,handles.h4_tab_Generate_Report,handles.hDivider2_tab_Generate_Report] = uisplitpane(handles.h2_tab_Generate_Report,'Orientation','ver');
set(handles.hDivider2_tab_Generate_Report,'DividerColor','green')
handles.hDivider2_tab_Generate_Report.DividerLocation = 0.001;


handles.tab_Generate_Report_frame1 = uipanel('Parent', handles.h4_tab_Generate_Report, 'Position',[.000001 .0000001 .999 .999]);


handles.tab_Generate_Report_uipanel = uipanel('Parent', handles.h1_tab_Generate_Report, 'Position',[.01 .6 .98 .35],'Title','','Visible','on');

handles.tab_Generate_Report_Generate_Report_pushbutton = uicontrol('Parent',handles.tab_Generate_Report_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Generate Report','FontSize',10,'FontWeight','bold','Callback',{@tab_Generate_Report_Generate_Report_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 150 166 30]) ;

handles.tab_Generate_Report_Quantify_Metabolite_pushbutton = uicontrol('Parent',handles.tab_Generate_Report_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Quantify Metabolite','FontSize',10,'Callback',{@tab_Generate_Report_Quantify_Metabolite_pushbutton_Callback,handles}, 'Visible','on', 'Position', [3 100 166 30]) ;


handles.tab_Generate_Report_Import_to_Excel_pushbutton = uicontrol('Parent',handles.tab_Generate_Report_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Export to Excel','FontSize',10,'FontWeight','bold','Callback',{@tab_Generate_Report_Import_to_Excel_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 50 166 30]) ;

handles.tab_Generate_Report_QC_Evaluation_pushbutton = uicontrol('Parent',handles.tab_Generate_Report_uipanel, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'QC Evaluation','FontSize',10,'FontWeight','bold','visible','off','Callback',{@tab_Generate_Report_QC_Evaluation_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [3 5 166 30]) ;


handles.tab_Generate_Report_save_options_pushbutton = uicontrol('Parent',handles.h1_tab_Generate_Report, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Save options','FontSize',10,'FontWeight','bold','Callback',{@tab_Generate_Report_save_options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [25 300 130 25]) ;



    function tab_Generate_Report_Generate_Report_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        set(handles.tab_Generate_Report_Generate_Report_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
       % try
            
            handles.Generate_Report_outputs = sigma_generate_report( handles.all_intervals_parameters,handles.sample_AcqPars,handles.data.ppm_mean,handles.tab_Generate_Report_frame1,handles.ColorSet,handles.sigma_plasma_options,handles.Included_PC);
            
            folder_name = uigetdir;
            
            handles.folder_name=folder_name;
            
            % export2wsdlg(checkLabels, varNames, items, 'Save to Workspace');
            SigMa_result=handles.Generate_Report_outputs;
            save([folder_name '\ SigMa_result.mat'],'SigMa_result');
            
            set(handles.tab_Generate_Report_Generate_Report_pushbutton,'BackgroundColor',[0 1 0])
%         catch e
%             errordlg(e.message)
%         end
        
        setappdata(0,'handles',handles)
    end






    function tab_Generate_Report_Import_to_Excel_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        set(handles.tab_Generate_Report_Import_to_Excel_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
        try
            
            hh = waitbar(0.5,'Please wait...');
            
            %             sigma_import_excel(handles.Generate_Report_outputs)
            sigma_import_excel(handles)
            
            close(hh)
            set(handles.tab_Generate_Report_Import_to_Excel_pushbutton,'BackgroundColor',[0 1 0])
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end







    function tab_Generate_Report_QC_Evaluation_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        %set(handles.tab_Generate_Report_QC_Evaluation_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
        msgbox('Coming soon...')
        
        setappdata(0,'handles',handles)
    end





    function tab_Generate_Report_save_options_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        set(handles.tab_Generate_Report_save_options_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
        try
            
            %             dname = uigetdir;
            dname = handles.folder_name;
            
            switch dname
                case 0
                    return
            end
            
            prompt = {'sigma_options'};
            dlg_title = 'Input a name for options';
            num_lines = 1;
            defaultans = {'sigma_options'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            if isempty(answer)
                return
            else
            end
            sigma_plasma_options = handles.sigma_plasma_options;
            save([dname '\' answer{1}],'sigma_plasma_options')
            
            set(handles.tab_Generate_Report_save_options_pushbutton,'BackgroundColor',[0 1 0])
        catch e
            errordlg(e.message)
        end
        
        
        setappdata(0,'handles',handles)
    end














% =============================================================================================================================
% Lipoprotein Prediction
% =============================================================================================================================

[handles.h1_tab_Lp_Prediction,handles.h2_tab_Lp_Prediction,handles.hDivider1_tab_Lp_Prediction] = uisplitpane(handles.tab_Lp_Prediction);
set(handles.hDivider1_tab_Lp_Prediction,'DividerColor','green')
handles.hDivider1_tab_Lp_Prediction.DividerLocation = 0.15;

[handles.h3_tab_Lp_Prediction,handles.h4_tab_Lp_Prediction,handles.hDivider2_tab_Lp_Prediction] = uisplitpane(handles.h2_tab_Lp_Prediction,'Orientation','ver');
set(handles.hDivider2_tab_Lp_Prediction,'DividerColor','green')
handles.hDivider2_tab_Lp_Prediction.DividerLocation = 0.001;


handles.tab_Lp_Prediction_Import_Bruker_Data_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Import Bruker Data ','Callback',{@tab_Lp_Prediction_Import_Bruker_Data_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [25 566 130 22]) ;

handles.tab_Lp_Prediction_Import_MATLAB_Data_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Import MATLAB Data ','Callback',{@tab_Lp_Prediction_Import_MATLAB_Data_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [25 539 130 22]) ;


handles.tab_Lp_Prediction_data_size_str = uicontrol('Parent', handles.h1_tab_Lp_Prediction, 'Style', 'text', 'String',...
    'Data size:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [20 516 130 20]) ;



handles.tab_Lp_Prediction_listbox_str = uicontrol('Parent', handles.h1_tab_Lp_Prediction, 'Style', 'text', 'String',...
    'Samples:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 495 70 20]) ;

handles.tab_Lp_Prediction_listbox = uicontrol('Parent', handles.h1_tab_Lp_Prediction, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [5 395 170 100],'Visible','on','Callback',{@tab_Lp_Prediction_listbox_Callback,handles}) ;

handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'Delete samples & variables','Visible','on','Callback',{@tab_Lp_Prediction_Delete_samp_and_var_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [10 367 160 25]) ;





handles.tab_Lp_Prediction_plot_type_popupmenu_str = uicontrol('Parent', handles.h1_tab_Lp_Prediction, 'Style', 'text', 'String',...
    'Plot:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [42 337 40 20]) ;

handles.tab_Lp_Prediction_plot_type_popupmenu = uicontrol('Parent', handles.h1_tab_Lp_Prediction, 'Style', 'popupmenu', 'String',[{'Overlay'} ; {'Subplot'} ; {'Sample-wise'}],...
    'Visible','on','FontSize',8,'Callback',{@tab_Lp_Prediction_plot_type_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [75 337 90 25]) ;



handles.tab_Lp_Prediction_Load_Y_test_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'Load Y Test-Optional','Visible','on','Callback',{@tab_Lp_Prediction_Load_Y_test_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [35 305 110 20]) ;


handles.tab_Lp_Prediction_One_Click_LP_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'One-Click LP','Visible','on','Callback',{@tab_Lp_Prediction_One_Click_LP_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [15 275 150 20]) ;


handles.tab_Lp_Prediction_Options_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'Options','Visible','on','Callback',{@tab_Lp_Prediction_Options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [45 220 90 25]) ;


handles.tab_Lp_Prediction_CHECK_X_TEST_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'CHECK X TEST ','Visible','on','Callback',{@tab_Lp_Prediction_CHECK_X_TEST_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [45 180 90 25]) ;




handles.tab_Lp_Prediction_PREDICT_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'PREDICT','Visible','off','Callback',{@tab_Lp_Prediction_PREDICT_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [45 140 90 25]) ;


handles.tab_Lp_Prediction_PLOT_Y_DIST_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'PLOT Y DIST','Visible','off','Callback',{@tab_Lp_Prediction_PLOT_Y_DIST_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [45 100 90 25]) ;


handles.tab_Lp_Prediction_PLOT_Y_PRED_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'PLOT Y PRED','Visible','off','Callback',{@tab_Lp_Prediction_PLOT_Y_PRED_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [45 60 90 25]) ;


handles.tab_Lp_Prediction_EXPORT_pushbutton = uicontrol('Parent',handles.h1_tab_Lp_Prediction, 'Style', 'pushbutton', 'String',...
    'Save','Visible','off','Callback',{@tab_Lp_Prediction_EXPORT_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [45 20 90 25]) ;


handles.tab_Lp_Prediction_frame1 = uipanel('Parent', handles.h4_tab_Lp_Prediction, 'Position',[.000001 .0000001 .999 .999]);

handles.op_LP = [];




% handles.tab_Lp_Prediction_Import_Bruker_Data_pushbutton
% handles.tab_Lp_Prediction_Import_MATLAB_Data_pushbutton
% handles.tab_Lp_Prediction_listbox
% handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton
% handles.tab_Lp_Prediction_plot_type_popupmenu
% handles.tab_Lp_Prediction_Load_Y_test_pushbutton
% handles.tab_Lp_Prediction_One_Click_SigMa_pushbutton
% handles.tab_Lp_Prediction_CHECK_X_TEST_pushbutton
% handles.tab_Lp_Prediction_Options_pushbutton
% handles.tab_Lp_Prediction_PREDICT_pushbutton
% handles.tab_Lp_Prediction_PLOT_Y_DIST_pushbutton
% handles.tab_Lp_Prediction_PLOT_Y_PRED_pushbutton
% handles.tab_Lp_Prediction_EXPORT_pushbutton


    function tab_Lp_Prediction_Import_Bruker_Data_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            %fdf=sdsdfsdf;
            GUI_dir = cd;
            cd ..
            temp_dir = cd;
            
            addpath(genpath([temp_dir '\m files of sigma']))
            dname = uigetdir;
            h = waitbar(0.5,'Please wait...');
            
            [handles.data,handles.sample_AcqPars,handles.sample_ProcPars]=import_processed_bruker_nmr_data_bkh(dname);
            handles.sigma_plasma_options = sigma_plasma_options1;
            close(h)
            
            
            cd(GUI_dir)
            
            
            
            Decrease_column_dimension_uimenu_Edit = get(handles.Decrease_column_dimension_uimenu_Edit,'Checked');
            msg_type = 0;
            switch Decrease_column_dimension_uimenu_Edit
                case 'on'
                    [m,n]=size(handles.data.data);
                    
                    if n<10000
                        loc = 1:n;
                        msg_type = 0;
                    elseif n>10000
                        loc0 = ceil(n/10000);
                        loc = 1:loc0:n;
                        msg_type = 1;
                    end
                    
                    handles.data.data = handles.data.data(:,loc);
                    handles.data.ppm_mean = handles.data.ppm_mean(loc);
                    
            end
            
            set(handles.tab_Import_Data_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
            
            
            
            hold off
            
            set(handles.tab_Import_Data_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Lp_Prediction_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Reference_Alignment_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Import_Data_listbox_str,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox_str,'Visible','on')
            set(handles.tab_Import_Data_listbox,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox,'Visible','on')
            set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Visible','on')
            
            set(handles.tab_Import_Data_Load_options_pushbutton,'Visible','on')
            
            set(handles.tab_Import_Data_Apply_norm_uipanel,'Visible','on')
            
            set(handles.tab_Import_Data_plot_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_plot_type_popupmenu,'Visible','on')
            
            set(handles.tab_Import_Data_sample_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_sample_type_popupmenu,'Visible','on')
            set(handles.tab_Import_Data_undo_pushbutton,'Visible','on')
            set(handles.tab_Import_Data_new_plot_pushbutton,'Visible','on')
            
            handles.data_ini = handles.data;
            handles.sample_AcqPars_ini = handles.sample_AcqPars;
            handles.sample_ProcPars_ini = handles.sample_ProcPars;
            handles.tab_Import_Data_index_for_plotting = 1;
            legend off
            
            set(handles.tab_Import_Data_Import_Bruker_Data_pushbutton,'BackgroundColor',[0 1 0])
            set(handles.tab_Import_Data_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            
            set(handles.tab_Lp_Prediction_Import_Bruker_Data_pushbutton,'BackgroundColor',[0 1 0])
            set(handles.tab_Lp_Prediction_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            
            
        catch e
            errordlg(e.message)
            close(h)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Lp_Prediction_Import_MATLAB_Data_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        try
            
            [filename, pathname] = uigetfile( {'*.mat','MATLAB Files (*.mat)'; '*.*',  'All Files (*.*)'}, 'Pick a file');
            
            nmrdata_temp = load([pathname filename]);
            ff2 = fieldnames(nmrdata_temp);
            nmrdata = nmrdata_temp.(ff2{1});
            h = waitbar(0.5,'Please wait...');
            
            [handles.data,handles.sample_AcqPars,handles.sample_ProcPars] = import_processed_matlab_nmr_data_bkh(nmrdata);
            close(h)
            handles.sample_AcqPars.sample_AcqPars_Title = handles.data.subjects;
         
            
            handles.sigma_plasma_options = sigma_plasma_options1;
            
            Decrease_column_dimension_uimenu_Edit = get(handles.Decrease_column_dimension_uimenu_Edit,'Checked');
            msg_type = 0;
            switch Decrease_column_dimension_uimenu_Edit
                case 'on'
                    [m,n]=size(handles.data.data);
                    
                    if n<10000
                        loc = 1:n;
                        msg_type = 0;
                    elseif n>10000
                        loc0 = ceil(n/10000);
                        loc = 1:loc0:n;
                        msg_type = 1;
                    end
                    
                    handles.data.data = handles.data.data(:,loc);
                    handles.data.ppm_mean = handles.data.ppm_mean(loc);
                    
            end
            set(handles.tab_Import_Data_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
            
            set(handles.tab_Lp_Prediction_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data.data,1)) ' * ' num2str(size(handles.data.data,2))]);
            
            
            set(handles.tab_Import_Data_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Lp_Prediction_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Interval_Recognition_validation_uipanel_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            set(handles.tab_Reference_Alignment_listbox,'String',handles.sample_AcqPars.sample_AcqPars_Title,'Value',[])
            
            set(handles.tab_Import_Data_listbox_str,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox_str,'Visible','on')
            set(handles.tab_Import_Data_listbox,'Visible','on')
            set(handles.tab_Lp_Prediction_listbox,'Visible','on')
            set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Visible','on')
            set(handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton,'Visible','on')
            set(handles.tab_Import_Data_Apply_norm_uipanel,'Visible','on')
            
            set(handles.tab_Import_Data_plot_type_popupmenu_str,'Visible','on')
            set(handles.tab_Lp_Prediction_plot_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_plot_type_popupmenu,'Visible','on')
            set(handles.tab_Lp_Prediction_plot_type_popupmenu,'Visible','on')
            
            set(handles.tab_Import_Data_Load_options_pushbutton,'Visible','on')
            
            set(handles.tab_Import_Data_sample_type_popupmenu_str,'Visible','on')
            set(handles.tab_Import_Data_sample_type_popupmenu,'Visible','on')
            set(handles.tab_Import_Data_undo_pushbutton,'Visible','on')
            set(handles.tab_Import_Data_new_plot_pushbutton,'Visible','on')
            
            handles.data_ini = handles.data;
            handles.sample_AcqPars_ini = handles.sample_AcqPars;
            handles.sample_ProcPars_ini = handles.sample_ProcPars;
            handles.tab_Import_Data_index_for_plotting = 1;
            
            
            
            legend off
            
            set(handles.tab_Import_Data_Import_Bruker_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            set(handles.tab_Import_Data_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0 1 0])
            
            set(handles.tab_Lp_Prediction_Import_Bruker_Data_pushbutton,'BackgroundColor',[0.94 0.94 0.94])
            set(handles.tab_Lp_Prediction_Import_MATLAB_Data_pushbutton,'BackgroundColor',[0 1 0])
            
        catch e
            try
                close(h)
            end
            errordlg(e.message)
            
        end
        
        setappdata(0,'handles',handles)
    end




    function tab_Lp_Prediction_listbox_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            
            tab_Lp_Prediction_listbox_str = get(handles.tab_Lp_Prediction_listbox,'String');
            tab_Lp_Prediction_listbox_val = get(handles.tab_Lp_Prediction_listbox,'Value');
            
            tab_Lp_Prediction_plot_type_popupmenu_val = get(handles.tab_Lp_Prediction_plot_type_popupmenu,'Value');
            
            subplot(1,1,1,'Parent',handles.tab_Lp_Prediction_frame1)
            plot(0,0,'*w')
            
            
            tab_Lp_Prediction_Del_pb_Bckcolor = get(handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton,'Backgroundcolor');
            if tab_Lp_Prediction_Del_pb_Bckcolor == [0.9294 0.6902 0.1294]
                
                switch tab_Lp_Prediction_plot_type_popupmenu_val
                    case 1
                        subplot(1,1,1,'Parent',handles.tab_Lp_Prediction_frame1)
                        plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Lp_Prediction_listbox_val,:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        hold off
                        
                        legend_name = {};
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            legend_name(i) = tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i));
                        end
                        legend(legend_name)
                        
                    case 2
                        [x , y] = subplot_x_y_size(length(tab_Lp_Prediction_listbox_val));
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(x,y,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                    case 3
                        
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(length(tab_Lp_Prediction_listbox_val),1,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                end
                
                
            else
                
                switch tab_Lp_Prediction_plot_type_popupmenu_val
                    case 1
                        subplot(1,1,1,'Parent',handles.tab_Lp_Prediction_frame1)
                        plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Lp_Prediction_listbox_val,:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        hold off
                        
                        legend_name = {};
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            legend_name(i) = tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i));
                        end
                        legend(legend_name)
                        
                    case 2
                        [x , y] = subplot_x_y_size(length(tab_Lp_Prediction_listbox_val));
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(x,y,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                    case 3
                        
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(length(tab_Lp_Prediction_listbox_val),1,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                end
                
                
            end
            
            
            
            
            legend_name = {};
            for i = 1:length(tab_Lp_Prediction_listbox_val)
                legend_name(i) = tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i));
            end
            legend(legend_name)
            %             legend off
            
            legend off
            
            
            
            
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end




    function tab_Lp_Prediction_Delete_samp_and_var_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            tab_Import_Data_sample_type_popupmenu0 = get(handles.tab_Import_Data_sample_type_popupmenu,'Value');
            output = tab_Import_Data_Delete_samp_and_var_pb_gui(handles.data,handles.sample_AcqPars,handles.sample_ProcPars,handles.sigma_plasma_options,tab_Import_Data_sample_type_popupmenu0,'Lp_Prediction');
            
            if isempty(output)
                return
            end
            handles.data_new = output{1}(:,1);
            handles.sample_AcqPars_new = output{2};
            handles.sample_ProcPars_new = output{3};
            handles.sigma_plasma_options_new =output{4};
            
            
                       
            
            set(handles.tab_Import_Data_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data_new.data,1)) ' * ' num2str(size(handles.data_new.data,2))]);
            set(handles.tab_Lp_Prediction_data_size_str,'Visible','on','String', ['Data size: ' num2str(size(handles.data_new.data,1)) ' * ' num2str(size(handles.data_new.data,2))]);
            
            set(handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton,'Backgroundcolor',[0.9294 0.6902 0.1294],'Tooltipstring','Accept data by preesing mouse right click and then accept data')
            
            
            tab_Lp_Prediction_Delete_samp_and_var_pb_UICntMn = uicontextmenu;
            handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton.UIContextMenu = tab_Lp_Prediction_Delete_samp_and_var_pb_UICntMn;
            IDM_UICntMn1 = uimenu(tab_Lp_Prediction_Delete_samp_and_var_pb_UICntMn,'Label','Accept data','Callback',{@tab_Lp_Prediction_Delete_samp_and_var_pb_UI_cm,handles});
            
            %             set(handles.tab_Import_Data_save_pushbutton,'Enable','on')
            %             legend off
            
            
            
            
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Lp_Prediction_plot_type_popupmenu_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        try
            
            
            tab_Lp_Prediction_listbox_str = get(handles.tab_Lp_Prediction_listbox,'String');
            tab_Lp_Prediction_listbox_val = get(handles.tab_Lp_Prediction_listbox,'Value');
            
            tab_Lp_Prediction_plot_type_popupmenu_val = get(handles.tab_Lp_Prediction_plot_type_popupmenu,'Value');
            
            subplot(1,1,1,'Parent',handles.tab_Lp_Prediction_frame1)
            plot(0,0,'*w')
            
            
            tab_Lp_Prediction_Del_pb_Bckcolor = get(handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton,'Backgroundcolor');
            if tab_Lp_Prediction_Del_pb_Bckcolor == [0.9294 0.6902 0.1294]
                
                switch tab_Lp_Prediction_plot_type_popupmenu_val
                    case 1
                        subplot(1,1,1,'Parent',handles.tab_Lp_Prediction_frame1)
                        plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Lp_Prediction_listbox_val,:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        hold off
                        
                        legend_name = {};
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            legend_name(i) = tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i));
                        end
                        legend(legend_name)
                        
                    case 2
                        [x , y] = subplot_x_y_size(length(tab_Lp_Prediction_listbox_val));
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(x,y,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                    case 3
                        
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(length(tab_Lp_Prediction_listbox_val),1,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data_new.ppm_mean,handles.data_new.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                end
                
                
            else
                
                switch tab_Lp_Prediction_plot_type_popupmenu_val
                    case 1
                        subplot(1,1,1,'Parent',handles.tab_Lp_Prediction_frame1)
                        plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Lp_Prediction_listbox_val,:)); xlabel('ppm');
                        set(gca,'xdir','rev');
                        axis tight
                        hold off
                        
                        legend_name = {};
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            legend_name(i) = tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i));
                        end
                        legend(legend_name)
                        
                    case 2
                        [x , y] = subplot_x_y_size(length(tab_Lp_Prediction_listbox_val));
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(x,y,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                    case 3
                        
                        for i = 1:length(tab_Lp_Prediction_listbox_val)
                            ax(i) = subplot(length(tab_Lp_Prediction_listbox_val),1,i,'Parent',handles.tab_Lp_Prediction_frame1);
                            plot_bkh(handles.data.ppm_mean,handles.data.data(tab_Lp_Prediction_listbox_val(i),:)); xlabel('ppm');
                            set(gca,'xdir','rev');
                            axis tight
                            legend(tab_Lp_Prediction_listbox_str(tab_Lp_Prediction_listbox_val(i)))
                        end
                        linkaxes(ax,'xy');
                        hold off
                        
                end
                
                
            end
            
            
            
            
            %             legend off
            
            legend off
            
            
            
            
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Lp_Prediction_Load_Y_test_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        
        try
            
            [filename, pathname] = uigetfile( {'*.mat','MATLAB Files (*.mat)'; '*.*',  'All Files (*.*)'}, 'Pick a file');
            nmrdata_temp = load([pathname filename]);
            ff2 = fieldnames(nmrdata_temp);
            handles.Y = nmrdata_temp.(ff2{1});
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





    function tab_Lp_Prediction_One_Click_LP_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            sigma_nmr_lp_default_run(handles);
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end



    function tab_Lp_Prediction_Options_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            prompt = {'0=No Alignment,  or type 1-5 to select the best alignment','FixXaxis (1=yes;0=No):','FixYaxis (1=yes;0=No):','RemoveHigh (1=yes;0=No):','RemoveLow (1=yes;0=No):'};
            title = 'LP data check option';
            dims = [1 35];
            definput = {'0','0','0','0','0'};
            answer = inputdlg(prompt,title,dims,definput);
            
           
            if isempty(answer)
                return
            end
            
            handles.op_LP = lp_data_check_option([],str2num(answer{2}),str2num(answer{3}),[],str2num(answer{4}),[],str2num(answer{5}),[],str2num(answer{1}),[]);
            
            
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end




    function tab_Lp_Prediction_CHECK_X_TEST_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            
            % h = waitbar(0.5,'Checking validity of user NMR spectra for lipoprotein prediction');
            
            set(0, 'currentfigure', handles.f);
            
            if isfield(handles,'sigma_plasma_options')==0
                handles.sigma_plasma_options=sigma_plasma_options1;
            end;
            
            
            %
            %                 handles.Xref=nmrdata;
            %         handles.Yref=ucdata;
            %         handles.Model=Final_Model;
            if isempty(handles.op_LP)
                %             handles.data.data=lp_data_check_bkh(handles.Xref,handles.data_ini,handles.tab_Lp_Prediction_frame1,handles.sigma_plasma_options);
                handles.data_new.data=lp_data_check_bkh(handles.Xref,handles.data,handles.tab_Lp_Prediction_frame1,handles.sigma_plasma_options);
            else
                %handles.data.data=lp_data_check_bkh(handles.Xref,handles.data_ini,handles.tab_Lp_Prediction_frame1,handles.sigma_plasma_options,handles.op_LP);
                handles.data_new.data=lp_data_check_bkh(handles.Xref,handles.data,handles.tab_Lp_Prediction_frame1,handles.sigma_plasma_options,handles.op_LP);
            end
            handles.data_new.ppm=handles.Xref.ppm;
            handles.data_new.ppm_mean=handles.Xref.ppm;
            
            %set(handles.tab_Lp_Prediction_CHECK_X_TEST_pushbutton,'BackgroundColor',[0 1 0])
            set(handles.tab_Lp_Prediction_CHECK_X_TEST_pushbutton,'Backgroundcolor',[0.9294 0.6902 0.1294],'Tooltipstring','Accept data by preesing mouse right click and then accept data')
            
            
            set(handles.tab_Lp_Prediction_PREDICT_pushbutton,'Visible','On')
            
            tab_Lp_Prediction_CHECK_X_TEST_pushbutton_UICntMn = uicontextmenu;
            handles.tab_Lp_Prediction_CHECK_X_TEST_pushbutton.UIContextMenu = tab_Lp_Prediction_CHECK_X_TEST_pushbutton_UICntMn;
            LP_UICntMn1 = uimenu(tab_Lp_Prediction_CHECK_X_TEST_pushbutton_UICntMn,'Label','Accept data','Callback',{@tab_Lp_Prediction_CHECK_X_TEST_pb_UI_cm,handles});
            
            
        catch e
            errordlg(e.message)
        end
        % close(h)
        
        setappdata(0,'handles',handles)
        
    end










    function tab_Lp_Prediction_PREDICT_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            prompt = {'LP IDs:'};
            title = 'Input LP IDs to predict';
            dims = [1 35];
            definput = {['1:' num2str(size(handles.Yref.data,2))]};
            answer = inputdlg(prompt,title,dims,definput);
            
            h = waitbar(0.5,'Predicting lipoproteins...');
            
            if isempty(answer)
                return
            end
            handles.LP_IDs = str2num(answer{1});
            
            if (max(handles.LP_IDs) > size(handles.Yref.data,2)) || (min(handles.LP_IDs) < 1)
                warndlg(['Selected LPs are outside the range of sigma data. Thus, default LP IDs are used('  num2str('1-') num2str(size(handles.Yref.data,2)) ').'])
                handles.LP_IDs=[1:size(handles.Yref.data,2)];
            end
            
            [ handles] = sigma_pls_testset_predict_bkh(handles);
            
            %             if isfield(handles,'Y')
            %                [ handles] = sigma_pls_testset_predict_bkh(handles.data,handles.Xref,handles.Yref,handles.Model,handles.LP_IDs,handles.Y);
            %             else
            %                 [ handles.S ] = sigma_pls_testset_predict_bkh(handles.data,handles.Xref,handles.Yref,handles.Model,handles.LP_IDs);
            %             end;
            
            
            set(handles.tab_Lp_Prediction_PREDICT_pushbutton,'BackgroundColor',[0 1 0])
            
            set(handles.tab_Lp_Prediction_PLOT_Y_DIST_pushbutton,'Visible','On')
            set(handles.tab_Lp_Prediction_PLOT_Y_PRED_pushbutton,'Visible','On')
            set(handles.tab_Lp_Prediction_EXPORT_pushbutton,'Visible','On')
            
        catch e
            errordlg(e.message)
        end
        
        delete(h)
        setappdata(0,'handles',handles)
    end





    function tab_Lp_Prediction_PLOT_Y_DIST_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            prompt = {'LP IDs:'};
            title = 'Input LP IDs to plot';
            dims = [1 35];
            definput = {['1:' num2str(length(handles.LP_IDs))]};
            answer = inputdlg(prompt,title,dims,definput);
            if isempty(answer)
                return
            end
            handles.LP_IDs_for_plot = str2num(answer{1});
            
            
            if (max(handles.LP_IDs_for_plot) > length(handles.S.models_test)) || (min(handles.LP_IDs_for_plot) < 1)
                warndlg(['Selected LPs to plot are not predicted. Thus, default LP IDs are used('  num2str('1-') num2str(length(handles.LP_IDs_for_plot)) ').']);
                handles.LP_IDs_for_plot=[1:length(handles.LP_IDs_for_plot)];
            end
            
            plot_Ydist_bkh(handles);
            
            set(handles.tab_Lp_Prediction_PLOT_Y_DIST_pushbutton,'BackgroundColor',[0 1 0])
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Lp_Prediction_PLOT_Y_PRED_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            prompt = {'LP IDs:'};
            title = 'Input LP IDs to plot';
            dims = [1 35];
            definput = {['1:' num2str(length(handles.LP_IDs))]};
            answer = inputdlg(prompt,title,dims,definput);
            if isempty(answer)
                return
            end
            handles.LP_IDs_for_plot = str2num(answer{1});
            
            if (max(handles.LP_IDs_for_plot) > length(handles.S.models_test)) || (min(handles.LP_IDs_for_plot) < 1)
                warndlg(['Selected LPs to plot are not predicted. Thus, default LP IDs are used('  num2str('1-') num2str(length(handles.LP_IDs_for_plot)) ').']);
                handles.LP_IDs_for_plot=[1:length(handles.LP_IDs_for_plot)];
            end
            
            %             plot_Ypred_bkh(handles.S,handles.Yref,handles.Xref,handles.Model,handles.LP_IDs,handles.LP_IDs_for_plot);
            plot_Ypred_bkh(handles);
            set(handles.tab_Lp_Prediction_PLOT_Y_PRED_pushbutton,'BackgroundColor',[0 1 0])
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end






    function tab_Lp_Prediction_EXPORT_pushbutton_Callback(source,eventdata,handles)
        handles = getappdata(0,'handles');
        try
            
            %        show_results_of_LP(handles.S)
            sigma_import_excel_LP(handles.S);
            
            set(handles.tab_Lp_Prediction_EXPORT_pushbutton,'BackgroundColor',[0 1 0])
            
        catch e
            errordlg(e.message)
        end
        
        setappdata(0,'handles',handles)
    end





try
    
    
    
    
    
    
    
    
    handles.previous_tab = 'Import Data';
    handles.Included_PC={};
    
    
    % -------------------------------------------------------------------
    try
        figbh = findobj(allchild(0),'tag','figbrowser');
        if ishandle(figbh)
            delete(figbh);
        end
    end
    try
        figbh = findobj(allchild(0),'tag','figbrowsermenu');
        if ~isempty(figbh);
            delete(figbh);
        end
    end
    % -------------------------------------------------------------------
    
    
    set( findall( gcf, '-property', 'Units' ), 'Units', 'Normalized' )
    
    
    handles.f.Visible = 'on';
    
    
    setappdata(0,'handles',handles)
    
    
catch e
    errordlg(e.message)
end

end






% Create a Callback
% =============================================================================================================================

function tabChangedCB(hObject,eventdata,handles)
% Get the Title of the previous tab
% tabName = eventdata.OldValue.Title
handles = getappdata(0,'handles');

try
    tabName_New = eventdata.NewValue.Title;
    
    % If 'Loan Data' was the previous tab, update the table and plot
    if strcmp(tabName_New, 'Import Data')
        % elseif strcmp(tabName_New, 'View')
        handles.previous_tab = 'Import Data';
        
    elseif strcmp(tabName_New, 'Reference Alignment')
        
        delete(handles.tab_Reference_frame1.Children)
        
        %         if handles.tab_Reference_Alignment_index_for_plotting == 0
        %
        %             tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
        %             if isempty(tab_Import_Data_listbox_val)
        %                 return
        %             end
        %             tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %
        %             switch handles.tab_Import_Data_index_for_plotting
        %                 case 0
        %
        %                 case 1
        %
        %                     tab_Import_Data_listbox_str = get(handles.tab_Import_Data_listbox,'String');
        %                     set(handles.tab_Reference_Alignment_listbox,'String',tab_Import_Data_listbox_str);
        %
        %                     tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
        %                     if length(tab_Import_Data_listbox_val) > 2
        %                         set(handles.tab_Reference_Alignment_listbox,'Value',1:2);
        %                     else
        %                         set(handles.tab_Reference_Alignment_listbox,'Value',tab_Import_Data_listbox_val);
        %                     end
        %
        %
        %                     tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %
        %                     tab_Reference_Alignment_listbox_str = get(handles.tab_Reference_Alignment_listbox,'String');
        %                     tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %
        %                     tab_Import_Data_plot_type_popupmenu_val = get(handles.tab_Import_Data_plot_type_popupmenu,'Value');
        %
        %
        %                     subplot(1,1,1,'Parent',handles.tab_Reference_frame1)
        %                     plot(0,0,'*w')
        %
        %                     switch tab_Import_Data_plot_type_popupmenu_val
        %                         case 1
        %                             subplot(1,1,1,'Parent',handles.tab_Reference_frame1)
        %                             plot(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
        %                             set(gca,'xdir','rev');
        %                             axis tight
        %                             hold off
        %
        %
        %                             legend_name = {};
        %                             for i = 1:length(tab_Reference_Alignment_listbox_val)
        %                                 legend_name(i) = tab_Reference_Alignment_listbox_str(tab_Reference_Alignment_listbox_val(i));
        %                             end
        %                             legend(legend_name)
        %
        %                         case 2
        %                             [x , y] = subplot_x_y_size(length(tab_Reference_Alignment_listbox_val));
        %                             for i = 1:length(tab_Reference_Alignment_listbox_val)
        %                                 ax(i) = subplot(x,y,i,'Parent',handles.tab_Reference_frame1);
        %                                 plot(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val(i),:)); xlabel('ppm');
        %                                 set(gca,'xdir','rev');
        %                                 axis tight
        %                                 legend(tab_Reference_Alignment_listbox_str(tab_Reference_Alignment_listbox_val(i)))
        %                             end
        %                             linkaxes(ax,'xy');
        %                             hold off
        %
        %                         case 3
        %
        %                             for i = 1:length(tab_Reference_Alignment_listbox_val)
        %                                 ax(i) = subplot(length(tab_Reference_Alignment_listbox_val),1,i,'Parent',handles.tab_Reference_frame1);
        %                                 plot(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val(i),:)); xlabel('ppm');
        %                                 set(gca,'xdir','rev');
        %                                 axis tight
        %                                 legend(tab_Reference_Alignment_listbox_str(tab_Reference_Alignment_listbox_val(i)))
        %                             end
        %                             linkaxes(ax,'xy');
        %                             hold off
        %
        %                     end
        %
        %                 case 2
        %
        %                     % % %                     if handles.tab_Import_Data_index_for_plotting == 1
        %                     % % %                         p1b = 1;
        %                     % % %                         p2b = length(handles.data_Reference_Alignment_ini.ppm_mean);
        %                     % % %                     elseif handles.tab_Import_Data_index_for_plotting == 2
        %                     % % %                         handles.data_Reference_Alignment_ini.data = handles.data_norm;
        %                     % % %
        %                     % % %                         start_of_the_region_val = str2double(get(handles.tab_Import_Data_Apply_norm_start_of_the_region_edit,'String'));
        %                     % % %                         end_of_the_region_val = str2double(get(handles.tab_Import_Data_Apply_norm_end_of_the_region_edit,'String'));
        %                     % % %                         a1=abs(handles.data.ppm_mean-end_of_the_region_val); p1b=find(a1==min(a1));  if length(p1b)>1; p1b=p1b(1,1); end;
        %                     % % %                         a1=abs(handles.data.ppm_mean-start_of_the_region_val); p2b=find(a1==min(a1));    if length(p2b)>1; p2b=p2b(1,1); end;
        %                     % % %
        %                     % % %                     end
        %                     % % %
        %                     % % %                     tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %                     % % %                     tab_Reference_Alignment_listbox_str = get(handles.tab_Reference_Alignment_listbox,'String');
        %                     % % %                     tab_Reference_Alignment_plot_type_popupmenu_val = get(handles.tab_Reference_Alignment_plot_type_popupmenu,'Value');
        %                     % % %
        %                     % % %
        %                     % % %
        %                     % % %
        %                     % % %                     %
        %                     % % %                     %                                 syms axx
        %                     % % %                     %             tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %                     % % %                     %
        %                     % % %                     %             tab_Reference_Alignment_plot_type_popupmenu_val = get(handles.tab_Reference_Alignment_plot_type_popupmenu,'Value');
        %                     % % %                     subplot(1,1,1,'Parent',handles.tab_Reference_frame1)
        %                     % % %                     if size(handles.tab_Reference_Alignment_Align_current_plot,1) == 1
        %                     % % %                         switch tab_Reference_Alignment_plot_type_popupmenu_val
        %                     % % %                             case 1
        %                     % % %                                 eval(handles.tab_Reference_Alignment_Align_current_plot{1,3})
        %                     % % %                                 eval(['plot(' handles.tab_Reference_Alignment_Align_current_plot{1,1} ',' handles.tab_Reference_Alignment_Align_current_plot{1,2} ');'])
        %                     % % %                                 for i = 5:size(handles.tab_Reference_Alignment_Align_current_plot,2)
        %                     % % %                                     eval(handles.tab_Reference_Alignment_Align_current_plot{1,i})
        %                     % % %                                 end
        %                     % % %                             case 2
        %                     % % %
        %                     % % %                             case 3
        %                     % % %
        %                     % % %                         end
        %                     % % %                     elseif size(handles.tab_Reference_Alignment_Align_current_plot,1) == 2
        %                     % % %                         switch tab_Reference_Alignment_plot_type_popupmenu_val
        %                     % % %                             case 1
        %                     % % %                                 eval(handles.tab_Reference_Alignment_Align_current_plot{1,3})
        %                     % % %                                 eval(['plot(' handles.tab_Reference_Alignment_Align_current_plot{1,1} ',' handles.tab_Reference_Alignment_Align_current_plot{1,2} ');'])
        %                     % % %                                 for i = 5:size(handles.tab_Reference_Alignment_Align_current_plot,2)
        %                     % % %                                     eval(handles.tab_Reference_Alignment_Align_current_plot{1,i})
        %                     % % %                                 end
        %                     % % %
        %                     % % %                                 eval(handles.tab_Reference_Alignment_Align_current_plot{2,3})
        %                     % % %                                 eval(['plot(' handles.tab_Reference_Alignment_Align_current_plot{2,1} ',' handles.tab_Reference_Alignment_Align_current_plot{2,2} ');'])
        %                     % % %                                 for i = 5:size(handles.tab_Reference_Alignment_Align_current_plot,2)
        %                     % % %                                     eval(handles.tab_Reference_Alignment_Align_current_plot{2,i})
        %                     % % %                                 end
        %                     % % %
        %                     % % %                             case 2
        %                     % % %
        %                     % % %                             case 3
        %                     % % %
        %                     % % %                         end
        %                     % % %
        %                     % % %                     end
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %
        %                     %                     switch tab_Reference_Alignment_plot_type_popupmenu_val
        %                     %                         case 1
        %                     %                             subplot(1,1,1,'Parent',handles.tab_Reference_frame1)
        %                     %                             plot(handles.data_Reference_Alignment_ini.ppm_mean,handles.data_Reference_Alignment_ini.data(tab_Reference_Alignment_listbox_val,p1b:p2b)); xlabel('ppm');
        %                     %                             set(gca,'xdir','rev');
        %                     %                             axis tight
        %                     %                             hold off
        %                     %
        %                     %                             legend_name = {};
        %                     %                             for i = 1:length(tab_Reference_Alignment_listbox_val)
        %                     %                                 legend_name(i) = tab_Reference_Alignment_listbox_str(tab_Reference_Alignment_listbox_val(i));
        %                     %                             end
        %                     %                             legend(legend_name)
        %                     %
        %                     %                         case 2
        %                     %                             [x , y] = subplot_x_y_size(length(tab_Import_Data_listbox_val));
        %                     %                             for i = 1:length(tab_Import_Data_listbox_val)
        %                     %                                 ax(i) = subplot(x,y,i,'Parent',handles.tab_Reference_frame1);
        %                     %                                 plot(handles.data_Reference_Alignment_ini.ppm_mean,handles.data_Reference_Alignment_ini.data(tab_Reference_Alignment_listbox_val(i),p1b:p2b)); xlabel('ppm');
        %                     %                                 set(gca,'xdir','rev');
        %                     %                                 axis tight
        %                     %                                 legend(tab_Reference_Alignment_listbox_str(tab_Reference_Alignment_listbox_val(i)))
        %                     %                             end
        %                     %                             linkaxes(ax,'xy');
        %                     %                             hold off
        %                     %
        %                     %                         case 3
        %                     %                             for i = 1:length(tab_Import_Data_listbox_val)
        %                     %                                 ax(i) = subplot(length(tab_Import_Data_listbox_val),1,i,'Parent',handles.tab_Reference_frame1);
        %                     %                                 plot(handles.data_Reference_Alignment_ini.ppm_mean,handles.data_Reference_Alignment_ini.data(tab_Reference_Alignment_listbox_val(i),p1b:p2b)); xlabel('ppm');
        %                     %                                 set(gca,'xdir','rev');
        %                     %                                 axis tight
        %                     %                                 legend(tab_Reference_Alignment_listbox_str(tab_Reference_Alignment_listbox_val(i)))
        %                     %                             end
        %                     %                             linkaxes(ax,'xy');
        %                     %                             hold off
        %                     %
        %                     %                     end
        %
        %
        %
        %
        %                     % % %                     tab_Import_Data_listbox_val = get(handles.tab_Import_Data_listbox,'Value');
        %                     % % %                     set(handles.tab_Reference_Alignment_listbox,'Value',tab_Import_Data_listbox_val);
        %
        %             end
        %
        %
        %         elseif handles.tab_Reference_Alignment_index_for_plotting == 1
        %
        %             tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %
        %             ax1(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        %             plot(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
        %             set(gca,'xdir','rev');
        %             axis tight
        %             title('Raw Data')
        %             hold off
        %
        %             ax1(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        %             plot(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');
        %             set(gca,'xdir','rev');
        %             axis tight
        %             title('Aligned data')
        %             hold off
        %             linkaxes(ax1,'xy');
        %
        %         elseif handles.tab_Reference_Alignment_index_for_plotting == 2
        %             tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %
        %             ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        %             plot(handles.data.ppm_mean,handles.data.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
        %
        %             ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        %             plot(handles.data.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:));set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %
        %         elseif handles.tab_Reference_Alignment_index_for_plotting == 3
        %             tab_Reference_Alignment_listbox_val = get(handles.tab_Reference_Alignment_listbox,'Value');
        %             ax2(1) = subplot(2,1,1,'Parent',handles.tab_Reference_frame1);
        %             plot(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:)); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
        %
        %             ax2(2) = subplot(2,1,2,'Parent',handles.tab_Reference_frame1);
        %             plot(handles.data_new.ppm_mean,handles.data_new.data(tab_Reference_Alignment_listbox_val,:));set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %
        %         end
        
        handles.previous_tab = 'Reference Alignment';
        
    elseif strcmp(tabName_New, 'Interval Recognition')
        
        %         if handles.tab_Import_Data_index_for_plotting == 1 && handles.tab_Reference_Alignment_index_for_plotting == 0
        %             ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        %             plot(handles.data.ppm_mean,handles.data.data); xlabel('ppm');set(gca,'xdir','rev'); title('Raw data');axis tight;
        %             handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
        %         elseif handles.tab_Import_Data_index_for_plotting == 2 && handles.tab_Reference_Alignment_index_for_plotting == 0
        %
        %
        %         elseif handles.tab_Reference_Alignment_index_for_plotting == 1
        %
        %             ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        %             plot(handles.data_new.ppm_mean,handles.data_new.data); xlabel('ppm');set(gca,'xdir','rev'); title('Reference Alignment data');axis tight;
        %             handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
        %
        %         elseif handles.tab_Reference_Alignment_index_for_plotting == 2 || handles.tab_Reference_Alignment_index_for_plotting == 3
        %
        %             ax2 = subplot(1,1,1,'Parent',handles.tab_Interval_Recognition_frame1);
        %             if handles.tab_Reference_Alignment_index_for_plotting == 2
        %                 plot(handles.data.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); title('Pre-Aligned Data');axis tight;
        %                 handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
        %             elseif handles.tab_Reference_Alignment_index_for_plotting == 3
        %                 plot(handles.data_new.ppm_mean,handles.data_new.data);set(gca,'xdir','rev'); xlabel('ppm');    title('Pre-Aligned Data');axis tight;
        %                 handles.x_axis_for_Interval_Recognition_table = handles.data_new.ppm_mean;
        %             end
        %
        %         end
        handles.previous_tab = 'Interval Recognition';
        
    elseif strcmp(tabName_New, 'Interval Alignment')
        handles.previous_tab = 'Interval Alignment';
        
    elseif strcmp(tabName_New, 'Quantification')
        handles.previous_tab = 'Quantification';
        
    elseif strcmp(tabName_New, 'Generate Report')
        handles.previous_tab = 'Generate Report';
        
    elseif strcmp(tabName_New, 'Lipoprotein Prediction')
        handles.previous_tab = 'Lipoprotein Prediction';
        
        load('ucdata2.mat')
        load('nmrdata2.mat')
        load('Final_Model2.mat')
        
        handles.Xref=nmrdata;
        handles.Yref=ucdata;
        handles.Model=Final_Model;
        
    end
    
catch e
    errordlg(e.message)
end

setappdata(0,'handles',handles)
end










% ==========================================================================================================================================================
% ==========================================================================================================================================================
% Functions
% ==========================================================================================================================================================
% ==========================================================================================================================================================


function LineSelected(ObjectH, EventData, H)
handles = getappdata(0,'handles');
try
    
    set(ObjectH, 'LineWidth', 2.5);
    set(H(H ~= ObjectH), 'LineWidth', 0.5);
    
catch e
    errordlg(e.message)
end

setappdata(0,'handles',handles)

end




function Add_new_interval(source,callbackdata,handles,ylim1,ColorSet)
handles = getappdata(0,'handles');
% try

x_loc = source.Callback{2}.tab_Interval_Recognition_frame1.Children.CurrentPoint(1,1);
n1 = find(handles.x_axis_for_Interval_Recognition_table > x_loc);
if isempty(n1)
    x_range = [handles.x_axis_for_Interval_Recognition_table(7) handles.x_axis_for_Interval_Recognition_table(1)];
else
    %n2 = handles.x_axis_for_Interval_Recognition_table(n1(end));
    n2 = n1(end);
    if n2 < 4
        x_range = [handles.x_axis_for_Interval_Recognition_table(7) handles.x_axis_for_Interval_Recognition_table(1)];
    elseif n2 > length(handles.x_axis_for_Interval_Recognition_table)-3
        x_range = [handles.x_axis_for_Interval_Recognition_table(end) handles.x_axis_for_Interval_Recognition_table(end-6)];
    else
        x_range = [handles.x_axis_for_Interval_Recognition_table(n1(end)+3) handles.x_axis_for_Interval_Recognition_table(n1(end)-3)];
    end
    
end
x_range = [x_range(2) x_range(1)];

% prompt = {'Enter Component Name:' , 'Class' , 'Variables Included (0 or 1)'};
% title = 'Input a desired name';
% dims = [1 35];
% definput = {'Com_name' , '1' , '1'};

%
prompt = {'Class','Interval name','End ppm:','Start ppm','Flex','Hs of SS','Hs total', ...
    'align','MCR PCs','Consistancy','Inc= 1;No= 0'};
title = 'Input dialog box';
dims = [1 50];
definput = {'1','metabolite' , '0.02','-0.02','0.001','1','1','1','1','1','1'};
%

Component_Name = inputdlg(prompt,title,dims,definput);

if ~isempty(Component_Name)
    x_range(1,1)=str2num(Component_Name{3,1});
    x_range(1,2)=str2num(Component_Name{4,1});
end

if isempty(Component_Name)
    return
end;



i= size(handles.sigma_plasma_options.intervals_ppm,1) + 1;
handles.sigma_plasma_options.intervals_ppm(i,:) = x_range;

y1 = ylim1(1);
y2 = ylim1(2);

ColorSet(i,:) = ColorSet(1,:);

hold on

if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([handles.sigma_plasma_options.intervals_ppm(i,1) handles.sigma_plasma_options.intervals_ppm(i,2)])
    msg='';
    filled=[[y1 y1],fliplr([y2 y2])];
    xpoints=[[handles.sigma_plasma_options.intervals_ppm(i,1) handles.sigma_plasma_options.intervals_ppm(i,2)],fliplr([handles.sigma_plasma_options.intervals_ppm(i,1) handles.sigma_plasma_options.intervals_ppm(i,2)])];
    if 0
        hold on
    end
    handles.fillhandle.(['i_raw' num2str(i)])=fill(xpoints,filled,ColorSet(i,:));%plot the data
    set(handles.fillhandle.(['i_raw' num2str(i)]),'EdgeColor',ColorSet(i,:),...
        'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',handles.sigma_plasma_options.intervals_ppm(i,:));%set edge color
    if 0
        hold off
    end
    
    cont.(['i_raw' num2str(i)]) = uicontextmenu;
else
    msg='Error: Must use the same number of points in each vector';
end

if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([handles.sigma_plasma_options.intervals_ppm(i,1) handles.sigma_plasma_options.intervals_ppm(i,2)])
    handles.fillhandle.(['i_raw' num2str(i)]).UIContextMenu = cont.(['i_raw' num2str(i)]);
    
    m1 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
    m2 = uimenu(cont.(['i_raw' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
end

%

new_met=i;
new_met_pars=cat(2,prompt',Component_Name);

new_met_clas=[str2num(new_met_pars{1,2})];
new_met_name=[new_met_pars(2,2)];
new_met_ppms=[str2num(new_met_pars{3,2}) str2num(new_met_pars{4,2})];
new_met_flex=[str2num(new_met_pars{5,2}) str2num(new_met_pars{5,2})]; 
new_met_prot=[str2num(new_met_pars{7,2}) str2num(new_met_pars{6,2})]; 
new_met_alig=[str2num(new_met_pars{8,2})];
new_met_MCRs=[str2num(new_met_pars{9,2})];
new_met_cons=[str2num(new_met_pars{10,2})];
new_met_vars=[str2num(new_met_pars{11,2})];

handles.sigma_plasma_options.intervals_class(new_met,:)=new_met_clas;
handles.sigma_plasma_options.intervals_name(new_met,:)=new_met_name;
% handles.sigma_plasma_options.intervals_ppm(new_met,:)=new_met_ppms; % Bz,
% it is already inserted by the user
handles.sigma_plasma_options.intervals_ppm_flex(new_met,:)=new_met_flex;
handles.sigma_plasma_options.intervals_SS_and_total_1H(new_met,:)=new_met_prot;
handles.sigma_plasma_options.intervals_Interative_Align(new_met,:)=new_met_alig;
handles.sigma_plasma_options.intervals_MCR_Components(new_met,:)=new_met_MCRs;
handles.sigma_plasma_options.intervals_consistant_occasional(new_met,:)=new_met_cons;
handles.sigma_plasma_options.VariablesIncluded(new_met,:)=new_met_vars;

hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
data = [(1:length(handles.sigma_plasma_options.intervals_name))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded handles.sigma_plasma_options.intervals_ppm_flex hihi_index];
kk = ~isnan(data(:,3));
kk2 = data(kk,:);
kk2 = sortrows(kk2,2);
unique_kk2 = unique(kk2(:,2));
kk4 = [];
for ii3 = 1:length(unique_kk2)
    unique_1 = (kk2(:,2) == unique_kk2(ii3));
    kk3 = sortrows(kk2(unique_1,:),3);
    kk4 = [kk4 ; kk3];
end

% hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
hihi_index=kk4(:,end);
kk4(:,end)=[];
    % Sort sigma_plasma_options Variable Parameters acording to above sorting
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
        end
    end



kk4 = [(1:size(kk4,1))' kk4(:,2:5)];

m0=[num2str(size(handles.sigma_plasma_options.intervals_class,1)) ' intervals are recognized'];
m1=[num2str(size(find(handles.sigma_plasma_options.intervals_class==1),1)) ' SS of metabolites (Class 1)'];
m2=[num2str(size(find(handles.sigma_plasma_options.intervals_class==2),1)) ' SUS of unknowns (Class 2)'];
m3=[num2str(size(find(handles.sigma_plasma_options.intervals_class==3),1)) ' BINS (Class 3)'];

intervals_name = handles.sigma_plasma_options.intervals_name;
set(handles.tab_Interval_Recognition_Identify_Intervals_listbox,'String',{m0;m1; m2;m3})
set(handles.Intervals_Selected_intervals_uitable, 'Data', kk4,'RowName',intervals_name)
set(handles.tab_Interval_Alignment_intervals_uitable, 'Data', kk4,'RowName',intervals_name)
% handles = sigma_ss_mapping_bkh(handles);
set(handles.tab_Interval_Recognition_Identify_Intervals_pushbutton,'backgroundcolor',[0.94 0.94 0.94]);
set(handles.tab_Interval_Recognition_Evaluate_Intervals_pb,'Enable','off');
% catch e
%     errordlg(e.message)
% end
setappdata(0,'handles',handles)

end






function changeThisItervals(source,callbackdata,handles,i,y,ColorSet)
handles = getappdata(0,'handles');
% try
legend off
intervals_ppm = handles.fillhandle.(['i_raw' num2str(i)]).UserData;

% handles.him.(['h' num2str(i) '1']) = imline(handles.tab_Interval_Recognition_frame1.Children,[handles.sigma_plasma_options.intervals_ppm(i,1) handles.sigma_plasma_options.intervals_ppm(i,1)], [y(1) y(2)]);
handles.him.(['h' num2str(i) '1']) = drawline('Position',[intervals_ppm(1),y(1); intervals_ppm(1), y(2)],'StripeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),'InteractionsAllowed','translate');
h1 = handles.him.(['h' num2str(i) '1']);
addlistener(handles.him.(['h' num2str(i) '1']),'ROIMoved',@(src,event)dragline_changeThisItervals(h1,handles,i,y,ColorSet));
% addlistener(handles.him.(['h' num2str(i) '1']),'ROIMoved',{@dragline_changeThisItervals,{h1,handles,i,y,ColorSet}});
% {@componentCallback,'check box'}
% {@displayCoordinates,ax}
% addlistener(handles.him.(['h' num2str(i) '1']),'ROIMoved',{@dragline_changeThisItervals,h1,handles,i,y,ColorSet});


% % handles.him.(['h' num2str(i) '1']) = imline(handles.tab_Interval_Recognition_frame1.Children,[intervals_ppm(1) intervals_ppm(1)], [y(1) y(2)]);
% % % handles.him.(['h' num2str(i) '1']) = images.roi.Line(handles.tab_Interval_Recognition_frame1.Children,'Position',[intervals_ppm(1)  y(1); intervals_ppm(1) y(2)]);
% % 
% % h1 = handles.him.(['h' num2str(i) '1']);
% % setColor(h1,[1 0 0])  % red color
% % fcn = makeConstrainToRectFcn('imline',handles.Intervals_xlim,handles.Intervals_ylim);
% % setPositionConstraintFcn(h1,fcn);
% % addNewPositionCallback(h1,@(h1)dragline_changeThisItervals(h1,handles,i,y,ColorSet));
% % %setColor(h1,ColorSet(size(ColorSet,1)+1-i,:))
% % setColor(h1,ColorSet(handles.sigma_plasma_options.intervals_class(i),:))


% handles.him.(['h' num2str(i) '2']) = imline(handles.tab_Interval_Recognition_frame1.Children,[handles.sigma_plasma_options.intervals_ppm(i,2) handles.sigma_plasma_options.intervals_ppm(i,2)], [y(1) y(2)]);






handles.him.(['h' num2str(i) '2']) = drawline('Position',[intervals_ppm(2),y(1);intervals_ppm(2), y(2)],'StripeColor',ColorSet(handles.sigma_plasma_options.intervals_class(i),:),'InteractionsAllowed','translate');
h2 = handles.him.(['h' num2str(i) '1']);
addlistener(handles.him.(['h' num2str(i) '2']),'ROIMoved',@(h2)dragline_changeThisItervals(h2,handles,i,y,ColorSet));






% % handles.him.(['h' num2str(i) '2']) = imline(handles.tab_Interval_Recognition_frame1.Children,[intervals_ppm(2) intervals_ppm(2)], [y(1) y(2)]);
% % h2 = handles.him.(['h' num2str(i) '2']);
% % setColor(h2,[1 0 0])  % red color
% % fcn = makeConstrainToRectFcn('imline',handles.Intervals_xlim,handles.Intervals_ylim);
% % setPositionConstraintFcn(h2,fcn);
% % addNewPositionCallback(h2,@(h2)dragline_changeThisItervals(h2,handles,i,y,ColorSet));
% % % setColor(h2,ColorSet(size(ColorSet,1)+1-i,:))
% % setColor(h2,ColorSet(handles.sigma_plasma_options.intervals_class(i),:))
%     legend(handles.legend_name_for_Interval_Recognition_tab)
% catch e
%     errordlg(e.message)
% end

setappdata(0,'handles',handles)

end







function changeThisItervals_for_validation(source,callbackdata,handles,i,y,ColorSet)
handles = getappdata(0,'handles');
% try
legend off
handles.him.(['h' num2str(i) '1']) = imline(handles.tab_Interval_Recognition_frame1.Children,[handles.sigma_plasma_options.intervals_ppm(i,1) handles.sigma_plasma_options.intervals_ppm(i,1)], [y(1) y(2)]);
h1 = handles.him.(['h' num2str(i) '1']);
setColor(h1,[1 0 0])  % red color
fcn = makeConstrainToRectFcn('imline',handles.Intervals_xlim,handles.Intervals_ylim);
setPositionConstraintFcn(h1,fcn);
addNewPositionCallback(h1,@(h1)dragline_changeThisItervals(h1,handles,i,y,ColorSet));
%setColor(h1,ColorSet(size(ColorSet,1)+1-i,:))
% setColor(h1,ColorSet(handles.sigma_plasma_options.intervals_class(i),:))


handles.him.(['h' num2str(i) '2']) = imline(handles.tab_Interval_Recognition_frame1.Children,[handles.sigma_plasma_options.intervals_ppm(i,2) handles.sigma_plasma_options.intervals_ppm(i,2)], [y(1) y(2)]);
h2 = handles.him.(['h' num2str(i) '2']);
setColor(h2,[1 0 0])  % red color
fcn = makeConstrainToRectFcn('imline',handles.Intervals_xlim,handles.Intervals_ylim);
setPositionConstraintFcn(h2,fcn);
addNewPositionCallback(h2,@(h2)dragline_changeThisItervals(h2,handles,i,y,ColorSet));
%setColor(h2,ColorSet(size(ColorSet,1)+1-i,:))
setColor(h2,ColorSet(handles.sigma_plasma_options.intervals_class(i),:))

legend(handles.legend_name_for_Interval_Recognition_tab)
% catch e
%     errordlg(e.message)
% end

setappdata(0,'handles',handles)

end











function dragline_changeThisItervals(h1,handles,i,y,ColorSet)
handles = getappdata(0,'handles');
try
    
    handles.x_axis_for_Interval_Recognition_table = handles.data.ppm_mean;
    
    intervals_ppm = handles.fillhandle.(['i_raw' num2str(i)]).UserData;
    
    
    temp = abs(intervals_ppm - h(1,1));
    loc1 = find(temp == min(temp));
    
    X1 = h(1,1);
    Xt1 = find(handles.x_axis_for_Interval_Recognition_table < X1);
    if isempty(Xt1)
        Xt1 = 1;
    end
    Xt1 = handles.x_axis_for_Interval_Recognition_table(Xt1(1));
    
    Xt2 = find(handles.x_axis_for_Interval_Recognition_table > X1);
    if isempty(Xt2)
        Xt2 = length(handles.x_axis_for_Interval_Recognition_table);
    end
    Xt2 = handles.x_axis_for_Interval_Recognition_table(Xt2(end));
    XData = Xt1;
    if Xt2 - X1 < Xt1 - X1
        XData = Xt2;
    end
    XData1 = find (handles.x_axis_for_Interval_Recognition_table == XData);
    XData2 = handles.x_axis_for_Interval_Recognition_table(XData1);
    
    if loc1 == 1
        handles.fillhandle.(['i_raw' num2str(i)]).Vertices =...
            [XData2 y(1);...
            intervals_ppm(2) y(1);...
            intervals_ppm(2) y(2);...
            XData2 y(2)];
        %handles.sigma_plasma_options.intervals_ppm(i,1) = XData2;
        intervals_ppm_new = [XData2 intervals_ppm(2)];
    elseif loc1 == 2
        handles.fillhandle.(['i_raw' num2str(i)]).Vertices =...
            [intervals_ppm(1) y(1);...
            XData2 y(1);...
            XData2 y(2);...
            intervals_ppm(1) y(2)];
        %handles.sigma_plasma_options.intervals_ppm(i,2) = XData2;
        intervals_ppm_new = [intervals_ppm(1) XData2];
    end
    
    
    %handles.sigma_plasma_options.intervals_ppm
    
    l1 = find(handles.sigma_plasma_options.intervals_ppm(:,1) == intervals_ppm_new(1));
    if ~isempty(l1)
        handles.sigma_plasma_options.intervals_ppm(l1,2) = intervals_ppm_new(2);
    else
        l2 = find(handles.sigma_plasma_options.intervals_ppm(:,2) == intervals_ppm_new(2));
        handles.sigma_plasma_options.intervals_ppm(l2,1) = intervals_ppm_new(1);
    end
    
    handles.fillhandle.(['i_raw' num2str(i)]).UserData = intervals_ppm_new;
    
    data = [(1:length(handles.sigma_plasma_options.intervals_name))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded handles.sigma_plasma_options.intervals_ppm_flex];
    
    
    set(handles.Intervals_Selected_intervals_uitable, 'Data', data(:,1:5),'RowName',handles.sigma_plasma_options.intervals_name)
    set(handles.tab_Interval_Alignment_intervals_uitable, 'Data', data(:,1:5),'RowName',handles.sigma_plasma_options.intervals_name)
    
catch e
    errordlg(e.message)
end

setappdata(0,'handles',handles)

end






function deleteItervals(source,callbackdata,handles,i,y,ColorSet)
handles = getappdata(0,'handles');
try
    
    intervals_ppm_new = handles.fillhandle.(['i_raw' num2str(i)]).UserData;
    delete(handles.fillhandle.(['i_raw' num2str(i)]))
    try
        delete(handles.him.(['h' num2str(i) '1']))
        delete(handles.him.(['h' num2str(i) '2']))
    end
    i
    
    l1 = find(handles.sigma_plasma_options.intervals_ppm(:,1) == intervals_ppm_new(1));
    %         handles.sigma_plasma_options.intervals_ppm(l1,2) = intervals_ppm_new(2);
    
    
    
    
    
    % Remove the Option Variables of the deleted Interval 
    % handles.sigma_plasma_options.intervals_ppm(l1,:) = [NaN NaN];
    h2=fieldnames(handles.sigma_plasma_options);
    name_size=size(handles.sigma_plasma_options.intervals_name,1);
    for hihi=1:length(fieldnames(handles.sigma_plasma_options))
        if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
            handles.sigma_plasma_options.(h2{hihi})(l1,:)=[];
        end
    end
    
    
    hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
    data = [(1:length(handles.sigma_plasma_options.intervals_name))' handles.sigma_plasma_options.intervals_class handles.sigma_plasma_options.intervals_ppm handles.sigma_plasma_options.VariablesIncluded handles.sigma_plasma_options.intervals_ppm_flex hihi_index];
    kk = ~isnan(data(:,3));
    kk2 = data(kk,:);
    kk2 = sortrows(kk2,2);
    unique_kk2 = unique(kk2(:,2));
    kk4 = [];
    for ii3 = 1:length(unique_kk2)
        unique_1 = (kk2(:,2) == unique_kk2(ii3));
        kk3 = sortrows(kk2(unique_1,:),3);
        kk4 = [kk4 ; kk3];
    end
    
    
        %hihi_index=[1:length(handles.sigma_plasma_options.intervals_name)]';
        hihi_index=kk4(:,end);
        kk4(:,end)=[];
        % Sort sigma_plasma_options Variable Parameters acording to above sorting
        h2=fieldnames(handles.sigma_plasma_options);
        name_size=size(handles.sigma_plasma_options.intervals_name,1);
        for hihi=1:length(fieldnames(handles.sigma_plasma_options))
            if size(handles.sigma_plasma_options.(h2{hihi}),1)==name_size
                handles.sigma_plasma_options.(h2{hihi})=handles.sigma_plasma_options.(h2{hihi})(hihi_index,:);
            end
        end
        
        intervals_name = handles.sigma_plasma_options.intervals_name;
    
   
    kk4 = [(1:size(kk4,1))' kk4(:,2:5)];
    
    
    set(handles.Intervals_Selected_intervals_uitable, 'Data', kk4,'RowName',intervals_name)
    set(handles.tab_Interval_Alignment_intervals_uitable, 'Data', kk4,'RowName',intervals_name)
    
    set(handles.tab_Interval_Recognition_Evaluate_Intervals_pb,'Enable','off');
    
    set(handles.tab_Interval_Recognition_Identify_Intervals_pushbutton,'backgroundcolor',[0.94 0.94 0.94]);
    
    
    % set(handles.Intervals_Selected_intervals_uitable, 'Data', kk2,'RowName',intervals_name)
    
catch e
    errordlg(e.message)
end

setappdata(0,'handles',handles)

end






function Interval_Recognition_uitable_CellEditCallback(source,callbackdata,handles)
handles = getappdata(0,'handles');


% try
if callbackdata.Indices(2) == 5
    Rowname1 = get(handles.Intervals_Selected_intervals_uitable,'Rowname');
    for jjj = 1 : length(handles.sigma_plasma_options.intervals_name)
        switch Rowname1{callbackdata.Indices(1)}
            case handles.sigma_plasma_options.intervals_name{jjj}
                loc_jjj = jjj;
                break
        end
    end
    data = get(handles.Intervals_Selected_intervals_uitable,'Data');
    set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data)
    handles.sigma_plasma_options.VariablesIncluded(loc_jjj) = data(callbackdata.Indices(1),callbackdata.Indices(2));
    setappdata(0,'handles',handles)
    return
end
callbackdata.Indices
try
    y = source.Parent.Parent.Children(1).Children.Children.YLim;
catch
    y = source.Parent.Parent.Children(1).Children.Children(2).YLim;
end

data = get(handles.Intervals_Selected_intervals_uitable,'Data');
set(handles.tab_Interval_Alignment_intervals_uitable,'Data',data)

Intervals = handles.sigma_plasma_options.intervals_ppm;
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
kk2 = sortrows(kk2,1);
kk3 = ~isnan(kk2(:,1));

intervals1 = Intervals(kk3,:);

if sum(data(:,3) - intervals1(:,1)) ~= 0
    temp = data(:,3) - intervals1(:,1);
    n1 = find(temp ~= 0);
    f = find(handles.sigma_plasma_options.intervals_ppm(:,1) == intervals1(n1,1));
    
    X1 = data(n1,3);
    Xt1 = find(handles.x_axis_for_Interval_Recognition_table < X1);
    if isempty(Xt1)
        Xt1 = 1;
    end
    Xt1 = handles.x_axis_for_Interval_Recognition_table(Xt1(1));
    
    Xt2 = find(handles.x_axis_for_Interval_Recognition_table > X1);
    if isempty(Xt2)
        Xt2 = length(handles.x_axis_for_Interval_Recognition_table);
    end
    Xt2 = handles.x_axis_for_Interval_Recognition_table(Xt2(end));
    XData = Xt1;
    if Xt2 - X1 < Xt1 - X1
        XData = Xt2;
    end
    XData1 = find (handles.x_axis_for_Interval_Recognition_table == XData);
    XData2 = handles.x_axis_for_Interval_Recognition_table(XData1);
    
    handles.fillhandle.(['i_raw' num2str(n1)]).Vertices =...
        [intervals1(n1,2) y(2);...
        XData2 y(2);...
        XData2 y(1);...
        intervals1(n1,2) y(1)];
    
    handles.sigma_plasma_options.intervals_ppm(f,1) = X1;
    
elseif sum(data(:,4) - handles.sigma_plasma_options.intervals_ppm(:,2)) ~= 0
    
    temp = data(:,4) - intervals1(:,2);
    n1 = find(temp ~= 0);
    f = find(handles.sigma_plasma_options.intervals_ppm(:,2) == intervals1(n1,2));
    
    X1 = data(n1,4);
    Xt1 = find(handles.x_axis_for_Interval_Recognition_table < X1);
    if isempty(Xt1)
        Xt1 = 1;
    end
    Xt1 = handles.x_axis_for_Interval_Recognition_table(Xt1(1));
    
    Xt2 = find(handles.x_axis_for_Interval_Recognition_table > X1);
    if isempty(Xt2)
        Xt2 = length(handles.x_axis_for_Interval_Recognition_table);
    end
    Xt2 = handles.x_axis_for_Interval_Recognition_table(Xt2(end));
    XData = Xt1;
    if Xt2 - X1 < Xt1 - X1
        XData = Xt2;
    end
    XData1 = find (handles.x_axis_for_Interval_Recognition_table == XData);
    XData2 = handles.x_axis_for_Interval_Recognition_table(XData1);
    
    handles.fillhandle.(['i_raw' num2str(n1)]).Vertices =...
        [intervals1(n1,1) y(2);...
        XData2 y(2);...
        XData2 y(1);...
        intervals1(n1,1) y(1)];
    
    handles.sigma_plasma_options.intervals_ppm(f,2) = X1;
    
else
    return
end





%     handles.sigma_plasma_options.VariablesIncluded






% catch e
%     errordlg(e.message)
% end

setappdata(0,'handles',handles)

end







% =========================================================================================================
% UIContextMenu
% =========================================================================================================


function tab_Import_Data_Delete_samp_and_var_pb_UI_cm(source,callbackdata,handles)
handles = getappdata(0,'handles');

set(handles.tab_Import_Data_Delete_samp_and_var_pushbutton,'Backgroundcolor',[0 1 0],'Tooltipstring','')

delete(handles.tab_Import_Data_Delete_samp_and_var_pushbutton.UIContextMenu)


handles.data.data = handles.data_new.data;
handles.data.ppm_mean = handles.data_new.ppm_mean;

handles.sample_AcqPars =handles.sample_AcqPars_new;
handles.sample_ProcPars = handles.sample_ProcPars_new;
handles.sigma_plasma_options = handles.sigma_plasma_options_new;

handles.data_new = [];
handles.sample_AcqPars_new = [];
handles.sample_ProcPars_new = [];
handles.sigma_plasma_options_new = [];

% % Run "sigma_CheckSize_bkh"
% [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
%     (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
% RUN "sigma_Check_Intervals_bkh"
[handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);



set(handles.tab_Import_Data_save_pushbutton,'Enable','off')
% rmfield(handles,'data_new')
% rmfield(handles,'sample_AcqPars_new')
% rmfield(handles,'sample_ProcPars_new')
% rmfield(handles,'sigma_plasma_options_new')

setappdata(0,'handles',handles)

end





function tab_Import_Data_Apply_norm_pb_UI_cm(source,callbackdata,handles)
handles = getappdata(0,'handles');

set(handles.tab_Import_Data_Apply_norm_pushbutton,'Backgroundcolor',[0 1 0],'Tooltipstring','')

delete(handles.tab_Import_Data_Apply_norm_pushbutton.UIContextMenu)


handles.data.data = handles.data_new.data;

handles.data_new.data = [];
handles.data_new.ppm_mean = [];

% % Run "sigma_CheckSize_bkh"
% [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
%     (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
% RUN "sigma_Check_Intervals_bkh"
[handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);


set(handles.tab_Import_Data_save_pushbutton,'Enable','off')

setappdata(0,'handles',handles)

end












% Reference Alignment
% =========================================================================================================

function Reference_Alignment_Align_Ref_Signal_pushbutton_cm(source,callbackdata,handles)
handles = getappdata(0,'handles');

set(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton,'BackgroundColor',[0 1 0],'Tooltipstring','')

delete(handles.tab_Reference_Alignment_Align_Ref_Signal_pushbutton.UIContextMenu)

handles.data.data = handles.data_new.data;
handles.data.ppm_mean = handles.data_new.ppm_mean;

handles.data_new.data = [];
% handles.data_new.ppm_mean = [];

% % Run "sigma_CheckSize_bkh"
% [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
%     (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
% RUN "sigma_Check_Intervals_bkh"
[handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);


handles.tab_Reference_Alignment_index_for_plotting = 1;

set(handles.tab_Reference_Alignment_save_pushbutton,'Enable','off')

setappdata(0,'handles',handles)

end







function Reference_Alignment_Pre_Align_Spectra_pb_cm(source,callbackdata,handles)
handles = getappdata(0,'handles');

set(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton,'BackgroundColor',[0 1 0],'Tooltipstring','','Enable','off')

delete(handles.tab_Reference_Alignment_Pre_Align_Spectra_pushbutton.UIContextMenu)

handles.data.data = handles.data_new.data;

handles.data_new.data = [];
handles.data_new.ppm_mean = [];

% % Run "sigma_CheckSize_bkh"
% [handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean]=sigma_CheckSize_bkh...
%     (handles.sigma_plasma_options.ref_spect,handles.sigma_plasma_options.ref_spect_ppm,handles.data.data,handles.data.ppm_mean);
% RUN "sigma_Check_Intervals_bkh"
[handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);


handles.tab_Reference_Alignment_index_for_plotting = 2;

set(handles.tab_Reference_Alignment_save_pushbutton,'Enable','off')

setappdata(0,'handles',handles)

end







% Interval Recognition
% =========================================================================================================


function Interval_Recognition_Identify_Intervals_pb_cm(source,callbackdata,handles)
handles = getappdata(0,'handles');

set(handles.tab_Interval_Recognition_Identify_Intervals_pushbutton,'BackgroundColor',[0 1 0],'Tooltipstring','')

delete(handles.tab_Interval_Recognition_Identify_Intervals_pushbutton.UIContextMenu)

% handles.data.data = handles.data_new.data;
handles.sigma_plasma_options = handles.sigma_plasma_options_new;
handles.sigma_plasma_options_new = [];

% handles.data_new.data = [];
% handles.data_new.ppm_mean = [];

set(handles.tab_Interval_Recognition_save_pushbutton,'Enable','off')

setappdata(0,'handles',handles)

end



% Lp_Prediction
% =========================================================================================================


function tab_Lp_Prediction_Delete_samp_and_var_pb_UI_cm(source,callbackdata,handles)
handles = getappdata(0,'handles');

set(handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton,'Backgroundcolor',[0 1 0],'Tooltipstring','')

delete(handles.tab_Lp_Prediction_Delete_samp_and_var_pushbutton.UIContextMenu)


handles.data.data = handles.data_new.data;
handles.data.ppm_mean = handles.data_new.ppm_mean;

handles.sample_AcqPars =handles.sample_AcqPars_new;
handles.sample_ProcPars = handles.sample_ProcPars_new;
handles.sigma_plasma_options = handles.sigma_plasma_options_new;

handles.data_new = [];
handles.sample_AcqPars_new = [];
handles.sample_ProcPars_new = [];
handles.sigma_plasma_options_new = [];

% % Run "sigma_CheckSize_bkh"
[handles.sigma_plasma_options]=sigma_Check_Intervals_bkh(handles.sigma_plasma_options,handles.data.ppm_mean);


setappdata(0,'handles',handles)

end




function tab_Lp_Prediction_CHECK_X_TEST_pb_UI_cm(source,callbackdata,handles)
handles = getappdata(0,'handles');



set(handles.tab_Lp_Prediction_CHECK_X_TEST_pushbutton,'Backgroundcolor',[0 1 0],'Tooltipstring','')
handles.data.data = handles.data_new.data;
handles.data.ppm = handles.data_new.ppm;
handles.data.ppm_mean = handles.data_new.ppm_mean;
handles.data_new = [];



setappdata(0,'handles',handles)

end



