function Temp(varargin)
%  http://de.mathworks.com/help/matlab/examples/creating-a-user-interface-with-tab-panels.html#zmw57dd0e8852

% handles.sample = varargin{1};
% handles.wavelengths = varargin{2};
% 
% if isempty(handles.wavelengths)
%     handles.wavelengths=(1:size(handles.sample,3));
% end
% 
% handles.mask = varargin{3};


% Objects Used to Create Tab Panels
% =============================================================================================================================

handles.f = figure('Visible','off','Position',[140 110 1200 590], 'resize', 'on');
handles.f.Name = 'PARADISe V.1.0';
movegui(handles.f,'center')


warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
jframe=get(handles.f,'javaframe');
jIcon=javax.swing.ImageIcon('Icon.png');
jframe.setFigureIcon(jIcon);



handles.tgroup = uitabgroup('Parent', handles.f);
handles.tab_Import_and_view = uitab('Parent', handles.tgroup, 'Title', 'Import & View');
% handles.tab_View = uitab('Parent', handles.tgroup, 'Title', 'View');
handles.tab_Preprocessing = uitab('Parent', handles.tgroup, 'Title', 'Preprocessing');
handles.tab_Intervals = uitab('Parent', handles.tgroup, 'Title', 'Intervals');
handles.tab_Resolve = uitab('Parent', handles.tgroup, 'Title', 'Resolve');
handles.tab_Identification = uitab('Parent', handles.tgroup, 'Title', 'Identification');
handles.tab_Export = uitab('Parent', handles.tgroup, 'Title', 'Export');

set(handles.tgroup,'SelectionChangedFcn',{@tabChangedCB,handles})

% Change Tabgroup and Tab Properties
% =============================================================================================================================

handles.tab_Import_and_view.ForegroundColor = 'blue';
handles.tab_Preprocessing.ForegroundColor = [0.180392 0.545098 0.341176];

% handles.tab_View.ForegroundColor = [0.180392 0.545098 0.341176];
handles.tab_Intervals.ForegroundColor = [0.180392 0.545098 0.341176];
handles.tab_Resolve.ForegroundColor = 'magenta';
handles.tab_Identification.ForegroundColor = 'magenta';
handles.tab_Export.ForegroundColor = 'red';

handles.tgroup.SelectedTab = handles.tab_Import_and_view;

% UIMenu
% -------------------------------------------------------------------------
f = uimenu('Label','PARADISe Help');
uimenu(f,'Label','Import & View','Callback',@Import_and_view_uimenu_help);
uimenu(f,'Label','Preprocessing(icoshiftMC)','Callback',@Preprocessing_uimenu_help);
%     uimenu(handles.f.muUImenu,'Label','Quit','Callback','disp(''exit'')',...
%            'Separator','on','Accelerator','Q');
uimenu(f,'Label','Intervals','Callback',@Intervals_uimenu_help);
uimenu(f,'Label','Resolve','Callback',@Resolve_uimenu_help);
uimenu(f,'Label','Identification','Callback',@Identification_uimenu_help);
uimenu(f,'Label','Export','Callback',@Export_uimenu_help);



  
    
    

% Add Components to Tabs
% =============================================================================================================================
% =============================================================================================================================

% Import and view part
% =============================================================================================================================

[handles.h1_tab_Import_and_view,handles.h2_tab_Import_and_view,handles.hDivider1_tab_Import_and_view] = uisplitpane(handles.tab_Import_and_view);
set(handles.hDivider1_tab_Import_and_view,'DividerColor','green')
handles.hDivider1_tab_Import_and_view.DividerLocation = 0.15;

[handles.h3_tab_Import_and_view,handles.h4_tab_Import_and_view,handles.hDivider2_tab_Import_and_view] = uisplitpane(handles.h2_tab_Import_and_view,'Orientation','ver');
set(handles.hDivider2_tab_Import_and_view,'DividerColor','green')
handles.hDivider2_tab_Import_and_view.DividerLocation = 0.001;


handles.Import_and_view_Import_data_pushbutton = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton','FontWeight','bold', 'String',...
    'Import Data','Callback',{@Import_and_view_Import_data_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [50 550 80 30]) ;

handles.Import_and_view_Import_data_listbox_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'Samples:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 520 70 20]) ;

handles.Import_and_view_Import_data_listbox = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [5 370 150 150],'Visible','off','Callback',{@Import_and_view_Import_data_listbox_Callback,handles}) ;

handles.Import_and_view_delete_pushbutton = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton', 'String',...
    'Remove samples','Visible','off','Callback',{@Import_and_view_delete_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [35 340 100 25]) ;

handles.Import_and_view_overlay_popupmenu_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'Plot:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 295 40 20]) ;

handles.Import_and_view_overlay_popupmenu = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'popupmenu', 'String',[{'Subplot'} ; {'Overlay'} ; {'Sample-wise'}],...
    'Visible','off','FontSize',8,'Callback',{@Import_and_view_overlay_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [33 295 90 25]) ;

handles.Import_and_view_show_type_popupmenu_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'Chromatogram:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 260 90 20]) ;

handles.Import_and_view_show_type_popupmenu = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'popupmenu', 'String',...
    [{'TIC'} ; {'EIC'} ; {'BPC'} ; {'Surf'}],'Visible','off',...
    'Callback',{@Import_and_view_show_type_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [85 260 60 25]) ;

handles.Import_and_view_m_to_z_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'm/z range:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 235 70 20]) ;

handles.Import_and_view_m_to_z_edit = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'edit','Visible','off','Position', [60 235 50 25]) ;

handles.Import_and_view_m_to_z_pushbutton = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton','Visible','off', 'String',...
    'Plot','Callback',{@Import_and_view_m_to_z_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [115 235 55 25]) ;

handles.Import_and_view_colormap_type_popupmenu_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'Colormap:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 220 70 20]) ;

handles.Import_and_view_colormap_type_popupmenu = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'popupmenu', 'String',...
    [{'PARADAISe'} ; {'jet'} ; {'parula'} ; {'hsv'} ; {'hot'} ; {'cool'} ; {'spring'} ; {'summer'} ; {'autumn'} ; {'winter'} ; {'gray'} ; {'bone'} ;...
    {'copper'} ; {'pink'} ; {'lines'} ; {'colorcube'} ; {'prism'} ; {'flag'} ],'Visible','off',...
    'Callback',{@Import_and_view_colormap_type_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [65 220 90 25]) ;

handles.Import_and_view_view_MS_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'View MS: ===============','FontSize',9,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 185 170 20]) ;

handles.Import_and_view_view_MS_pushbutton1 = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton', 'String',...
    'Point','FontSize',9,'FontWeight','bold','Callback',{@Import_and_view_view_MS_pushbutton1_Callback,handles},'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 160 65 25]) ;

% s = sprintf('Press mouse right click for changing zoom selection mode');
handles.Import_and_view_view_MS_pushbutton1.TooltipString = 'Press mouse right click for changing zoom selection mode';

c = uicontextmenu;
handles.Import_and_view_view_MS_pushbutton1.UIContextMenu = c;
handles.Import_and_view_view_MS_pushbutton1_UIContextMenu1 = uimenu(c,'Label','With zoom','Callback',@MZ_Zoom);
handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2 = uimenu(c,'Label','Without zoom','Callback',@MZ_Zoom);
set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2,'Checked','on')
handles.Import_and_view_view_MS_pushbutton1_zoom = 2;



handles.Import_and_view_view_MS_pushbutton2 = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton', 'String',...
    'Range','FontSize',9,'FontWeight','bold','Callback',{@Import_and_view_view_MS_pushbutton2_Callback,handles},'Visible','off', 'HorizontalAlignment', 'left', 'Position', [100 160 65 25]) ;

% s = sprintf('Press mouse right click for changing zoom selection mode');
handles.Import_and_view_view_MS_pushbutton2.TooltipString = 'Press mouse right click for changing zoom selection mode';

c1 = uicontextmenu;
handles.Import_and_view_view_MS_pushbutton2.UIContextMenu = c1;
handles.Import_and_view_view_MS_pushbutton2_UIContextMenu1 = uimenu(c1,'Label','With zoom','Callback',@MZ_Zoom2);
handles.Import_and_view_view_MS_pushbutton2_UIContextMenu2 = uimenu(c1,'Label','Without zoom','Callback',@MZ_Zoom2);
set(handles.Import_and_view_view_MS_pushbutton2_UIContextMenu2,'Checked','on')
handles.Import_and_view_view_MS_pushbutton2_zoom = 2;


















handles.folder_for_search_results_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'Folder for search results:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 125 130 20]) ;

handles.Import_and_view_dir_for_save_pushbutton = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton', 'String',...
    'Change','Callback',{@Import_and_view_dir_for_save_pushbutton_Callback,handles},'Visible','off', 'HorizontalAlignment', 'left', 'Position', [130 125 50 25]) ;

handles.Import_and_view_dir_for_save_edit = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'edit','Visible','off','Position', [2 103 175 20]) ;




% handles.Import_and_view_dir_for_save_pushbutton = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton', 'String',...
%     'dir. for save','FontSize',9,'FontWeight','bold','Callback',{@Import_and_view_dir_for_save_pushbutton_Callback,handles},'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 110 80 25]) ;

handles.Import_and_view_NIST_search_pushbutton = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton', 'String',...
    'NIST search','FontSize',9,'FontWeight','bold','Callback',{@Import_and_view_NIST_search_pushbutton_Callback,handles},'Visible','off', 'HorizontalAlignment', 'left', 'Position', [40 70 85 25]) ;

handles.Import_and_view_new_plot_pushbutton = uicontrol('Parent',handles.h1_tab_Import_and_view, 'Style', 'pushbutton', 'String',...
    'New plot','Callback',{@Import_and_view_new_plot_pushbutton_Callback,handles},'Visible','off', 'HorizontalAlignment', 'left', 'Position', [25 12 65 25]) ;

% s = sprintf('Show plot in separate window');
handles.Import_and_view_new_plot_pushbutton.TooltipString = 'Show plot in separate window';


handles.Import_and_view_wait_str = uicontrol('Parent', handles.h1_tab_Import_and_view, 'Style', 'text', 'String',...
    'Wait ...','FontSize',8,'Visible','off','Backgroundcolor',[1 0 0], 'HorizontalAlignment', 'center', 'Position', [100 17 50 15]) ;


handles.Import_and_view_frame1 = uipanel('Parent', handles.h4_tab_Import_and_view, 'Position',[.000001 .0000001 .999 .999]);

try
    load Import_and_view_dir_for_save_str
    handles.Import_and_view_dir_for_save_str = Import_and_view_dir_for_save_str;
catch
    handles.Import_and_view_dir_for_save_str = cd;
    Import_and_view_dir_for_save_str = handles.Import_and_view_dir_for_save_str;
    save Import_and_view_dir_for_save_str Import_and_view_dir_for_save_str
end
set(handles.Import_and_view_dir_for_save_edit,'String',handles.Import_and_view_dir_for_save_str)









% Preprocessing part
% =============================================================================================================================

[handles.h1_tab_Preprocessing,handles.h2_tab_Preprocessing,handles.hDivider1_tab_Preprocessing] = uisplitpane(handles.tab_Preprocessing);
set(handles.hDivider1_tab_Preprocessing,'DividerColor','green')
handles.hDivider1_tab_Preprocessing.DividerLocation = 0.15;

[handles.h3_tab_Preprocessing,handles.h4_tab_Preprocessing,handles.hDivider2_tab_Preprocessing] = uisplitpane(handles.h2_tab_Preprocessing,'Orientation','ver');
set(handles.hDivider2_tab_Preprocessing,'DividerColor','green')
handles.hDivider2_tab_Preprocessing.DividerLocation = 0.001;

[handles.h5_tab_Preprocessing,handles.h6_tab_Preprocessing,handles.hDivider3_tab_Preprocessing] = uisplitpane(handles.h4_tab_Preprocessing);
set(handles.hDivider3_tab_Preprocessing,'DividerColor','green')
handles.hDivider3_tab_Preprocessing.DividerLocation = 0.8;

handles.Preprocessing_target_samples_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Target Samples:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 560 85 20]) ;

handles.Preprocessing_target_samples_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu', 'String',[{'All samples'} ; {'Select samples'}],...
    'Visible','on','FontSize',8,'Callback',{@Preprocessing_target_samples_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [85 565 95 20]) ;

handles.Preprocessing_target_vector_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Target vector:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 525 80 20]) ;

handles.Preprocessing_target_vector_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu', 'String',[{'average'} ; {'median'} ; {'max'}],...
    'Visible','on','FontSize',8,'Callback',{@Preprocessing_target_vector_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [80 530 75 20]) ;

handles.Preprocessing_space_str1 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    '----------------------------------','FontSize',11,'FontWeight','bold','Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 510 190 15]) ;

handles.Preprocessing_alignment_mode_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Alignment mode:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 484 90 20]) ;

handles.Preprocessing_alignment_mode_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
    'String',[{'whole'} ; {'nint'} ; {'ndata'} ; {'Int. def.'} ; {'refs:refe'} ; {'refs-refe'}],...
    'Visible','on','FontSize',8,'Callback',{@Preprocessing_alignment_mode_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [90 487 75 20]) ;

handles.Preprocessing_Intervals_alignment_mode_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Input:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 458 70 20]) ;

handles.Preprocessing_Intervals_alignment_mode_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit','Visible','off','Position', [60 460 80 20]) ;

handles.Preprocessing_space_str2 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    '----------------------------------','FontSize',11,'FontWeight','bold','Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 447 190 13]) ;

handles.Preprocessing_Channels_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Channels:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 422 90 20]) ;

handles.Preprocessing_Channels_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
    'String',[{'corrProd'} ; {'corrSum'} ; {'corrMax'} ; {'corrTrimSum'} ; {'corrTrimProd'} ; {'sum'} ; {'max'} ; {'[ch1, ch2,...]'} ; {'ch1, ... ch10-ch13,...'}],...
    'Visible','on','FontSize',8,'Callback',{@Preprocessing_Channels_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [60 424 95 20]) ;

handles.Preprocessing_Channels_popupmenu_str2 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Input:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 396 70 20]) ;

handles.Preprocessing_Channels_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit','Visible','off','Position', [60 398 80 20]) ;


handles.Preprocessing_space_str3 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    '----------------------------------','FontSize',11,'FontWeight','bold','Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 384 190 13]) ;

handles.Preprocessing_Shift_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Shift:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 358 90 20]) ;

handles.Preprocessing_Shift_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
    'String',[{'Maximum shift'} ; {'Best'} ; {'Fast'}],...
    'Visible','on','FontSize',8, 'Value', 2,'Callback',{@Preprocessing_Shift_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [40 361 95 20]) ;

handles.Preprocessing_Shift_popupmenu_str2 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Input:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 330 70 20]) ;

handles.Preprocessing_Shift_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit','Visible','off','Position', [60 331 80 20]) ;

handles.Preprocessing_space_str4 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    '----------------------------------','FontSize',11,'FontWeight','bold','Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 318 190 13]) ;

handles.Preprocessing_options_first_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Options:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 290 170 20]) ;

handles.Preprocessing_options_first_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
    'String',[{'Triggers plots'} ; {'Filling mode'} ; {'Co-shift preprocessing'} ; {'Max allowed shift'} ; {'intervals'} ; {'corrThresh'}],...
    'Visible','on','FontSize',8,'Callback',{@Preprocessing_options_first_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [60 290 95 25]) ;

handles.Preprocessing_options_second_popupmenu_str2 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Inputs:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 261 60 20]) ;

handles.Preprocessing_options_second_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
    'String',[{'Only warnings'} ; {'No on-screen output'} ; {'warnings and plots'}],'Value',3,...
    'Visible','on','FontSize',8,'Callback',{@Preprocessing_options_second_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [60 261 95 25]) ;

handles.Preprocessing_Channels_options_edit_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Input range:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [5 235 70 20]) ;

handles.Preprocessing_Channels_options_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit',...
    'Callback',{@Preprocessing_Channels_options_edit_Callback,handles},'Visible','off','Position', [70 237 70 20]) ;

handles.Preprocessing_options_listbox = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'Listbox', 'String', ' ', ...
    'max',1,'HorizontalAlignment', 'left', 'Position', [5 163 170 70],'Visible','on') ;

handles.Preprocessing_run_pushbutton = uicontrol('Parent',handles.h1_tab_Preprocessing, 'Style', 'pushbutton', 'String',...
    'Align','FontSize',11,'FontWeight','bold','Visible','on','Callback',{@Preprocessing_run_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [5 127 75 30]) ;


handles.Preprocessing_accept_checkbox = uicontrol('Parent',handles.h1_tab_Preprocessing, 'Style', 'checkbox', 'String',...
    'Accept','FontSize',11,'FontWeight','bold','Callback',{@Preprocessing_accept_checkbox_Callback,handles}, 'HorizontalAlignment', 'left','Value',0, 'Position', [90 129 75 25]) ;








handles.Preprocessing_data_listbox_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Samples:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 104 70 20]) ;

handles.Preprocessing_data_listbox = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'Listbox', 'String', ' ', ...
    'max',100000,'HorizontalAlignment', 'left', 'Position', [5 16 170 86],'Visible','on','Callback',{@Preprocessing_data_listbox_Callback,handles}) ;


% Visualize Part
%-------------------------------------------------------------------------------------------------------------------------

% handles.Preprocessing_overlay_popupmenu_str = uicontrol('Parent', handles.h3_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Plot:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 80 40 20]) ;
% 
% handles.Preprocessing_overlay_popupmenu = uicontrol('Parent', handles.h3_tab_Preprocessing, 'Style', 'popupmenu', 'String',[{'Subplot'} ; {'Overlay'} ; {'Sample-wise'}],...
%     'Visible','off','FontSize',8,'Callback',{@Import_and_view_overlay_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [33 275 90 25]) ;

handles.Preprocessing_frame1 = uipanel('Parent', handles.h5_tab_Preprocessing, 'Position',[.000001 .0000001 .999 .999]);

handles.Preprocessing_frame2 = uipanel('Parent', handles.h6_tab_Preprocessing, 'Position',[.000001 .0000001 .999 .999]);

handles.Preprocessing_Options = checkOptions;
handles.Preprocessing_Options.show = 2;
handles.Preprocessing_options_listbox_str = [{'Triggers plots ==> Only warnings'} ; {'Filling mode ==> Using previous point'} ; {'Co-shift preprocessing ==> No Co-shift preprocessing'};...
    {'Max allowed shift ==> 0'} ; {'Intervals ==> Intervals are given in No. of datapoints'} ; {'CorrThresh ==> 0'}];

set(handles.Preprocessing_options_listbox,'String',handles.Preprocessing_options_listbox_str)

handles.Preprocessing_wait_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
    'Wait ...','FontSize',8,'Visible','off','Backgroundcolor',[1 0 0], 'HorizontalAlignment', 'center', 'Position', [55 1 50 13]) ;

handles.preprocessing_accept_checkbox_val = 0;








% Intervals part
% =============================================================================================================================

[handles.h1_tab_Intervals,handles.h2_tab_Intervals,handles.hDivider1_tab_Intervals] = uisplitpane(handles.tab_Intervals);
set(handles.hDivider1_tab_Intervals,'DividerColor','green')
handles.hDivider1_tab_Intervals.DividerLocation = 0.165;

[handles.h3_tab_Intervals,handles.h4_tab_Intervals,handles.hDivider2_tab_Intervals] = uisplitpane(handles.h2_tab_Intervals,'Orientation','ver');
set(handles.hDivider2_tab_Intervals,'DividerColor','green')
handles.hDivider2_tab_Intervals.DividerLocation = 0.15;



handles.Intervals_run_pushbutton = uicontrol('Parent',handles.h1_tab_Intervals, 'Style', 'pushbutton', 'String',...
    'Run','Callback',{@Intervals_run_Callback,handles},'FontSize',11,'FontWeight','bold', 'HorizontalAlignment', 'center', 'Position', [70 555 65 30]) ;

handles.Intervals_No_of_detected_intervals_str1 = uicontrol('Parent', handles.h1_tab_Intervals, 'Style', 'text', 'String',...
    'No. of detected intervals:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 530 140 20]) ;

handles.Intervals_No_of_detected_intervals_str2 = uicontrol('Parent', handles.h1_tab_Intervals, 'Style', 'text', 'String',...
    ' ','FontSize',9,'Visible','on','BackgroundColor',[0.690196 0.878431 0.901961], 'Position', [135 532 50 20]) ;



handles.Intervals_frame_more_options = uipanel('Parent', handles.h1_tab_Intervals, 'Title','More options','FontSize',10,'FontWeight','bold', 'Position',[.001 .4 .999 .48]);

handles.Intervals_frame_more_options_preprocessing = uipanel('Parent', handles.Intervals_frame_more_options, 'Title','Preprocessing', 'Position',[.001 .56 .999 .42]);

handles.Intervals_frame_more_options_variables = uipanel('Parent', handles.Intervals_frame_more_options, 'Title','Variables', 'Position',[.001 .1 .999 .41]);


handles.Intervals_continue_until_next_minimum_checkbox = uicontrol('Parent', handles.Intervals_frame_more_options, 'Style', 'checkbox', 'String',...
    'Continue until next minimum','Callback',{@Intervals_continue_until_next_minimum_checkbox_Callback,handles}, 'HorizontalAlignment',...
    'left','Value',1, 'Position', [5 1 185 25]) ;

handles.Intervals_until_next_minimum_checkbox_val = 1;




handles.Intervals_more_options_prepro_beads_checkbox = uicontrol('Parent', handles.Intervals_frame_more_options_preprocessing, 'Style', 'checkbox', 'String',...
    'beads','Callback',{@Intervals_more_options_prepro_beads_checkbox_Callback,handles}, 'HorizontalAlignment',...
    'left','Value',0, 'Position', [5 60 75 25]) ;

handles.Intervals_more_options_prepro_msbackadj_checkbox = uicontrol('Parent', handles.Intervals_frame_more_options_preprocessing, 'Style', 'checkbox','Value',1, 'String',...
    'msbackadj','Callback',{@Intervals_more_options_prepro_msbackadj_checkbox_Callback,handles}, 'HorizontalAlignment',...
    'left','Value',0, 'Position', [5 30 75 25]) ;

handles.Intervals_more_options_prepro_listbox = uicontrol('Parent', handles.Intervals_frame_more_options_preprocessing, 'Style', 'Listbox', 'String', 'None', ...
    'max',2,'HorizontalAlignment', 'left', 'Position', [80 35 75 50],'Visible','on') ;

handles.Intervals_up_2_down_pushbutton = uicontrol('Parent',handles.Intervals_frame_more_options_preprocessing, 'Style', 'pushbutton', ...
    'Callback',{@Intervals_up_2_down_pushbutton_Callback,handles},'FontSize',11,'FontWeight','bold', 'HorizontalAlignment', 'center', 'Position', [156 42 31 31]) ;

hh=imread('up_2_down.png');
hh=imresize(hh, [22 22]);
set(handles.Intervals_up_2_down_pushbutton,'CData',hh);
set(handles.Intervals_up_2_down_pushbutton,'Visible','on');

handles.Intervals_more_options_prepro_plot_pushbutton = uicontrol('Parent',handles.Intervals_frame_more_options_preprocessing, 'Style', 'pushbutton', 'String',...
    'Plot','Callback',{@Intervals_more_options_prepro_plot_pushbutton_Callback,handles}, 'HorizontalAlignment', 'center', 'Position', [60 5 65 25]) ;











handles.Intervals_more_options_variables_std_str = uicontrol('Parent', handles.Intervals_frame_more_options_variables, 'Style', 'text', 'String',...
    'Standard deviation:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [1 60 110 20]) ;

handles.Intervals_more_options_variables_std_edit = uicontrol('Parent', handles.Intervals_frame_more_options_variables, 'Style', 'edit','String',...
    '.1','Visible','on','Position', [15 42 60 20]) ;

handles.Intervals_more_options_variables_Interval_width_str = uicontrol('Parent', handles.Intervals_frame_more_options_variables, 'Style', 'text', 'String',...
    'Interval width:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [110 60 110 20]) ;

handles.Intervals_more_options_variables_Interval_width_edit = uicontrol('Parent', handles.Intervals_frame_more_options_variables, 'Style', 'edit','String',...
    '.01','Visible','on','Position', [113 42 60 20]) ;

handles.Intervals_more_options_variables_Space_str = uicontrol('Parent', handles.Intervals_frame_more_options_variables, 'Style', 'text', 'String',...
    'Space between two intervals:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [25 20 150 20]) ;

handles.Intervals_more_options_variables_Space_edit = uicontrol('Parent', handles.Intervals_frame_more_options_variables, 'Style', 'edit','String',...
    '.01','Visible','on','Position', [65 5 60 20]) ;









handles.Intervals_Selected_intervals_str = uicontrol('Parent', handles.h1_tab_Intervals, 'Style', 'text', 'String',...
    'Selected intervals:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 195 110 20]) ;

% handles.Intervals_Selected_intervals_uitable = uicontrol('Parent', handles.h1_tab_Intervals, 'Style', 'Listbox', 'String', '---', ...
%     'max',10000,'HorizontalAlignment', 'left', 'Position', [5 92 185 100],'Visible','on') ;





columnname = {'Start','End','QuantIon'};
columnformat = {'numeric','numeric','Char'};
rnames = {1 2 3};
d =    {};
handles.Intervals_Selected_intervals_uitable = uitable('Parent',handles.h1_tab_Intervals,'Data', d,... 
            'ColumnName', columnname, 'ColumnFormat', columnformat, 'ColumnEditable', [false false true],...
            'RowName',rnames,'ColumnWidth',{50 50 80}, 'Position', [5 77 185 120]);

handles.Intervals_Selected_intervals_uitable.BackgroundColor = [1 1 1;0.690196 0.878431 0.901961];
% handles.Intervals_Selected_intervals_uitable.ColumnWidth = {40 40 40 40};



handles.Intervals_save_pushbutton = uicontrol('Parent',handles.h1_tab_Intervals, 'Style', 'pushbutton', 'String',...
    'Save','Callback',{@Intervals_save_pushbutton_Callback,handles},'FontSize',10,'FontWeight','bold', 'HorizontalAlignment', 'center', 'Position', [5 23 50 30]) ;

handles.Intervals_save_to_excel_pushbutton = uicontrol('Parent',handles.h1_tab_Intervals, 'Style', 'pushbutton', 'String','Save area to excel', 'Visible','off',...
    'Callback',{@Intervals_save_to_excel_pushbutton_Callback,handles},'FontSize',10,'FontWeight','bold', 'HorizontalAlignment', 'center', 'Position', [60 23 135 30]) ;




handles.Intervals_frame1 = uipanel('Parent', handles.h4_tab_Intervals, 'Position',[.001 .001 .999 .999]);



handles.Intervals_wait_str = uicontrol('Parent', handles.h1_tab_Intervals, 'Style', 'text', 'String',...
    'Wait ...','FontSize',8,'Visible','off','Backgroundcolor',[1 0 0], 'HorizontalAlignment', 'center', 'Position', [55 1 50 13]) ;





handles.Intervals_calculate_area_pushbutton = uicontrol('Parent',handles.h3_tab_Intervals, 'Style', 'pushbutton', 'String','Calculate Area', 'Visible','off',...
    'Callback',{@Intervals_calculate_area_pushbutton_Callback,handles},'FontSize',9,'FontWeight','bold', 'HorizontalAlignment', 'center', 'Position', [130 15 100 30]) ;

handles.Intervals_Selected_intervals_area_str1 = uicontrol('Parent', handles.h3_tab_Intervals, 'Style', 'text', 'String',...
    'M/Z:', 'Visible','off','FontSize',8, 'HorizontalAlignment', 'left', 'Position', [18 55 50 20]) ;

handles.Intervals_Selected_intervals_area_popupmenu = uicontrol('Parent', handles.h3_tab_Intervals, 'Style', 'popupmenu',...
    'String',[{'All'} ; {'Manual'} ; {'From workspace'}], 'Visible','off','FontSize',8,...
    'Callback',{@Intervals_Selected_intervals_area_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [55 55 110 25]) ;

handles.Intervals_Selected_intervals_area_edit = uicontrol('Parent', handles.h3_tab_Intervals, 'Style', 'edit',...
    'Visible','off','Position', [5 17 70 25]) ;

handles.Intervals_Selected_intervals_area_apply_pushbutton = uicontrol('Parent',handles.h3_tab_Intervals, 'Style', 'pushbutton', 'String','Apply', 'Visible','off',...
    'Callback',{@Intervals_Selected_intervals_area_apply_pushbutton_Callback,handles},'FontSize',9, 'HorizontalAlignment', 'center', 'Position', [80 17 40 25]) ;







handles.Intervals_Selected_intervals_area_uitable_str = uicontrol('Parent', handles.h3_tab_Intervals, 'Style', 'text', 'String',...
    'Area:','FontSize',8,'Visible','off', 'HorizontalAlignment', 'left', 'Position', [235 60 60 20]) ;

d =    {};
handles.Intervals_Selected_intervals_area_uitable = uitable('Parent',handles.h3_tab_Intervals,'Data', d,... 
            'ColumnEditable', [false false false false], 'Position', [280 5 700 80],'Visible','off');

handles.Intervals_Selected_intervals_area_uitable.BackgroundColor = [1 1 1;0.690196 0.878431 0.901961];
% handles.Intervals_Selected_intervals_uitable.ColumnWidth = {40 40 40 40};



handles.Intervals = [];
handles.Areas_Of_Selected_Intervals = [];
handles.Intervals_more_options_prepro_listbox_data = {'msbackadj'};
set(handles.Intervals_more_options_prepro_listbox,'String',handles.Intervals_more_options_prepro_listbox_data)
% handles.Intervals_more_options_prepro_listbox_data = 'None';
handles.Intervals_Selected_intervals_area_popupmenu_val = 1;
set(handles.Intervals_more_options_prepro_msbackadj_checkbox,'Value',1)






% Resolve part
% =============================================================================================================================
[handles.h1_tab_Resolve,handles.h2_tab_Resolve,handles.hDivider1_tab_Resolve] = uisplitpane(handles.tab_Resolve);
set(handles.hDivider1_tab_Resolve,'DividerColor','green')
handles.hDivider1_tab_Resolve.DividerLocation = 0.162;

[handles.h3_tab_Resolve,handles.h4_tab_Resolve,handles.hDivider2_tab_Resolve] = uisplitpane(handles.h2_tab_Resolve,'Orientation','ver');
set(handles.hDivider2_tab_Resolve,'DividerColor','green')
handles.hDivider2_tab_Resolve.DividerLocation = 0.17;


handles.Resolve_run_parafac2_pushbutton = uicontrol('Parent',handles.h1_tab_Resolve, 'Style', 'pushbutton','FontWeight','bold','FontSize',10, 'String',...
    'Run PARAFAC2','Callback',{@Resolve_run_parafac2_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [35 530 115 25]) ;



handles.Resolve_options_str = uicontrol('Parent', handles.h1_tab_Resolve, 'Style', 'text', 'String',...
    'Options : ====================','FontSize',9,'FontWeight','bold','Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 495 380 20]) ;


handles.Resolve_parafac2_options_pushbutton = uicontrol('Parent',handles.h1_tab_Resolve, 'Style', 'pushbutton', 'String',...
    'PARAFAC Options','Callback',{@Resolve_parafac2_options_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [40 470 105 25]) ;









handles.Resolve_No_of_component_for_all_str = uicontrol('Parent', handles.h1_tab_Resolve, 'Style', 'text', 'String',...
    'No of comp:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 430 60 20]) ;

handles.Resolve_No_of_component_for_all_edit = uicontrol('Parent', handles.h1_tab_Resolve, 'Style', 'edit','String',...
    '2:3','Visible','on','Position', [67 432 60 20]) ;

handles.Resolve_No_of_component_for_all_pushbutton = uicontrol('Parent',handles.h1_tab_Resolve, 'Style', 'pushbutton', 'String',...
    'Apply to all','Callback',{@Resolve_No_of_component_for_all_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [130 430 65 25]) ;








handles.Resolve_Selected_intervals_str = uicontrol('Parent', handles.h1_tab_Resolve, 'Style', 'text', 'String',...
    'Selected intervals:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 405 110 20]) ;


columnname = {'Start','End','No. of comp.'};
columnformat = {'numeric','numeric','char'};
rnames = {1 2 3};
% Define the data
d =    {0 0 '0';0 0 '0';0 0 '0'};

% Create the uitable
handles.Resolve_uitable_run_parafac2 = uitable('Parent',handles.h1_tab_Resolve,'Data', d,... 
            'ColumnName', columnname, 'ColumnFormat', columnformat, 'ColumnEditable', [false false true],...
            'RowName',rnames, 'Position', [2 255 190 150]);

handles.Resolve_uitable_run_parafac2.BackgroundColor = [1 1 1;0.690196 0.878431 0.901961];
handles.Resolve_uitable_run_parafac2.ColumnWidth = {50 50 60};
% handles.Resolve_uitable_run_parafac2.Position(3) = handles.Resolve_uitable_run_parafac2.Extent(3);
% handles.Resolve_uitable_run_parafac2.Position(4) = handles.Resolve_uitable_run_parafac2.Extent(4);       

handles.Resolve_save_results_pushbutton = uicontrol('Parent',handles.h1_tab_Resolve, 'Style', 'pushbutton', 'String',...
    'Save results','Callback',{@Resolve_save_results_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [40 220 100 25]) ;






% handles.Resolve_intervals_listbox_str = uicontrol('Parent', handles.h3_tab_Resolve, 'Style', 'text', 'String',...
%     'Intervals:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 55 70 20]) ;
% 
% handles.Resolve_intervals_listbox = uicontrol('Parent', handles.h3_tab_Resolve, 'Style', 'Listbox', 'String', ' ', ...
%     'max',100000,'HorizontalAlignment', 'left', 'Position', [55 2 170 75],'Visible','on','Callback',{@Resolve_intervals_listbox_Callback,handles}) ;


% columnname = {'1','2','3'};
handles.Resolve_intervals_uitable_str1 = uicontrol('Parent', handles.h3_tab_Resolve, 'Style', 'text', 'String',...
    'Intervals:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 30 70 20]) ;

handles.Resolve_intervals_uitable_1 = uitable('Parent',handles.h3_tab_Resolve,'Data', [],...
    'FontSize',10,'ColumnName', [],'RowName',[],'CellSelectionCallback',@Resolve_intervals_uitable_1_Callback,...
    'Position', [55 22 260 45]);



% columnname = {'1','2','3'};
handles.Resolve_factors_uitable_str2 = uicontrol('Parent', handles.h3_tab_Resolve, 'Style', 'text', 'String',...
    'Factors:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [380 30 70 20]) ;

handles.Resolve_factors_uitable_2 = uitable('Parent',handles.h3_tab_Resolve,'Data', [],...
    'FontSize',10,'ColumnName', [],'RowName',[],'CellSelectionCallback',@Resolve_factors_uitable_2_Callback,...
    'Position', [425 22 260 45]);


% CellSelectionCallback

% ButtonDownFcn






handles.Accept_this_result_as_the_best_pushbutton = uicontrol('Parent',handles.h3_tab_Resolve, 'Style', 'pushbutton', 'String',...
    'Accept','Callback',{@Accept_this_result_as_the_best_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [710 30 65 25]) ;


handles.Accept_this_result_as_the_best_str1 = uicontrol('Parent', handles.h3_tab_Resolve, 'Style', 'text', 'String',...
    'Best factor for each interval:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [800 73 170 20]) ;



columnname = {'Interval','Factor'};
columnformat = {'numeric','numeric'};
rnames = {1};
% Define the data
d = [];

% Create the uitable
handles.Accept_this_result_as_the_best_uitable = uitable('Parent',handles.h3_tab_Resolve,'Data', d,... 
            'ColumnName', columnname, 'ColumnFormat', columnformat, 'ColumnEditable', [false false],...
            'RowName',rnames, 'Position', [800 2 200 75]);


        

% handles.parafac2.options = parafac2('options');
% % handles.parafac2.options.display='off';
% handles.parafac2.options.plots='off';


handles.Resolve_wait_str = uicontrol('Parent', handles.h1_tab_Resolve, 'Style', 'text', 'String',...
    'Wait ...','FontSize',8,'Visible','off','Backgroundcolor',[1 0 0], 'HorizontalAlignment', 'center', 'Position', [55 1 50 13]) ;

% handles.Resolve_frame1 = uipanel('Parent', handles.h4_tab_Resolve, 'Position',[.000001 .0000001 .999 .999]);

handles.Resolve_frame1 = uipanel('Parent', handles.h4_tab_Resolve, 'Position',[.001 .501 .33 .499]);
handles.Resolve_frame2 = uipanel('Parent', handles.h4_tab_Resolve, 'Position',[.333 .501 .33 .499]);
handles.Resolve_frame3 = uipanel('Parent', handles.h4_tab_Resolve, 'Position',[.665 .501 .33 .499]);
handles.Resolve_frame4 = uipanel('Parent', handles.h4_tab_Resolve, 'Position',[.001 .001 .33 .499]);
handles.Resolve_frame5 = uipanel('Parent', handles.h4_tab_Resolve, 'Position',[.333 .001 .33 .499]);
handles.Resolve_frame6 = uipanel('Parent', handles.h4_tab_Resolve, 'Position',[.665 .001 .33 .499]);




% Identification part
% =============================================================================================================================






% Export part
% =============================================================================================================================













graylvl =.4;

handles.PARADAISe_coloemap=[linspace(.7,1,32)' linspace(.2,1,32)' linspace(.2,1,32)'];

% [linspace(1,graylvl,32)' linspace(1,graylvl,32)'  linspace(1,graylvl,32)']]

colormap(handles.PARADAISe_coloemap);




% -------------------------------------------------------------------
try
    figbh = findobj(allchild(0),'tag','figbrowser');
    if ishandle(figbh)
        delete(figbh);
    end
end
try
    figbh = findobj(allchild(0),'tag','figbrowsermenu');
    if ~isempty(figbh);
        delete(figbh);
    end
end
% -------------------------------------------------------------------





set( findall( gcf, '-property', 'Units' ), 'Units', 'Normalized' )


handles.f.Visible = 'on';

setappdata(0,'handles',handles)
end






% Create a Callback
% =============================================================================================================================

function tabChangedCB(hObject,eventdata,handles)
% Get the Title of the previous tab
% tabName = eventdata.OldValue.Title
handles = getappdata(0,'handles');

tabName_New = eventdata.NewValue.Title;


% If 'Loan Data' was the previous tab, update the table and plot
if strcmp(tabName_New, 'Import & View')
    % <insert code here to update the amortization table and plot>
    
    
% elseif strcmp(tabName_New, 'View')
    

elseif strcmp(tabName_New, 'Intervals')
    if ~isempty(handles.Intervals)
        set(handles.Intervals_more_options_variables_Interval_width_edit,'String',4*abs(handles.axis_min(2)-handles.axis_min(1)))
        set(handles.Intervals_more_options_variables_Space_edit,'String',4*abs(handles.axis_min(2)-handles.axis_min(1)))
    end
    
elseif strcmp(tabName_New, 'Resolve')
    if ~isempty(handles.Intervals)
        Resolve_No_of_component_for_all_val = get(handles.Resolve_No_of_component_for_all_edit,'String');

        Intervals = handles.Intervals(:,1:2);
        kk = ~isnan(Intervals(:,1));
        kk2 = Intervals(kk,:);
        kk2 = sortrows(kk2,1);
        
        temp = kk2;
        for ii = 1:size(temp,1)
            temp1(ii,:) = {kk2(ii,1) kk2(ii,2) Resolve_No_of_component_for_all_val};
        end
        Intervals = temp1;
        set(handles.Resolve_uitable_run_parafac2, 'Data', Intervals)
        
        rnames = (1:size(temp,1))';
        handles.Resolve_uitable_run_parafac2.RowName = rnames;
    else
        handles.Resolve_uitable_run_parafac2.Data = [];
    end
elseif strcmp(tabName_New, 'Identification')
    
    
elseif strcmp(tabName_New, 'Export')
    
    
    
end

setappdata(0,'handles',handles)
end



% Functions
% =============================================================================================================================
% =============================================================================================================================




% =============================================================================================================================
% Import
% =============================================================================================================================

function Import_and_view_Import_data_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
handles.filename_for_listbox = {};

[handles.filename, pathname] = uigetfile( {  '*.CDF','CDF-files (*.mat)'; '*.mat','MATLAB-files (*.mat)' ; '*.*',  'All Files (*.*)'}, ...
    'Pick a file', 'MultiSelect', 'on');
switch pathname
    case 0
        return
end
set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)
subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')

% if iscell(handles.filename)
%     for i = 1:length(handles.filename)
%         handles.filename_for_listbox(i) = {[num2str(i) ' - ' handles.filename{i}]};
%     end
% else
%     handles.filename_for_listbox = {[num2str(1) ' - ' handles.filename]};
% end

if length(handles.filename) > 2
%     try
%         handles = rmfield('handles','matrix');
%         handles = rmfield('handles','TIC');
%     end
    
    if iscell(handles.filename)
        switch handles.filename{1}(end-2:end)
                case 'mat'
                    %             load ([pathname handles.filename{i}])
                    %             eval(['handles.sample = ' handles.filename{i}(1:end-4) '.data;'])
                    %             eval(['handles.sample_label = ' handles.filename{i}(1:end-4) '.label{3};'])
                    %             eval(['handles.axis_min = ' handles.filename{i}(1:end-4) '.axisscale{1};'])
                    %             eval(['handles.axis_mz = ' handles.filename{i}(1:end-4) '.axisscale{2};'])
                    %
                    %             for i = 1:length(handles.filename)
                    %                 handles.filename_for_listbox(i) = {[num2str(i) ' - ' handles.filename{i}]};
                    %             end
                    
                    
                otherwise
                    for i = 1:length(handles.filename)
                        d = ncread([pathname handles.filename{i}],'mass_values');
                        max_d(i) = max(round(d));
                    end
                    max_d = max(max_d);
                    
                    handles.matrix = {};
                    handles.TIC = {};
                    handles.axis_min = {};
                    for i = 1:length(handles.filename)
                        [matrix,TIC,axis_min,axis_mz] = my_iCDF_load_64bit([pathname handles.filename{i}],max_d);
                        handles.matrix(i) = {matrix};
                        handles.TIC(i) = {TIC};
                        handles.axis_min(i) = {axis_min};
                        handles.filename_for_listbox(i) = {[num2str(i) ' - ' handles.filename{i}]};
                        
                    end
                    handles.axis_mz = 1:max_d;
                    
                    
                    
%                     axis_min1 = handles.axis_min;
                    
                    minw=zeros(1,size(handles.axis_min,2)); 
                    for i=1:size(handles.axis_min,2); 
                        minw(i)=handles.axis_min{i}(1,1); 
                    end
                    
                    [m11 m22]=max(minw);
                    min2=zeros(1,size(handles.axis_min,2));
                    
                    for i=1:size(handles.axis_min,2);
                        temp = abs(handles.axis_min{i}-m11);
                        temp2=find(temp ==min(temp));
                        if length(temp2) > 1
                            temp2 = temp2(1);
                        end
                        min2(i) = temp2;
                    end
                    
                    for i=1:size(handles.axis_min,2); 
                        m1{i}(:,:)=handles.matrix{i}(min2(1,i):end,:); 
                    end
                    for i=1:size(handles.axis_min,2); 
                        m2{i}=handles.TIC{i}(min2(1,i):end,:); 
                    end
                    for i=1:size(handles.axis_min,2); 
                        m3{i}=handles.axis_min{i}(min2(1,i):end,:); 
                    end
                    
                    
                    
                    
                    for i=1:size(handles.axis_min,2); 
                        minn(i)=size(m3{i},1); 
                    end;
                    
                    m1a=min(minn);
                    
                    for i=1:size(handles.axis_min,2); 
                        m1b(:,:,i)=m1{i}(1:m1a,:); 
                    end;
                    
                    for i=1:size(handles.axis_min,2); 
                        m2b(:,i)=m2{i}(1:m1a,:); 
                    end;
                    
                    for i=1:size(handles.axis_min,2); 
                        m3b{i}=m3{i}(1:m1a,:);
                    end;
                    
                    handles.matrix = m1b;
                    handles.TIC = m2b;
                    handles.axis_min = m3b{1};
                    
                    %                     matrix1=m1b;
                    %                     TIC1=m2b;
                    %                     axis_min1=m3b;
                    
        end
    else
        switch handles.filename(end-2:end)
            case 'mat'
                load ([pathname handles.filename])
                eval(['handles.matrix = ' handles.filename(1:end-4) '.data;'])
                eval(['handles.sample_label = ' handles.filename(1:end-4) '.label{3};'])
                eval(['handles.axis_min = ' handles.filename(1:end-4) '.axisscale{1};'])
                eval(['handles.axis_mz = ' handles.filename(1:end-4) '.axisscale{2};'])
                handles.axis_min = handles.axis_min';
                
                for i = 1:size(handles.sample_label,1)
                    handles.filename_for_listbox(i) = {[num2str(i) ' - ' handles.sample_label(i,:)]};
                end
                
                handles.TIC = [];
                for i = 1:size(handles.matrix,3)
                    %                         handles.matrix(i) = {squeeze(handles.sample(:,:,i))};
                    handles.TIC(:,i) = sum(squeeze(handles.matrix(:,:,i)),2);
                end
                
                
            otherwise
                
                [matrix,TIC,axis_min,axis_mz] = iCDF_load_64bit([pathname handles.filename]);
                handles.matrix = matrix;
                handles.TIC = TIC;
                handles.axis_min = axis_min;
                handles.axis_mz = axis_mz;
                handles.filename_for_listbox = {[num2str(1) ' - ' handles.filename]};
        end
        handles.filename = {handles.filename};
    end
    
    set(handles.Intervals_more_options_variables_Interval_width_edit,'String',4*abs(handles.axis_min(2)-handles.axis_min(1)))
    set(handles.Intervals_more_options_variables_Space_edit,'String',4*abs(handles.axis_min(2)-handles.axis_min(1)))
    
    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
    plot(handles.axis_min,handles.TIC(:,1))
    xlabel('RT');ylabel('Ion intensity');axis tight
    title(['TIC for sample ' handles.filename_for_listbox{1}], 'FontSize', 11,'FontWeight','Normal')
    
    set(handles.Import_and_view_Import_data_listbox,'Value',1)
    set(handles.Import_and_view_Import_data_listbox,'String',handles.filename_for_listbox)
    
    set(handles.Preprocessing_data_listbox_str,'Visible','on')
    set(handles.Preprocessing_data_listbox,'Value',1,'Visible','on')
    set(handles.Preprocessing_data_listbox,'String',handles.filename_for_listbox,'Visible','on')
    
    
    set(handles.Import_and_view_Import_data_listbox,'Visible','on')
    set(handles.Import_and_view_Import_data_listbox_str,'Visible','on')
    
    set(handles.Import_and_view_show_type_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_show_type_popupmenu,'Visible','on')
    set(handles.Import_and_view_new_plot_pushbutton,'Visible','on')
    
    
    %         set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','on')
    %         set(handles.Import_and_view_colormap_type_popupmenu,'Visible','on')
    
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','on')
    set(handles.Import_and_view_view_MS_str,'Visible','on')
    set(handles.Import_and_view_view_MS_pushbutton1,'Visible','on')
    set(handles.Import_and_view_view_MS_pushbutton2,'Visible','on')
    set(handles.Import_and_view_NIST_search_pushbutton,'Visible','on')
    set(handles.Import_and_view_dir_for_save_pushbutton,'Visible','on')
    set(handles.Import_and_view_delete_pushbutton,'Visible','on')
    
    set(handles.folder_for_search_results_str,'Visible','on')
    set(handles.Import_and_view_dir_for_save_edit,'Visible','on')
    
    % handles.Import_and_view_dir_for_save_pushbutton
    set(handles.Import_and_view_show_type_popupmenu,'Value',1);
    set(handles.Import_and_view_m_to_z_str,'Visible','off')
    set(handles.Import_and_view_m_to_z_edit,'Visible','off')
    set(handles.Import_and_view_m_to_z_pushbutton,'Visible','off')
    
end
% whos filename




% colorbar,shg

% colormap jet
handles.Import_and_view_show_MS_plot_val = 0;
set(handles.Import_and_view_wait_str,'Visible','off')
setappdata(0,'handles',handles)

end






function Import_and_view_Import_data_listbox_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)
subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')

val = get(handles.Import_and_view_Import_data_listbox,'Value');
% str = get(handles.Import_and_view_Import_data_listbox,'String');
% end_one = length(str);
set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 1 1])


contents = cellstr(get(handles.Import_and_view_show_type_popupmenu,'String'));
handles.Import_and_view_show_type_popupmenu_val = get(handles.Import_and_view_show_type_popupmenu,'Value');

Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');

Import_and_view_overlay_popupmenu_val = get(handles.Import_and_view_overlay_popupmenu,'Value');

if handles.Import_and_view_show_type_popupmenu_val == 4  % Surf
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','off')
else
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','on')
end

if handles.Import_and_view_show_type_popupmenu_val == 1  % TIC
    if length(Import_and_view_Import_data_listbox_val) == 1
        %         hh=subplot(1,1,1,'parent',handles.Import_and_view_frame1);
        %         plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val))
        %         set(hh, 'ButtonDownFcn',@clickcallback)
        subplot(1,1,1,'parent',handles.Import_and_view_frame1);
        plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val))
        
        
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for i = 1:length(Import_and_view_Import_data_listbox_val)
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,i,'parent',handles.Import_and_view_frame1)
                plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
                    hold on
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,i,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
                end
                
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
    end
    
elseif handles.Import_and_view_show_type_popupmenu_val == 2  % EIC
    
    Import_and_view_m_to_z_edit_val = str2num(get(handles.Import_and_view_m_to_z_edit,'String'));
    if isempty(Import_and_view_m_to_z_edit_val)
        set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 0 0])
        errordlg('Please fill the "m/z range" Edit box!!!')
        return
    end
    
    %     Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');
    
    if length(Import_and_view_Import_data_listbox_val) == 1
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        if length(Import_and_view_m_to_z_edit_val) == 1
            plot(handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val))
        else
            plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val))'))
        end
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for i = 1:length(Import_and_view_Import_data_listbox_val)
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,i,'parent',handles.Import_and_view_frame1)
                if length(Import_and_view_m_to_z_edit_val) == 1
                    plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))
                else
                    plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))'))
                end
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
                
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,i,'parent',handles.Import_and_view_frame1)
                end
                
                if Import_and_view_overlay_popupmenu_val == 2
                    plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))
                    legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
                    hold on
                elseif Import_and_view_overlay_popupmenu_val == 3
                    plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))'))
                    title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
                end
                xlabel('RT');ylabel('Ion intensity');axis tight
                
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
        
    end
    
    
    
    
elseif handles.Import_and_view_show_type_popupmenu_val == 3  % BPC
    if length(Import_and_view_Import_data_listbox_val) == 1
        x1 = handles.matrix(:,:,Import_and_view_Import_data_listbox_val);
        for i=1:size(x1,1);
            x2 = find(x1(i,:) == max(x1(i,:)));
            if length(x2) > 1
                x2=x2(1);
            end
            x3(i)=x2;
        end
%         x3 = unique(x3);
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        x4 = zeros(size(x1,1),1);
        for ii = 1:size(x1,1)
            x4(ii,1) = x1(ii,x3(ii));
        end
        
        plot(handles.axis_min,x4);
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['BPC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
        
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for j = 1:length(Import_and_view_Import_data_listbox_val)
            x1 = handles.matrix(:,:,Import_and_view_Import_data_listbox_val(j));
            for i=1:size(x1,1);
                x2 = find(x1(i,:) == max(x1(i,:)));
                if length(x2) > 1
                    x2=x2(1);
                end
                x3(i)=x2;
            end
            %             x3 = unique(x3);
            x4 = zeros(size(x1,1),1);
            for ii = 1:size(x1,1)
                x4(ii,1) = x1(ii,x3(ii));
            end
            
            
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,j,'parent',handles.Import_and_view_frame1)
                plot(handles.axis_min,x4);
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['BPC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}], 'FontSize', 11,'FontWeight','Normal')
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,x4);
                    title(['Sample ' num2str(Import_and_view_Import_data_listbox_val(j))], 'FontSize', 11,'FontWeight','Normal')
                    hold on
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    legend_str(j) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}};
                    
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,j,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,x4);
                    title(['Sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}], 'FontSize', 11,'FontWeight','Normal')
                    xlabel('RT');ylabel('Ion intensity');axis tight
                end
                
                
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
        
    end
    
    
    
elseif handles.Import_and_view_show_type_popupmenu_val == 4  % Surf
    if length(Import_and_view_Import_data_listbox_val) == 1
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        
        [X,Y] = meshgrid(handles.axis_mz,handles.axis_min);
        C = del2(handles.matrix(:,:,Import_and_view_Import_data_listbox_val));
        mesh(X,Y,handles.matrix(:,:,Import_and_view_Import_data_listbox_val),C,'FaceLighting','gouraud','LineWidth',0.3)
        xlabel('m/z');ylabel('RT');zlabel('Ion intensity');axis tight
        colorbar
        title(['Sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        for i = 1:length(Import_and_view_Import_data_listbox_val)
            subplot(x,y,i,'parent',handles.Import_and_view_frame1)
            
            [X,Y] = meshgrid(handles.axis_mz,handles.axis_min);
            C = del2(handles.matrix(:,:,Import_and_view_Import_data_listbox_val(i)));
            mesh(X,Y,handles.matrix(:,:,Import_and_view_Import_data_listbox_val(i)),C,'FaceLighting','gouraud','LineWidth',0.3)
            xlabel('m/z');ylabel('RT');zlabel('Ion intensity');axis tight
            colorbar
            
            title(['Sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
        end
    end
end

handles.Import_and_view_show_MS_plot_val = 0;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end




% function clickcallback(obj,evt)
% persistent chk
% if isempty(chk)
%     chk = 1;
%     pause(0.5); %Add a delay to distinguish single click from a double click
%     if chk == 1
%         %           fprintf(1,'\nI am doing a single-click.\n\n');
%         %           chk = [];
%     end
% else
%     chk = [];
%     %       fprintf(1,'\nI am doing a double-click.\n\n');
%     %     h= get(gca);
%     fig = figure;
%     new_handle = copyobj(obj,fig);
% end
% end





function Import_and_view_delete_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)


choice = questdlg('Are you sure to delete?','Delete', 'Yes','Cancel','Yes');
% Handle response
switch choice
    case 'Yes'
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        plot(0,0,'*w')
        
        val = get(handles.Import_and_view_Import_data_listbox,'Value');
        
        
        if length(handles.filename) == 1
            switch handles.filename{1}(end-2:end)
                case 'mat'
                    handles.sample_label(val,:) = [];
                    handles.filename_for_listbox = {};
                    for i = 1:size(handles.sample_label,1)
                        handles.filename_for_listbox(i) = {[num2str(i) ' - ' handles.sample_label(i,:)]};
                    end
                otherwise
                    handles.filename_for_listbox = {};
                        
            end
        else
            handles.filename(val) = [];
            handles.filename_for_listbox = {};
            for i = 1:length(handles.filename)
                handles.filename_for_listbox(i) = {[num2str(i) ' - ' handles.filename{i}]};
            end
            
        end
        
        
        
        handles.matrix(:,:,val) = [];
        handles.TIC(:,val) = [];
        
        
        
        if ~isempty(handles.matrix)
            subplot(1,1,1,'parent',handles.Import_and_view_frame1)
            plot(handles.axis_min,handles.TIC(:,1))
            xlabel('RT');ylabel('Ion intensity');axis tight
            title(['TIC for sample ' handles.filename_for_listbox{1}], 'FontSize', 11,'FontWeight','Normal')
            
            
            
            contents = cellstr(get(handles.Import_and_view_show_type_popupmenu,'String'));
            set(handles.Import_and_view_show_type_popupmenu,'Value',1);
            
            set(handles.Import_and_view_Import_data_listbox,'Value',1);
            
            set(handles.Import_and_view_overlay_popupmenu,'Value',1);
            
            set(handles.Import_and_view_Import_data_listbox,'Value',1);
            
        end
        set(handles.Import_and_view_Import_data_listbox,'String',handles.filename_for_listbox);
        set(handles.Preprocessing_data_listbox,'String',handles.filename_for_listbox)
        
end














setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end







function Import_and_view_show_type_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)
subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')


contents = cellstr(get(handles.Import_and_view_show_type_popupmenu,'String'));
handles.Import_and_view_show_type_popupmenu_val = get(handles.Import_and_view_show_type_popupmenu,'Value');
% handles.X_pre_processing_popupmenu_str = contents{get(handles.Import_and_view_show_type_popupmenu,'Value')};

Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');
Import_and_view_overlay_popupmenu_val = get(handles.Import_and_view_overlay_popupmenu,'Value');

if handles.Import_and_view_show_type_popupmenu_val == 4  % Surf
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','off')
else
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','on')
end

if handles.Import_and_view_show_type_popupmenu_val == 1  % TIC
    set(handles.Import_and_view_m_to_z_str,'Visible','off')
    set(handles.Import_and_view_m_to_z_edit,'Visible','off')
    set(handles.Import_and_view_m_to_z_pushbutton,'Visible','off')
    
    if length(Import_and_view_Import_data_listbox_val) == 1
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val))
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for i = 1:length(Import_and_view_Import_data_listbox_val)
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,i,'parent',handles.Import_and_view_frame1)
                plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
                    hold on
                    
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,i,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
                end
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
    end
    
    set(handles.Import_and_view_show_type_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_show_type_popupmenu,'Visible','on')
    
    
elseif handles.Import_and_view_show_type_popupmenu_val == 2  % EIC
    set(handles.Import_and_view_m_to_z_str,'Visible','on')
    set(handles.Import_and_view_m_to_z_edit,'Visible','on')
    set(handles.Import_and_view_m_to_z_pushbutton,'Visible','on')
    
    
elseif handles.Import_and_view_show_type_popupmenu_val == 3  % BPC
    set(handles.Import_and_view_m_to_z_str,'Visible','off')
    set(handles.Import_and_view_m_to_z_edit,'Visible','off')
    set(handles.Import_and_view_m_to_z_pushbutton,'Visible','off')
    
    if length(Import_and_view_Import_data_listbox_val) == 1
        x1 = handles.matrix(:,:,Import_and_view_Import_data_listbox_val);
        for i=1:size(x1,1);
            x2 = find(x1(i,:) == max(x1(i,:)));
            if length(x2) > 1
                x2=x2(1);
            end
            x3(i)=x2;
        end
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        x4 = zeros(size(x1,1),1);
        for ii = 1:size(x1,1)
            x4(ii,1) = x1(ii,x3(ii));
        end
        
        plot(handles.axis_min,x4);
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['BPC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for j = 1:length(Import_and_view_Import_data_listbox_val)
            x1 = handles.matrix(:,:,Import_and_view_Import_data_listbox_val(j));
            for i=1:size(x1,1);
                x2 = find(x1(i,:) == max(x1(i,:)));
                if length(x2) > 1
                    x2=x2(1);
                end
                x3(i)=x2;
            end
            x4 = zeros(size(x1,1),1);
            for ii = 1:size(x1,1)
                x4(ii,1) = x1(ii,x3(ii));
            end
            
            
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,j,'parent',handles.Import_and_view_frame1)
                plot(handles.axis_min,x4);
                title(['BPC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}], 'FontSize', 11,'FontWeight','Normal')
                xlabel('RT');ylabel('Ion intensity');axis tight
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,x4);
                    title('BPC', 'FontSize', 11,'FontWeight','Normal')
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    hold on
                    legend_str(j) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}};
                    
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,j,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,x4);
                    title('BPC', 'FontSize', 11,'FontWeight','Normal')
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    title(['BPC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}], 'FontSize', 11,'FontWeight','Normal')
                end
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
    end
    
    
    
elseif handles.Import_and_view_show_type_popupmenu_val == 4  % Surf
    set(handles.Import_and_view_m_to_z_str,'Visible','off')
    set(handles.Import_and_view_m_to_z_edit,'Visible','off')
    set(handles.Import_and_view_m_to_z_pushbutton,'Visible','off')
    if length(Import_and_view_Import_data_listbox_val) == 1
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        
        [X,Y] = meshgrid(handles.axis_mz,handles.axis_min);
        C = del2(handles.matrix(:,:,Import_and_view_Import_data_listbox_val));
        mesh(X,Y,handles.matrix(:,:,Import_and_view_Import_data_listbox_val),C,'FaceLighting','gouraud','LineWidth',0.3)
        xlabel('m/z');ylabel('RT');zlabel('Ion intensity');axis tight
        colorbar
        
        title(['Sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        for i = 1:length(Import_and_view_Import_data_listbox_val)
            
            subplot(x,y,i,'parent',handles.Import_and_view_frame1)
            
            [X,Y] = meshgrid(handles.axis_mz,handles.axis_min);
            C = del2(handles.matrix(:,:,Import_and_view_Import_data_listbox_val(i)));
            mesh(X,Y,handles.matrix(:,:,Import_and_view_Import_data_listbox_val(i)),C,'FaceLighting','gouraud','LineWidth',0.3)
            xlabel('m/z');ylabel('RT');zlabel('Ion intensity');axis tight
            colorbar
            
            title(['Sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
        end
    end
end

handles.Import_and_view_show_MS_plot_val = 0;
setappdata(0,'handles',handles)

set(handles.Import_and_view_wait_str,'Visible','off')

end








function Import_and_view_m_to_z_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)
subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')

Import_and_view_m_to_z_edit_val = str2num(get(handles.Import_and_view_m_to_z_edit,'String'));
Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');
Import_and_view_overlay_popupmenu_val = get(handles.Import_and_view_overlay_popupmenu,'Value');
set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 1 1]) 

if handles.Import_and_view_show_type_popupmenu_val == 4  % Surf
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','off')
else
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','on')
end

if isempty(Import_and_view_m_to_z_edit_val)
    set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 0 0])
    errordlg('Please fill the "m/z range" Edit box!!!')
    return
end


if length(Import_and_view_Import_data_listbox_val) == 1
    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
    if length(Import_and_view_m_to_z_edit_val) == 1
        plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val))
    else
        plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val))'))
    end
    xlabel('RT');ylabel('Ion intensity');axis tight
    title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    
else
    [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
    legend_str = {};
    for i = 1:length(Import_and_view_Import_data_listbox_val)
        if Import_and_view_overlay_popupmenu_val == 1
            subplot(x,y,i,'parent',handles.Import_and_view_frame1)
            if length(Import_and_view_m_to_z_edit_val) == 1
                plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))
            else
                plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))'))
            end
            title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
            xlabel('RT');ylabel('Ion intensity');axis tight
            
        elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
            if Import_and_view_overlay_popupmenu_val == 2
                subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                if length(Import_and_view_m_to_z_edit_val) == 1
                    plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))
                else
                    plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))'))
                end
                legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
                xlabel('RT');ylabel('Ion intensity');axis tight
                hold on
                
            elseif Import_and_view_overlay_popupmenu_val == 3
                subplot(length(Import_and_view_Import_data_listbox_val),1,i,'parent',handles.Import_and_view_frame1)
                if length(Import_and_view_m_to_z_edit_val) == 1
                    plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))
                else
                    plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))'))
                end
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
            end
        end
    end
    if Import_and_view_overlay_popupmenu_val == 2
        legend(legend_str)
    end
    hold off
end

handles.Import_and_view_show_MS_plot_val = 0;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end








function Import_and_view_new_plot_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

fig = figure;

new_handle = copyobj(handles.Import_and_view_frame1,fig);

setappdata(0,'handles',handles)
end







function Import_and_view_overlay_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)

val = get(handles.Import_and_view_Import_data_listbox,'Value');
% str = get(handles.Import_and_view_Import_data_listbox,'String');
% end_one = length(str);
set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 1 1])


contents = cellstr(get(handles.Import_and_view_show_type_popupmenu,'String'));
handles.Import_and_view_show_type_popupmenu_val = get(handles.Import_and_view_show_type_popupmenu,'Value');

Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');

Import_and_view_overlay_popupmenu_val = get(handles.Import_and_view_overlay_popupmenu,'Value');

if handles.Import_and_view_show_type_popupmenu_val == 4  % Surf
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','off')
else
    set(handles.Import_and_view_colormap_type_popupmenu_str,'Visible','off')
    set(handles.Import_and_view_colormap_type_popupmenu,'Visible','off')
    set(handles.Import_and_view_overlay_popupmenu_str,'Visible','on')
    set(handles.Import_and_view_overlay_popupmenu,'Visible','on')
end

if handles.Import_and_view_show_type_popupmenu_val ~= 4
    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
    plot(0,0,'*w')
end

if handles.Import_and_view_show_type_popupmenu_val == 1  % TIC
    if length(Import_and_view_Import_data_listbox_val) == 1
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val))
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for i = 1:length(Import_and_view_Import_data_listbox_val)
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,i,'parent',handles.Import_and_view_frame1)
                plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
                    hold on
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,i,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
                end
                
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
    end
    
elseif handles.Import_and_view_show_type_popupmenu_val == 2  % EIC
    
    Import_and_view_m_to_z_edit_val = str2num(get(handles.Import_and_view_m_to_z_edit,'String'));
    if isempty(Import_and_view_m_to_z_edit_val)
        set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 0 0])
        errordlg('Please fill the "m/z range" Edit box!!!')
        return
    end
    
    %     Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');
    
    if length(Import_and_view_Import_data_listbox_val) == 1
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        if length(Import_and_view_m_to_z_edit_val) == 1
            plot(handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val))
        else
            plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val))'))
        end
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for i = 1:length(Import_and_view_Import_data_listbox_val)
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,i,'parent',handles.Import_and_view_frame1)
                if length(Import_and_view_m_to_z_edit_val) == 1
                    plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))
                else
                    plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))'))
                end
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
                
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,i,'parent',handles.Import_and_view_frame1)
                end
                
                if Import_and_view_overlay_popupmenu_val == 2
                    plot(handles.axis_min,handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))
                    legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
                    hold on
                elseif Import_and_view_overlay_popupmenu_val == 3
                    plot(handles.axis_min,sum((handles.matrix(:,Import_and_view_m_to_z_edit_val,Import_and_view_Import_data_listbox_val(i)))'))
                    title(['EIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}], 'FontSize', 11,'FontWeight','Normal')
                end
                xlabel('RT');ylabel('Ion intensity');axis tight
                
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
        
    end
    
    
    
    
elseif handles.Import_and_view_show_type_popupmenu_val == 3  % BPC
    if length(Import_and_view_Import_data_listbox_val) == 1
        x1 = handles.matrix(:,:,Import_and_view_Import_data_listbox_val);
        for i=1:size(x1,1);
            x2 = find(x1(i,:) == max(x1(i,:)));
            if length(x2) > 1
                x2=x2(1);
            end
            x3(i)=x2;
        end
%         x3 = unique(x3);
        subplot(1,1,1,'parent',handles.Import_and_view_frame1)
        x4 = zeros(size(x1,1),1);
        for ii = 1:size(x1,1)
            x4(ii,1) = x1(ii,x3(ii));
        end
        
        plot(handles.axis_min,x4);
        xlabel('RT');ylabel('Ion intensity');axis tight
        title(['BPC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
        
    else
        [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
        legend_str = {};
        for j = 1:length(Import_and_view_Import_data_listbox_val)
            x1 = handles.matrix(:,:,Import_and_view_Import_data_listbox_val(j));
            for i=1:size(x1,1);
                x2 = find(x1(i,:) == max(x1(i,:)));
                if length(x2) > 1
                    x2=x2(1);
                end
                x3(i)=x2;
            end
            %             x3 = unique(x3);
            x4 = zeros(size(x1,1),1);
            for ii = 1:size(x1,1)
                x4(ii,1) = x1(ii,x3(ii));
            end
            
            
            if Import_and_view_overlay_popupmenu_val == 1
                subplot(x,y,j,'parent',handles.Import_and_view_frame1)
                plot(handles.axis_min,x4);
                xlabel('RT');ylabel('Ion intensity');axis tight
                title(['BPC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}], 'FontSize', 11,'FontWeight','Normal')
            elseif Import_and_view_overlay_popupmenu_val == 2 || Import_and_view_overlay_popupmenu_val == 3
                if Import_and_view_overlay_popupmenu_val == 2
                    subplot(1,1,1,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,x4);
                    title(['Sample ' num2str(Import_and_view_Import_data_listbox_val(j))], 'FontSize', 11,'FontWeight','Normal')
                    hold on
                    xlabel('RT');ylabel('Ion intensity');axis tight
                    legend_str(j) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}};
                    
                elseif Import_and_view_overlay_popupmenu_val == 3
                    subplot(length(Import_and_view_Import_data_listbox_val),1,j,'parent',handles.Import_and_view_frame1)
                    plot(handles.axis_min,x4);
                    title(['Sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(j)}], 'FontSize', 11,'FontWeight','Normal')
                    xlabel('RT');ylabel('Ion intensity');axis tight
                end
                
                
            end
        end
        if Import_and_view_overlay_popupmenu_val == 2
            legend(legend_str)
        end
        hold off
        
    end
end

handles.Import_and_view_show_MS_plot_val = 0;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end







function Import_and_view_colormap_type_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)

contents = cellstr(get(handles.Import_and_view_colormap_type_popupmenu,'String'));
Import_and_view_colormap_type_popupmenu_val = get(handles.Import_and_view_colormap_type_popupmenu,'Value');

Import_and_view_colormap_type_popupmenu_str = contents{Import_and_view_colormap_type_popupmenu_val};

if Import_and_view_colormap_type_popupmenu_val == 1
    colormap(handles.PARADAISe_coloemap);
else
    colormap(Import_and_view_colormap_type_popupmenu_str);
end

handles.Import_and_view_show_MS_plot_val = 0;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end







function Import_and_view_view_MS_pushbutton1_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')

set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)

val = get(handles.Import_and_view_Import_data_listbox,'Value');
% str = get(handles.Import_and_view_Import_data_listbox,'String');
% end_one = length(str);
set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 1 1])


contents = cellstr(get(handles.Import_and_view_show_type_popupmenu,'String'));
handles.Import_and_view_show_type_popupmenu_val = get(handles.Import_and_view_show_type_popupmenu,'Value');

Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');


subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')

if length(Import_and_view_Import_data_listbox_val) == 1
    subplot(1,2,1,'parent',handles.Import_and_view_frame1)
    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val))
    xlabel('RT');ylabel('Ion intensity');axis tight
    title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
else
    [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
    legend_str = {};
    for i = 1:length(Import_and_view_Import_data_listbox_val)
        subplot(1,2,1,'parent',handles.Import_and_view_frame1)
        plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
        xlabel('RT');ylabel('Ion intensity');axis tight
        legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
        hold on
        
    end
    legend(legend_str)
    hold off
    
end

if handles.Import_and_view_view_MS_pushbutton1_zoom == 1
    pause
end

[n1 n2] = ginput(1);

temp1 = abs(handles.axis_min - n1);
handles.mz_loc1 = find(temp1 == min(temp1));
if length(handles.mz_loc1) > 1
    handles.mz_loc1 = handles.mz_loc1(1);
end

yy = get(gca,'ylim');
line([n1 n1],[yy(1) yy(2)],'color',[1 0 0],'linewidth',2);


for i = 1:length(Import_and_view_Import_data_listbox_val)
    subplot(length(Import_and_view_Import_data_listbox_val),2,2*i,'parent',handles.Import_and_view_frame1)
    bar(handles.axis_mz,handles.matrix(handles.mz_loc1,:,Import_and_view_Import_data_listbox_val(i)))
    xlabel('m/z');ylabel('Ion intensity');axis tight
    title(['sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)} ' - m/z for RT ' num2str(handles.axis_min(handles.mz_loc1))], 'FontSize', 11,'FontWeight','Normal')
end

handles.Import_and_view_show_MS_plot_val = 1;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end




function MZ_Zoom(source,callbackdata)
handles = getappdata(0,'handles');

switch source.Label
    case 'With zoom'
        if strcmp(get(gcbo,'Checked'),'on')
%             set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu1, 'Checked', 'off');
%             set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2, 'Checked', 'on');
        else
            set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu1, 'Checked', 'on');
            set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2, 'Checked', 'off');
        end
        handles.Import_and_view_view_MS_pushbutton1_zoom = 1;
        
    case 'Without zoom'
        
        if strcmp(get(gcbo,'Checked'),'on')
%             set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2, 'Checked', 'off');
%             set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu1, 'Checked', 'on');
        else
            set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu2, 'Checked', 'on');
            set(handles.Import_and_view_view_MS_pushbutton1_UIContextMenu1, 'Checked', 'off');
        end
        handles.Import_and_view_view_MS_pushbutton1_zoom = 2;
        
end
setappdata(0,'handles',handles)
end





function Import_and_view_view_MS_pushbutton2_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')

set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)

val = get(handles.Import_and_view_Import_data_listbox,'Value');
% str = get(handles.Import_and_view_Import_data_listbox,'String');
% end_one = length(str);
set(handles.Import_and_view_m_to_z_edit,'Backgroundcolor',[1 1 1])


contents = cellstr(get(handles.Import_and_view_show_type_popupmenu,'String'));
handles.Import_and_view_show_type_popupmenu_val = get(handles.Import_and_view_show_type_popupmenu,'Value');

Import_and_view_Import_data_listbox_val = get(handles.Import_and_view_Import_data_listbox,'Value');


subplot(1,1,1,'parent',handles.Import_and_view_frame1)
plot(0,0,'*w')

if length(Import_and_view_Import_data_listbox_val) == 1
    subplot(1,2,1,'parent',handles.Import_and_view_frame1)
    plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val))
    xlabel('RT');ylabel('Ion intensity');axis tight
    title(['TIC for sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val}], 'FontSize', 11,'FontWeight','Normal')
else
    [x , y] = subplot_x_y_size(length(Import_and_view_Import_data_listbox_val));
    legend_str = {};
    for i = 1:length(Import_and_view_Import_data_listbox_val)
        subplot(1,2,1,'parent',handles.Import_and_view_frame1)
        plot(handles.axis_min,handles.TIC(:,Import_and_view_Import_data_listbox_val(i)))
        xlabel('RT');ylabel('Ion intensity');axis tight
        legend_str(i) = {handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)}};
        hold on
        
    end
    legend(legend_str)
    hold off
    
end

yy = get(gca,'ylim');

if handles.Import_and_view_view_MS_pushbutton2_zoom == 1
    pause
end

[m1 m2] = ginput(1);
line([m1 m1],[yy(1) yy(2)],'color',[1 0 0],'linewidth',2);

[m3 m4] = ginput(1);
line([m3 m3],[yy(1) yy(2)],'color',[1 0 0],'linewidth',2);

n1= [m1 m3];



temp1 = abs(handles.axis_min - n1(1));
handles.mz_loc1 = find(temp1 == min(temp1));
if length(handles.mz_loc1) > 1
    handles.mz_loc1 = handles.mz_loc1(1);
end

temp3 = abs(handles.axis_min - n1(2));
handles.mz_loc2 = find(temp3 == min(temp3));
if length(handles.mz_loc2) > 1
    handles.mz_loc2 = handles.mz_loc2(1);
end



for i = 1:length(Import_and_view_Import_data_listbox_val)
    subplot(length(Import_and_view_Import_data_listbox_val),2,2*i,'parent',handles.Import_and_view_frame1)
    mean1 = mean(handles.matrix(handles.mz_loc1:handles.mz_loc2,:,Import_and_view_Import_data_listbox_val(i)));
    bar(handles.axis_mz,mean1)
    xlabel('m/z');ylabel('Ion intensity');axis tight
    title(['sample ' handles.filename_for_listbox{Import_and_view_Import_data_listbox_val(i)} ' - m/z for mean(' num2str(handles.axis_min(handles.mz_loc1)) ':' num2str(handles.axis_min(handles.mz_loc2)) ')'], 'FontSize', 11,'FontWeight','Normal')
end

handles.Import_and_view_show_MS_plot_val = 1;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end





function MZ_Zoom2(source,callbackdata)
handles = getappdata(0,'handles');

switch source.Label
    case 'With zoom'
        if strcmp(get(gcbo,'Checked'),'on')
        else
            set(handles.Import_and_view_view_MS_pushbutton2_UIContextMenu1, 'Checked', 'on');
            set(handles.Import_and_view_view_MS_pushbutton2_UIContextMenu2, 'Checked', 'off');
        end
        handles.Import_and_view_view_MS_pushbutton2_zoom = 1;
        
    case 'Without zoom'
        
        if strcmp(get(gcbo,'Checked'),'on')
        else
            set(handles.Import_and_view_view_MS_pushbutton2_UIContextMenu2, 'Checked', 'on');
            set(handles.Import_and_view_view_MS_pushbutton2_UIContextMenu1, 'Checked', 'off');
        end
        handles.Import_and_view_view_MS_pushbutton2_zoom = 2;
        
end
setappdata(0,'handles',handles)
end















function Import_and_view_NIST_search_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)

handles.Import_and_view_dir_for_save_str = get(handles.Import_and_view_dir_for_save_edit,'String');

NIST_dir = get(handles.Import_and_view_dir_for_save_edit,'String');
% NISTwd = NISTwdCheck(NIST_dir,1);
NISTwd = massLookUp(handles.matrix(handles.mz_loc1,:,1), handles.axis_mz, num2str(handles.axis_min(handles.mz_loc1)), handles.Import_and_view_dir_for_save_str, 'C:\NIST11\MSSEARCH', cd);



handles.Import_and_view_show_MS_plot_val = 0;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end












function Import_and_view_dir_for_save_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

set(handles.Import_and_view_wait_str,'Visible','on')
pause(0.0000000000000001)

try
    dname = uigetdir(handles.Import_and_view_dir_for_save_str);
catch
    dname = uigetdir(cd);
end

switch dname
    case 0
    otherwise
        handles.Import_and_view_dir_for_save_str = dname;
        Import_and_view_dir_for_save_str = dname;
        set(handles.Import_and_view_dir_for_save_edit,'String',handles.Import_and_view_dir_for_save_str)
        save Import_and_view_dir_for_save_str Import_and_view_dir_for_save_str
end
        
        



% handles.Import_and_view_show_MS_plot_val = 0;
setappdata(0,'handles',handles)
set(handles.Import_and_view_wait_str,'Visible','off')

end









% =============================================================================================================================
% Preprocessing
% =============================================================================================================================


function Preprocessing_data_listbox_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)

        



setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end










function Preprocessing_target_vector_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)

        



setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end











function Preprocessing_target_samples_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)

        



setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end









function Preprocessing_alignment_mode_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)

Preprocessing_alignment_mode_popupmenu_val = get(handles.Preprocessing_alignment_mode_popupmenu,'Value');
switch Preprocessing_alignment_mode_popupmenu_val
    case 1
        set(handles.Preprocessing_Intervals_alignment_mode_str,'Visible','off')
        set(handles.Preprocessing_Intervals_alignment_mode_edit,'Visible','off')
    case 2
        set(handles.Preprocessing_Intervals_alignment_mode_str,'Visible','on')
        set(handles.Preprocessing_Intervals_alignment_mode_edit,'Visible','on')
    case 3
        set(handles.Preprocessing_Intervals_alignment_mode_str,'Visible','on')
        set(handles.Preprocessing_Intervals_alignment_mode_edit,'Visible','on')
    case 4
        set(handles.Preprocessing_Intervals_alignment_mode_str,'Visible','on')
        set(handles.Preprocessing_Intervals_alignment_mode_edit,'Visible','on')
    case 5
        set(handles.Preprocessing_Intervals_alignment_mode_str,'Visible','on')
        set(handles.Preprocessing_Intervals_alignment_mode_edit,'Visible','on')
    case 6
        set(handles.Preprocessing_Intervals_alignment_mode_str,'Visible','on')
        set(handles.Preprocessing_Intervals_alignment_mode_edit,'Visible','on')
end



setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end




% handles.Preprocessing_alignment_mode_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
%     'String',[{'whole'} ; {'nint'} ; {'ndata'} ; {'Int. def.'} ; {'refs:refe'} ; {'refs-refe'}],...
%     'Visible','on','FontSize',8,'Callback',{@Preprocessing_alignment_mode_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [90 450 75 25]) ;
% 







function Preprocessing_Channels_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)

Preprocessing_Channels_popupmenu_val = get(handles.Preprocessing_Channels_popupmenu,'Value');
switch Preprocessing_Channels_popupmenu_val
    case 1
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Channels_edit,'Visible','off')
    case 2
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Channels_edit,'Visible','off')
    case 3
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Channels_edit,'Visible','off')
    case 4
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Channels_edit,'Visible','off')
    case 5
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Channels_edit,'Visible','off')
    case 6
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Channels_edit,'Visible','off')
    case 7
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Channels_edit,'Visible','off')
    case 8
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','on')
        set(handles.Preprocessing_Channels_edit,'Visible','on')
    case 9
        set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','on')
        set(handles.Preprocessing_Channels_edit,'Visible','on')
        
end



setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end













function Preprocessing_Shift_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)

Preprocessing_Shift_popupmenu_val = get(handles.Preprocessing_Shift_popupmenu,'Value');
switch Preprocessing_Shift_popupmenu_val
    case 1
        set(handles.Preprocessing_Shift_popupmenu_str2,'Visible','on')
        set(handles.Preprocessing_Shift_edit,'Visible','on')
    case 2
        set(handles.Preprocessing_Shift_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Shift_edit,'Visible','off')
    case 3
        set(handles.Preprocessing_Shift_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_Shift_edit,'Visible','off')
end



setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end


% handles.Preprocessing_Shift_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Shift:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 345 90 20]) ;
% 
% handles.Preprocessing_Shift_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
%     'String',[{'Maximum shift'} ; {'Best'} ; {'Fast'}],...
%     'Visible','on','FontSize',8,'Callback',{@Preprocessing_Shift_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [40 348 95 20]) ;
% 
% handles.Preprocessing_Shift_popupmenu_str2 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Input:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 324 70 20]) ;
% 
% handles.Preprocessing_Shift_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit','Visible','on','Position', [60 325 50 20]) ;
% 
% 







































% options (1 � 5): (optional)
%                  (1) triggers plots & warnings:
%                      0 : no on-screen output
%                      1 : only warnings (default)
%                      2 : warnings and plots
%                  (2) selects filling mode
%                      0 : using not a number
%                      1 : using previous point (default)
%                  (3) turns on Co-shift preprocessing
%                      0 : no Co-shift preprocessing (default)
%                      1 : Executes a Co-shift step before carrying out iCOshift
%                  (4) max allowed shift for the Co-shift preprocessing (default = equal to n if not specified)
%                      it has to be given in Scal units if option(5)=1
%                  (5) 0 : intervals are given in No. of datapoints  (deafult)
%                      1 : intervals are given in ppm --> use Scal for inter and n









function Preprocessing_options_first_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)

Preprocessing_options_first_popupmenu_val = get(handles.Preprocessing_options_first_popupmenu,'Value');
switch Preprocessing_options_first_popupmenu_val
    case 1
        %         set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        %         set(handles.Preprocessing_Channels_edit,'Visible','off')
        
        
        set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','on')
        set(handles.Preprocessing_options_second_popupmenu,'Visible','on')
        
        
        set(handles.Preprocessing_Channels_options_edit_str,'Visible','off')
        set(handles.Preprocessing_Channels_options_edit,'Visible','off')
        set(handles.Preprocessing_options_second_popupmenu,'String',[{'Only warnings'} ; {'No on-screen output'} ; {'Warnings and plots'}]);
        
    case 2
        set(handles.Preprocessing_options_second_popupmenu,'String',[{'Using previous point'} ;{'Using not a number'}]);
        %         set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','on')
        %         set(handles.Preprocessing_options_second_popupmenu,'Visible','on')
        
        set(handles.Preprocessing_Channels_options_edit_str,'Visible','off')
        set(handles.Preprocessing_Channels_options_edit,'Visible','off')
        
        if handles.Preprocessing_Options.fill == 1
            set(handles.Preprocessing_options_second_popupmenu,'Value',1)
        elseif handles.Preprocessing_Options.fill == 0
            set(handles.Preprocessing_options_second_popupmenu,'Value',2)
        end
        
        set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','on')
        set(handles.Preprocessing_options_second_popupmenu,'Visible','on')
        
        
        
    case 3
        set(handles.Preprocessing_options_second_popupmenu,'String',[{'No Co-shift preprocessing'} ;{'Executes a Co-shift step before carrying out iCOshift'}]);
        %         set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','on')
        %         set(handles.Preprocessing_options_second_popupmenu,'Visible','on')
        
        set(handles.Preprocessing_Channels_options_edit_str,'Visible','off')
        set(handles.Preprocessing_Channels_options_edit,'Visible','off')
        
        if handles.Preprocessing_Options.preCOShift == 0
            set(handles.Preprocessing_options_second_popupmenu,'Value',1)
        elseif handles.Preprocessing_Options.preCOShift == 1
            set(handles.Preprocessing_options_second_popupmenu,'Value',2)
        end
        
        set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','on')
        set(handles.Preprocessing_options_second_popupmenu,'Visible','on')
        
    case 4
        set(handles.Preprocessing_options_second_popupmenu,'String',[{'No Co-shift preprocessing'} ;{'Executes a Co-shift step before carrying out iCOshift'}]);
        set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_options_second_popupmenu,'Visible','off')
        
        %         if handles.Preprocessing_Options.useScal == 0
        %
        %         elseif handles.Preprocessing_Options.useScal == 1
        %
        %         end
        
        set(handles.Preprocessing_Channels_options_edit_str,'Visible','on')
        set(handles.Preprocessing_Channels_options_edit,'Visible','on')
        if handles.Preprocessing_Options.useScal == 0
            set(handles.Preprocessing_Channels_options_edit_str,'String','Data point:')
        elseif handles.Preprocessing_Options.useScal == 1
            set(handles.Preprocessing_Channels_options_edit_str,'String','RT range:')
        end
        
    case 5
        set(handles.Preprocessing_options_second_popupmenu,'String',[{'Intervals are given in No. of datapoints'} ;{'Intervals are given in ppm'}]);
        
        if handles.Preprocessing_Options.useScal == 0
            set(handles.Preprocessing_options_second_popupmenu,'Value',1)
        elseif handles.Preprocessing_Options.useScal == 1
            set(handles.Preprocessing_options_second_popupmenu,'Value',2)
        end
        
        set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','on')
        set(handles.Preprocessing_options_second_popupmenu,'Visible','on')
        
        set(handles.Preprocessing_Channels_options_edit_str,'Visible','off')
        set(handles.Preprocessing_Channels_options_edit,'Visible','off')
        
        
    case 6
        set(handles.Preprocessing_options_second_popupmenu,'String',[{'corrThresh'}]);
        set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','off')
        set(handles.Preprocessing_options_second_popupmenu,'Visible','off')
        
        set(handles.Preprocessing_Channels_options_edit_str,'Visible','on')
        set(handles.Preprocessing_Channels_options_edit,'Visible','on')
        
        
        set(handles.Preprocessing_Channels_options_edit_str,'String','Threshold:')
        
end




% handles.Preprocessing_options_first_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Options:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 304 170 20]) ;
% 
% handles.Preprocessing_options_first_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
%     'String',[{'Triggers plots'} ; {'Filling mode'} ; {'Co-shift preprocessing'} ; {'Max allowed shift'} ; {'intervals'} ; {'corrThresh'}],...
%     'Visible','on','FontSize',8,'Callback',{@Preprocessing_options_first_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [60 304 95 25]) ;
% 
% 
% handles.Preprocessing_options_second_popupmenu_str2 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Inputs:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 278 60 20]) ;
% 
% handles.Preprocessing_options_second_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
%     'String',[{'Only warnings'} ; {'No on-screen output'} ; {'warnings and plots'}],...
%     'Visible','on','FontSize',8,'Callback',{@Preprocessing_options_second_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [60 278 95 25]) ;
% 
% 
% handles.Preprocessing_Channels_options_edit_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'm/z range:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 255 70 20]) ;
% 
% handles.Preprocessing_Channels_options_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit','Visible','on','Position', [60 257 50 20]) ;
% 










setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end




% handles.Preprocessing_options_first_popupmenu_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Options:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 310 60 20]) ;
% 
% handles.Preprocessing_options_first_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
%     'String',[{'Triggers plots'} ; {'Filling mode'} ; {'Co-shift preprocessing'} ; {'Max allowed shift'} ; {'intervals'}],...
%     'Visible','on','FontSize',8,'Callback',{@Preprocessing_options_first_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [60 310 95 25]) ;
% 
% 
% 
% handles.Preprocessing_options_second_popupmenu_str2 = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Options:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 280 60 20]) ;
% 
% handles.Preprocessing_options_second_popupmenu = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'popupmenu',...
%     'String',[{'Only warnings'} ; {'No on-screen output'}],...
%     'Visible','on','FontSize',8,'Callback',{@Preprocessing_options_second_popupmenu_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [60 280 95 25]) ;
% 







% handles.Preprocessing_options_listbox_str = [{'Triggers plots ==> only warnings'} ; {'Filling mode ==> using previous point'} ; {'Co-shift preprocessing ==> no Co-shift preprocessing'};...
%     {'Max allowed shift ==> 0'} ; {'Intervals ==> Intervals are given in No. of datapoints'} ; {'corrThresh ==> 0'}];






function Preprocessing_options_second_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');


Preprocessing_options_first_popupmenu_val = get(handles.Preprocessing_options_first_popupmenu,'Value');
Preprocessing_options_second_popupmenu_val = get(handles.Preprocessing_options_second_popupmenu,'Value');
switch Preprocessing_options_first_popupmenu_val
    case 1
        %         set(handles.Preprocessing_Channels_popupmenu_str2,'Visible','off')
        %         set(handles.Preprocessing_Channels_edit,'Visible','off')
        
        if Preprocessing_options_second_popupmenu_val == 1
            handles.Preprocessing_options_listbox_str(1,:) = [{'Triggers plots ==> Only warnings'}];
            handles.Preprocessing_Options.show = 1;
        elseif Preprocessing_options_second_popupmenu_val == 2
            handles.Preprocessing_options_listbox_str(1,:) = [{'Triggers plots ==> No on-screen output'}];
            handles.Preprocessing_Options.show = 0;
        elseif Preprocessing_options_second_popupmenu_val == 3
            handles.Preprocessing_options_listbox_str(1,:) = [{'Triggers plots ==> Warnings and plots'}];
            handles.Preprocessing_Options.show = 2;
        end
        
    case 2
        if Preprocessing_options_second_popupmenu_val == 1
            handles.Preprocessing_options_listbox_str(2,:) = [{'Filling mode ==> Using previous point'}];
            handles.Preprocessing_Options.fill = 1;
        elseif Preprocessing_options_second_popupmenu_val == 2
            handles.Preprocessing_options_listbox_str(2,:) = [{'Filling mode ==> Using not a number'}];
            handles.Preprocessing_Options.fill = 0;
        end

    case 3
        if Preprocessing_options_second_popupmenu_val == 1
            handles.Preprocessing_options_listbox_str(3,:) = [{'Co-shift preprocessing ==> No Co-shift preprocessing'}];
            handles.Preprocessing_Options.preCOShift = 0;
        elseif Preprocessing_options_second_popupmenu_val == 2
            handles.Preprocessing_options_listbox_str(3,:) = [{'Co-shift preprocessing ==> Executes a Co-shift step before carrying out iCOshift'}];
            handles.Preprocessing_Options.preCOShift = 1;
        end
        
    case 4
        %         handles.Preprocessing_options_listbox = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'Listbox', 'String', ' ', ...
        %     'max',1,'HorizontalAlignment', 'left', 'Position', [5 163 170 70],'Visible','on') ;
        
        %         handles.Preprocessing_Options.maxPreCOShift = 0;
        
        
        % handles.Preprocessing_Channels_options_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit','Visible','on','Position', [70 237 70 20]) ;
        
        
        %
        %         handles.Preprocessing_Channels_options_edit_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
        %             'Input range:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 235 70 20]) ;
        %
        %         handles.Preprocessing_Channels_options_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit','Visible','on','Position', [70 237 70 20]) ;
        
        
        
        
        %         set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','off')
        %         set(handles.Preprocessing_options_second_popupmenu,'Visible','off')
        
%         if handles.Preprocessing_Options.useScal == 0
%             set(handles.Preprocessing_Channels_options_edit_str,'String','Data point')
%         elseif handles.Preprocessing_Options.useScal == 1
%             set(handles.Preprocessing_Channels_options_edit_str,'String','RT range')
%         end
%         
%         set(handles.Preprocessing_Channels_options_edit_str,'Visible','on')
%         set(handles.Preprocessing_Channels_options_edit,'Visible','on')
        
    case 5
        
        if Preprocessing_options_second_popupmenu_val == 1
            handles.Preprocessing_options_listbox_str(5,:) = [{'Intervals ==> Intervals are given in No. of datapoints'}];
            handles.Preprocessing_Options.useScal = 0;
        elseif Preprocessing_options_second_popupmenu_val == 2
            handles.Preprocessing_options_listbox_str(5,:) = [{'Intervals ==> Intervals are given in ppm'}];
            handles.Preprocessing_Options.useScal = 1;
        end
        
    case 6
        
%         set(handles.Preprocessing_options_second_popupmenu,'String',[{'corrThresh'}]);
%         set(handles.Preprocessing_options_second_popupmenu_str2,'Visible','off')
%         set(handles.Preprocessing_options_second_popupmenu,'Visible','off')
%         
%         set(handles.Preprocessing_Channels_options_edit_str,'Visible','on')
%         set(handles.Preprocessing_Channels_options_edit,'Visible','on')
        
        
end

set(handles.Preprocessing_options_listbox,'String',handles.Preprocessing_options_listbox_str)



setappdata(0,'handles',handles)

end








% 
% handles.Preprocessing_Channels_options_edit_str = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'text', 'String',...
%     'Input range:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [5 235 70 20]) ;
% 
% handles.Preprocessing_Channels_options_edit = uicontrol('Parent', handles.h1_tab_Preprocessing, 'Style', 'edit',...
%     'Callback',{@Preprocessing_Channels_options_edit_Callback,handles},'Visible','on','Position', [70 237 70 20]) ;
% 

function Preprocessing_Channels_options_edit_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Import_and_view_frame1)
% plot(0,0,'*w')

% set(handles.Import_and_view_wait_str,'Visible','on')
% pause(0.0000000000000001)
Preprocessing_Channels_options_edit_val = str2num(get(handles.Preprocessing_Channels_options_edit,'String'));
Preprocessing_options_first_popupmenu_val = get(handles.Preprocessing_options_first_popupmenu,'Value');
switch Preprocessing_options_first_popupmenu_val
    case 4
        handles.Preprocessing_Options.maxPreCOShift = Preprocessing_Channels_options_edit_val;
        handles.Preprocessing_options_listbox_str(4,:) = [{['Max allowed shift ==> ' num2str(Preprocessing_Channels_options_edit_val)]}];
    case 6
        handles.Preprocessing_Options.corrThresh = Preprocessing_Channels_options_edit_val;
        handles.Preprocessing_options_listbox_str(6,:) = [{['CorrThresh ==> ' num2str(Preprocessing_Channels_options_edit_val)]}];
        
end

set(handles.Preprocessing_options_listbox,'String',handles.Preprocessing_options_listbox_str)

setappdata(0,'handles',handles)
% set(handles.Import_and_view_wait_str,'Visible','off')

end


















function Preprocessing_run_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
subplot(1,1,1,'parent',handles.Preprocessing_frame1)
plot(0,0,'*w')
axis off

set(handles.Preprocessing_wait_str,'Visible','on')
pause(0.0000000000000001)


Preprocessing_data_listbox_val = get(handles.Preprocessing_data_listbox,'Value');

Preprocessing_target_samples_popupmenu_val = get(handles.Preprocessing_target_samples_popupmenu,'Value');
Preprocessing_target_vector_popupmenu_content = get(handles.Preprocessing_target_vector_popupmenu,'String');
Preprocessing_target_vector_popupmenu_val = get(handles.Preprocessing_target_vector_popupmenu,'Value');
Preprocessing_target_vector_popupmenu_str = Preprocessing_target_vector_popupmenu_content(Preprocessing_target_vector_popupmenu_val,:)

permute_data = permute(handles.matrix,[3 1 2]);
if Preprocessing_target_samples_popupmenu_val == 1
    xT = Preprocessing_target_vector_popupmenu_str{1};
    
elseif Preprocessing_target_samples_popupmenu_val == 2
    if Preprocessing_target_vector_popupmenu_val == 1
        xT = mean(permute_data(Preprocessing_data_listbox_val,:,:),1);
    elseif Preprocessing_target_vector_popupmenu_val == 2
        xT = median(permute_data(Preprocessing_data_listbox_val,:,:),1);
    elseif Preprocessing_target_vector_popupmenu_val == 2
        xT = max(permute_data(Preprocessing_data_listbox_val,:,:),1);
    end
end


Preprocessing_Intervals_alignment_mode_edit_val = get(handles.Preprocessing_Intervals_alignment_mode_edit,'String');
Preprocessing_alignment_mode_popupmenu_val = get(handles.Preprocessing_alignment_mode_popupmenu,'Value');
switch Preprocessing_alignment_mode_popupmenu_val
    case 1
        inter = 'whole';
    case 2
        inter = str2num(Preprocessing_Intervals_alignment_mode_edit_val);
    case 3
        inter = Preprocessing_Intervals_alignment_mode_edit_val;
    case 4
        inter = str2num(Preprocessing_Intervals_alignment_mode_edit_val);
    case 5
        inter = str2num(Preprocessing_Intervals_alignment_mode_edit_val);
    case 6
        inter = Preprocessing_Intervals_alignment_mode_edit_val;
end


Preprocessing_Shift_popupmenu_val = get(handles.Preprocessing_Shift_popupmenu,'Value');
switch Preprocessing_Shift_popupmenu_val
    case 1
        n = str2num(get(handles.Preprocessing_Shift_edit,'String'));
        if isempty(n)
            errordlg('Please fill the shift edit box')
            return
        end
    case 2
        n = 'b';
    case 3
        n = 'f';
end


Preprocessing_Channels_edit_val = get(handles.Preprocessing_Channels_edit,'String');
Preprocessing_Channels_popupmenu_val = get(handles.Preprocessing_Channels_popupmenu,'Value');
switch Preprocessing_Channels_popupmenu_val
    case 1
        useChannels = 'corrProd';
    case 2
        useChannels = 'corrSum';
    case 3
        useChannels = 'corrMax';
    case 4
        useChannels = 'corrTrimSum';
    case 5
        useChannels = 'corrTrimProd';
    case 6
        useChannels = 'sum';
    case 7
        useChannels = 'max';
    case 8
        useChannels = str2num(Preprocessing_Channels_edit_val);
    case 9
        useChannels = {Preprocessing_Channels_edit_val};
end


[handles.xCS,handles.ints,handles.ind,handles.target] = my_icoshiftMC(xT,permute_data,inter,n,useChannels,handles.Preprocessing_Options,handles.axis_min,handles.axis_mz,handles);

a1 = (handles.axis_min(end) - handles.axis_min(1));
for i=1:length(handles.ind); 
    ind2(i,:)=(handles.ind(i,:)*a1)/length(handles.target);
end
subplot(1,1,1,'parent',handles.Preprocessing_frame2)
barh(ind2,0.0001);axis tight; xlabel('Shift (min)'); ylabel('Samples');title('Shift after alignment','FontSize',9);




% assignin('base','xCS',handles.xCS)
% assignin('base','ints',handles.ints)
% assignin('base','ind',handles.ind)
% assignin('base','target',handles.target)
% assignin('base','permute_data',permute_data)
% assignin('base','Preprocessing_Options',Preprocessing_Options)



setappdata(0,'handles',handles)
set(handles.Preprocessing_wait_str,'Visible','off')

end







function Preprocessing_accept_checkbox_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)


handles.preprocessing_accept_checkbox_val = get(handles.Preprocessing_accept_checkbox,'Value');
% 
if handles.preprocessing_accept_checkbox_val == 1
    %[handles.xCS,handles.ints,handles.ind,handles.target]
    %= my_icoshiftMC(xT,permute_data,inter,n,useChannels,handles.Preprocessing_Options,handles.axis_min,handles.axis_mz,handles);

elseif handles.preprocessing_accept_checkbox_val == 0
    
end
% [handles.xCS,handles.ints,handles.ind,handles.target] = my_icoshiftMC(xT,permute_data,inter,n,useChannels,handles.Preprocessing_Options,handles.axis_min,handles.axis_mz,handles);
% handles.matrix


setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end















% =============================================================================================================================
% View
% =============================================================================================================================






% =============================================================================================================================
% Intervals
% =============================================================================================================================

function Intervals_continue_until_next_minimum_checkbox_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Intervals_wait_str,'Visible','on')
pause(0.0000000000000001)

handles.Intervals_until_next_minimum_checkbox_val = get(handles.Intervals_continue_until_next_minimum_checkbox,'Value');

setappdata(0,'handles',handles)
set(handles.Intervals_wait_str,'Visible','off')

end






function Intervals_run_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Intervals_wait_str,'Visible','on')
pause(0.0000000000000001)

handles.preprocessing_accept_checkbox_val = get(handles.Preprocessing_accept_checkbox,'Value');

std_value = str2double(get(handles.Intervals_more_options_variables_std_edit,'String'));
peak_width = str2double(get(handles.Intervals_more_options_variables_Interval_width_edit,'String'));
space_between_two_intervals = str2double(get(handles.Intervals_more_options_variables_Space_edit,'String'));


try
    for ii = 1:size(handles.Intervals,1)
        try
            delete(handles.him.(['h' num2str(ii) '1']));
            delete(handles.him.(['h' num2str(ii) '2']));
        end
        
    end
end

if handles.preprocessing_accept_checkbox_val == 0
    
    if handles.Intervals_until_next_minimum_checkbox_val == 0
        [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(permute(handles.matrix , [3 1 2]),handles.axis_min,std_value,peak_width,space_between_two_intervals,0,handles.Intervals_more_options_prepro_listbox_data,handles);
    else
        [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(permute(handles.matrix , [3 1 2]),handles.axis_min,std_value,peak_width,space_between_two_intervals,1,handles.Intervals_more_options_prepro_listbox_data,handles);
    end
    
elseif handles.preprocessing_accept_checkbox_val == 1
    if handles.Intervals_until_next_minimum_checkbox_val == 0
        [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(handles.xCS,handles.axis_min,std_value,peak_width,space_between_two_intervals,0,handles.Intervals_more_options_prepro_listbox_data,handles);
    else
        [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(handles.xCS,handles.axis_min,std_value,peak_width,space_between_two_intervals,1,handles.Intervals_more_options_prepro_listbox_data,handles);
    end
    temp = permute(handles.matrix , [3 1 2]);
%     assignin('base','samples11',temp)
%     assignin('base','xCS',handles.xCS)

%     if handles.Intervals_until_next_minimum_checkbox_val == 0
%         [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(permute(handles.xCS , [3 1 2]),handles.axis_min,std_value,peak_width,space_between_two_intervals,0,handles);
%     else
%         [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(permute(handles.xCS , [3 1 2]),handles.axis_min,std_value,peak_width,space_between_two_intervals,1,handles);
%     end
end

if isempty(handles.Intervals)
    set(handles.Intervals_No_of_detected_intervals_str2, 'String', num2str(0))
    
    set(handles.Intervals_wait_str,'Visible','off')
    
%     set(handles.Intervals_calculate_area_pushbutton,'Visible','on')
%     set(handles.Intervals_Selected_intervals_area_str1,'Visible','on')
%     set(handles.Intervals_Selected_intervals_area_popupmenu,'Visible','on')
%     set(handles.Intervals_Selected_intervals_area_popupmenu,'Value',1)
    set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
    set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','off')
    
    set(handles.Intervals_Selected_intervals_area_uitable_str,'Visible','off')
    set(handles.Intervals_Selected_intervals_area_uitable,'Visible','off')
    set(handles.Intervals_save_to_excel_pushbutton,'Visible','off')
    handles.Areas_Of_Selected_Intervals = [];
    setappdata(0,'handles',handles)
    return
    
else
    set(handles.Intervals_No_of_detected_intervals_str2, 'String', num2str(size(handles.Intervals,1)))
end


str_for_Intervals_Selected_intervals_uitable = cell(size(handles.Intervals,1),3);
for i = 1:size(handles.Intervals,1)
    str_for_Intervals_Selected_intervals_uitable(i,:) = [{handles.Intervals(i,1)} {handles.Intervals(i,2)} {'All'}];
end
set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)
rnames = (1:size(handles.Intervals,1))';
handles.Intervals_Selected_intervals_uitable.RowName = rnames;
set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
set(handles.Intervals_Selected_intervals_area_popupmenu,'Value',1)

set(handles.hh, 'ButtonDownFcn', {@LineSelected, handles.hh})

subplot(1,1,1,'parent',handles.Intervals_frame1)
hold on
yy = get(gca,'ylim');
y1 = yy(1);
y2 = yy(2);
ColorSet = varycolor(size(handles.Intervals,1));


for i=1:size(handles.Intervals,1)
    
    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([handles.Intervals(i,1) handles.Intervals(i,2)])
        msg='';
        filled=[[y1 y1],fliplr([y2 y2])];
        xpoints=[[handles.Intervals(i,1) handles.Intervals(i,2)],fliplr([handles.Intervals(i,1) handles.Intervals(i,2)])];
        if 0
            hold on
        end
        handles.fillhandle.(['i' num2str(i)])=fill(xpoints,filled,ColorSet(i,:));%plot the data
        set(handles.fillhandle.(['i' num2str(i)]),'EdgeColor',ColorSet(i,:),...
            'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',handles.Intervals(i,:));%set edge color
        if 0
            hold off
        end
        
        cont.(['i' num2str(i)]) = uicontextmenu;
        
    else
        msg='Error: Must use the same number of points in each vector';
    end
    
end

for i=1:size(handles.Intervals,1)
    if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([handles.Intervals(i,1) handles.Intervals(i,2)])
        handles.fillhandle.(['i' num2str(i)]).UIContextMenu = cont.(['i' num2str(i)]);
        
        m1 = uimenu(cont.(['i' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
        m2 = uimenu(cont.(['i' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
    end
end

hold off

handles.Intervals_ylim = get(handles.Intervals_frame1.Children,'ylim');
handles.Intervals_xlim = get(handles.Intervals_frame1.Children,'xlim');

cont.('A') = uicontextmenu;
handles.Intervals_frame1.Children.UIContextMenu = cont.('A');
m1 = uimenu(cont.('A'),'Label','Add new interval','Callback',{@Add_new_interval,handles,handles.Intervals_ylim,ColorSet});

% assignin('base','handles',handles)
set(handles.Intervals_wait_str,'Visible','off')

set(handles.Intervals_calculate_area_pushbutton,'Visible','on')
set(handles.Intervals_Selected_intervals_area_str1,'Visible','on')
set(handles.Intervals_Selected_intervals_area_popupmenu,'Visible','on')
set(handles.Intervals_Selected_intervals_area_popupmenu,'Value',1)
set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','off')

set(handles.Intervals_Selected_intervals_area_uitable_str,'Visible','off')
set(handles.Intervals_Selected_intervals_area_uitable,'Visible','off')
set(handles.Intervals_save_to_excel_pushbutton,'Visible','off')
handles.Areas_Of_Selected_Intervals = [];
setappdata(0,'handles',handles)

end





function LineSelected(ObjectH, EventData, H)
handles = getappdata(0,'handles');

set(ObjectH, 'LineWidth', 2.5);
set(H(H ~= ObjectH), 'LineWidth', 0.5);

setappdata(0,'handles',handles)

end


function Add_new_interval(source,callbackdata,handles,ylim1,ColorSet)
% current_sample1 = getappdata(handles.figure1,'current_sample1');
% wavelengths1 = getappdata(handles.figure1,'wavelengths1');
handles = getappdata(0,'handles');

x_loc = source.Callback{2}.Intervals_frame1.Children.CurrentPoint(1,1);
n1 = find(handles.axis_min < x_loc);
if isempty(n1)
    x_range = [handles.axis_min(1) handles.axis_min(7)];
else
    n2 = handles.axis_min(n1(end))
    if n2 < 4
        x_range = [handles.axis_min(1) handles.axis_min(7)];
    elseif n2 > size(handles.axis_min,1)-3
        x_range = [handles.axis_min(end-6) handles.axis_min(end)];
    else
        x_range = [handles.axis_min(n1(end)-3) handles.axis_min(n1(end)+3)];
    end
    
end


i= size(handles.Intervals,1) + 1;
handles.Intervals(i,:) = x_range;

y1 = ylim1(1);
y2 = ylim1(2);

ColorSet(i,:) = ColorSet(1,:);

hold on
    
if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([handles.Intervals(i,1) handles.Intervals(i,2)])
    msg='';
    filled=[[y1 y1],fliplr([y2 y2])];
    xpoints=[[handles.Intervals(i,1) handles.Intervals(i,2)],fliplr([handles.Intervals(i,1) handles.Intervals(i,2)])];
    if 0
        hold on
    end
    handles.fillhandle.(['i' num2str(i)])=fill(xpoints,filled,ColorSet(i,:));%plot the data
    set(handles.fillhandle.(['i' num2str(i)]),'EdgeColor',ColorSet(i,:),...
        'FaceAlpha',.2,'EdgeAlpha',.2,'UserData',handles.Intervals(i,:));%set edge color
    if 0
        hold off
    end
    
    cont.(['i' num2str(i)]) = uicontextmenu;
else
    msg='Error: Must use the same number of points in each vector';
end

if length([y1 y1])==length([y2 y2]) && length([y2 y2])==length([handles.Intervals(i,1) handles.Intervals(i,2)])
    handles.fillhandle.(['i' num2str(i)]).UIContextMenu = cont.(['i' num2str(i)]);
    
    m1 = uimenu(cont.(['i' num2str(i)]),'Label','Change this Interval','Callback',{@changeThisItervals,handles,i,[y1 y2],ColorSet});
    m2 = uimenu(cont.(['i' num2str(i)]),'Label','Delete this Interval','Callback',{@deleteItervals,handles,i,[y1 y2],ColorSet});
end

Intervals = handles.Intervals;
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
kk2 = sortrows(kk2,1);
set(handles.Intervals_No_of_detected_intervals_str2, 'String', num2str(size(kk2,1)))

str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),3);
for i = 1:size(kk2,1)
    str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,1)} {'All'}];
end
set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)
set(handles.Intervals_Selected_intervals_area_popupmenu,'Visible','on')
set(handles.Intervals_Selected_intervals_area_popupmenu,'Value',1)
set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','off')
set(handles.Intervals_Selected_intervals_area_uitable_str,'Visible','off')
set(handles.Intervals_Selected_intervals_area_uitable,'Visible','off')


% set(handles.Intervals_Selected_intervals_uitable, 'String', num2str(kk2))
% set(handles.Intervals_Selected_intervals_uitable, 'Data', kk2)
rnames = (1:size(kk2,1))';
handles.Intervals_Selected_intervals_uitable.RowName = rnames;

setappdata(0,'handles',handles)

end






function changeThisItervals(source,callbackdata,handles,i,y,ColorSet)
handles = getappdata(0,'handles');


handles.him.(['h' num2str(i) '1']) = imline(handles.Intervals_frame1.Children,[handles.Intervals(i,1) handles.Intervals(i,1)], [y(1) y(2)]);
h1 = handles.him.(['h' num2str(i) '1']);
setColor(h1,[1 0 0])  % red color
fcn = makeConstrainToRectFcn('imline',handles.Intervals_xlim,handles.Intervals_ylim);
setPositionConstraintFcn(h1,fcn);
addNewPositionCallback(h1,@(h1)dragline_changeThisItervals(h1,handles,i,y,ColorSet));
setColor(h1,ColorSet(i,:))

handles.him.(['h' num2str(i) '2']) = imline(handles.Intervals_frame1.Children,[handles.Intervals(i,2) handles.Intervals(i,2)], [y(1) y(2)]);
h2 = handles.him.(['h' num2str(i) '2']);
setColor(h2,[1 0 0])  % red color
fcn = makeConstrainToRectFcn('imline',handles.Intervals_xlim,handles.Intervals_ylim);
setPositionConstraintFcn(h2,fcn);
addNewPositionCallback(h2,@(h2)dragline_changeThisItervals(h2,handles,i,y,ColorSet));
setColor(h2,ColorSet(i,:))

setappdata(0,'handles',handles)

end






function dragline_changeThisItervals(h,handles,i,y,ColorSet)
handles = getappdata(0,'handles');

temp = abs(handles.Intervals(i,:) - h(1,1));
loc1 = find(temp == min(temp));

X1 = h(1,1);
Xt1 = find(handles.axis_min < h(1,1));
if isempty(Xt1)
    Xt1 = 1;
end
Xt1 = handles.axis_min(Xt1(end));

Xt2 = find(handles.axis_min > X1);
if isempty(Xt2)
    Xt2 = length(handles.axis_min);
end
Xt2 = handles.axis_min(Xt2(1));
XData = Xt1;
if Xt2 - X1 < Xt1 - X1
    XData = Xt2;
end
XData1 = find (handles.axis_min == XData);
XData2 = handles.axis_min(XData1);

if loc1 == 1
    handles.fillhandle.(['i' num2str(i)]).Vertices =...
        [XData2 y(1);...
        handles.Intervals(i,2) y(1);...
        handles.Intervals(i,2) y(2);...
        XData2 y(2)];
    handles.Intervals(i,1) = XData2;
elseif loc1 == 2
    handles.fillhandle.(['i' num2str(i)]).Vertices =...
        [handles.Intervals(i,1) y(1);...
        XData2 y(1);...
        XData2 y(2);...
        handles.Intervals(i,1) y(2)];
    handles.Intervals(i,2) = XData2;
end

Intervals = handles.Intervals;
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
kk2 = sortrows(kk2,1);
set(handles.Intervals_No_of_detected_intervals_str2, 'String', num2str(size(kk2,1)))

str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),2);
for i = 1:size(kk2,1)
    str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,2)}];
end
temp = get(handles.Intervals_Selected_intervals_uitable, 'Data');
str_for_Intervals_Selected_intervals_uitable = [str_for_Intervals_Selected_intervals_uitable temp(:,3)];
set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)
set(handles.Intervals_Selected_intervals_area_popupmenu,'Visible','on')
% set(handles.Intervals_Selected_intervals_area_popupmenu,'Value',1)
% set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
% set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','off')
set(handles.Intervals_Selected_intervals_area_uitable_str,'Visible','off')
set(handles.Intervals_Selected_intervals_area_uitable,'Visible','off')

% set(handles.Intervals_Selected_intervals_uitable,'Value',1);
% set(handles.Intervals_Selected_intervals_uitable, 'Data', kk2)
rnames = (1:size(kk2,1))';
handles.Intervals_Selected_intervals_uitable.RowName = rnames;
set(handles.Intervals_No_of_detected_intervals_str2, 'String', num2str(size(kk2,1)))


% handles.Intervals

setappdata(0,'handles',handles)

end






function deleteItervals(source,callbackdata,handles,i,y,ColorSet)
handles = getappdata(0,'handles');

delete(handles.fillhandle.(['i' num2str(i)]))
try
    delete(handles.him.(['h' num2str(i) '1']))
    delete(handles.him.(['h' num2str(i) '2']))
end
handles.Intervals(i,:) = [NaN NaN];

Intervals = handles.Intervals;
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
kk2 = sortrows(kk2,1);
% set(handles.Intervals_Selected_intervals_uitable,'Value',1);
set(handles.Intervals_No_of_detected_intervals_str2, 'String', num2str(size(kk2,1)))


str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),3);
for i = 1:size(kk2,1)
    str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,1)} {'All'}];
end
set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)
set(handles.Intervals_Selected_intervals_area_popupmenu,'Visible','on')
set(handles.Intervals_Selected_intervals_area_popupmenu,'Value',1)
set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','off')
set(handles.Intervals_Selected_intervals_area_uitable_str,'Visible','off')
set(handles.Intervals_Selected_intervals_area_uitable,'Visible','off')
% set(handles.Intervals_Selected_intervals_uitable, 'Data', kk2)

rnames = (1:size(kk2,1))';
handles.Intervals_Selected_intervals_uitable.RowName = rnames;


setappdata(0,'handles',handles)

end









function Intervals_more_options_prepro_beads_checkbox_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Intervals_wait_str,'Visible','on')
pause(0.0000000000000001)





handles.Intervals_beads_checkbox_val = get(handles.Intervals_more_options_prepro_beads_checkbox,'Value');
temp = get(handles.Intervals_more_options_prepro_listbox,'String');
if handles.Intervals_beads_checkbox_val == 1
    
    if ischar(temp)
        handles.Intervals_more_options_prepro_listbox_data = {'beads'};
    else
        handles.Intervals_more_options_prepro_listbox_data = [handles.Intervals_more_options_prepro_listbox_data ; {'beads'}];
    end
    set(handles.Intervals_more_options_prepro_listbox,'String',handles.Intervals_more_options_prepro_listbox_data)
else
    if ~ischar(temp)
        flag = 0;
        for i = 1:size(handles.Intervals_more_options_prepro_listbox_data,1)
            switch handles.Intervals_more_options_prepro_listbox_data{i}
                case 'beads'
                    index_i = i;
                    flag = 1;
            end
        end
        if flag == 1
            handles.Intervals_more_options_prepro_listbox_data(index_i,:) = [];
        end
        if isempty(handles.Intervals_more_options_prepro_listbox_data)
            handles.Intervals_more_options_prepro_listbox_data = 'None';
        end
    else
        handles.Intervals_more_options_prepro_listbox_data = 'None';
    end
end
set(handles.Intervals_more_options_prepro_listbox,'String',handles.Intervals_more_options_prepro_listbox_data)
set(handles.Intervals_more_options_prepro_listbox,'Value',1)

if size(handles.Intervals_more_options_prepro_listbox_data,1) == 1
    set(handles.Intervals_up_2_down_pushbutton,'Visible','off');
elseif size(handles.Intervals_more_options_prepro_listbox_data,1) == 2
    set(handles.Intervals_up_2_down_pushbutton,'Visible','on');
end

setappdata(0,'handles',handles)
set(handles.Intervals_wait_str,'Visible','off')

end







function Intervals_more_options_prepro_msbackadj_checkbox_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Intervals_wait_str,'Visible','on')
pause(0.0000000000000001)

handles.Intervals_msbackadj_checkbox_val = get(handles.Intervals_more_options_prepro_msbackadj_checkbox,'Value');
temp = get(handles.Intervals_more_options_prepro_listbox,'String');
if handles.Intervals_msbackadj_checkbox_val == 1
    
    if ischar(temp)
        handles.Intervals_more_options_prepro_listbox_data = {'msbackadj'};
    else
        handles.Intervals_more_options_prepro_listbox_data = [handles.Intervals_more_options_prepro_listbox_data ; {'msbackadj'}];
    end
    set(handles.Intervals_more_options_prepro_listbox,'String',handles.Intervals_more_options_prepro_listbox_data)
else
    if ~ischar(temp)
        flag = 0;
        for i = 1:size(handles.Intervals_more_options_prepro_listbox_data,1)
            switch handles.Intervals_more_options_prepro_listbox_data{i}
                case 'msbackadj'
                    index_i = i;
                    flag = 1;
            end
        end
        if flag == 1
            handles.Intervals_more_options_prepro_listbox_data(index_i,:) = [];
        end
        if isempty(handles.Intervals_more_options_prepro_listbox_data)
            handles.Intervals_more_options_prepro_listbox_data = 'None';
        end
    else
        handles.Intervals_more_options_prepro_listbox_data = 'None';
    end
end
set(handles.Intervals_more_options_prepro_listbox,'String',handles.Intervals_more_options_prepro_listbox_data)
set(handles.Intervals_more_options_prepro_listbox,'Value',1)

if size(handles.Intervals_more_options_prepro_listbox_data,1) == 1
    set(handles.Intervals_up_2_down_pushbutton,'Visible','off');
elseif size(handles.Intervals_more_options_prepro_listbox_data,1) == 2
    set(handles.Intervals_up_2_down_pushbutton,'Visible','on');
end



setappdata(0,'handles',handles)
set(handles.Intervals_wait_str,'Visible','off')

end









function Intervals_up_2_down_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Intervals_wait_str,'Visible','on')
pause(0.0000000000000001)


temp(1,:) = handles.Intervals_more_options_prepro_listbox_data(2,:);
temp(2,:) = handles.Intervals_more_options_prepro_listbox_data(1,:);
handles.Intervals_more_options_prepro_listbox_data = temp;
set(handles.Intervals_more_options_prepro_listbox,'String',handles.Intervals_more_options_prepro_listbox_data)
set(handles.Intervals_more_options_prepro_listbox,'Value',1)



setappdata(0,'handles',handles)
set(handles.Intervals_wait_str,'Visible','off')

end







function Intervals_more_options_prepro_plot_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Intervals_wait_str,'Visible','on')
pause(0.0000000000000001)


if ~isempty(handles.Intervals_more_options_prepro_listbox_data) && ~ischar(handles.Intervals_more_options_prepro_listbox_data)
    if handles.preprocessing_accept_checkbox_val == 0
        
        handles.X2 = (squeeze(mean(permute(handles.matrix(:,:,:), [3 1 2]),3))');
        
        if size(handles.Intervals_more_options_prepro_listbox_data,1) == 1
            switch handles.Intervals_more_options_prepro_listbox_data{1}
                case 'msbackadj'
                    handles.X2 = msbackadj((1:size(handles.X2,2))',handles.X2');
                    handles.X2 = sum(handles.X2);
                    
                case 'beads'
                    
            end
        else
            for i = 1:2
                switch handles.Intervals_more_options_prepro_listbox_data{i}
                    case 'msbackadj'
                        handles.X2 = msbackadj((1:size(handles.X2,2))',handles.X2');
                        handles.X2 = sum(handles.X2);
                        
                    case 'beads'
                        
                end
            end
        end
        subplot(1,1,1,'parent',handles.Intervals_frame1)
        plot(handles.X2)
        
        
        
        
        %     if handles.Intervals_until_next_minimum_checkbox_val == 0
        %         [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(permute(handles.matrix , [3 1 2]),handles.axis_min,std_value,peak_width,space_between_two_intervals,0,handles);
        %     else
        %         [handles.Intervals,handles.X_axis_label,handles.hh] = peak_extraction_PARADISe(permute(handles.matrix , [3 1 2]),handles.axis_min,std_value,peak_width,space_between_two_intervals,1,handles);
        %     end
        
    elseif handles.preprocessing_accept_checkbox_val == 1
        
        handles.X2 = (squeeze(mean(handles.xCS,3))');
        if size(handles.Intervals_more_options_prepro_listbox_data,1) == 1
            switch handles.Intervals_more_options_prepro_listbox_data{1}
                case 'msbackadj'
                    handles.X2 = msbackadj((1:size(handles.X2,2))',handles.X2');
                    handles.X2 = sum(handles.X2);
                    
                case 'beads'
                    
            end
        else
            for i = 1:2
                switch handles.Intervals_more_options_prepro_listbox_data{i}
                    case 'msbackadj'
                        handles.X2 = msbackadj((1:size(handles.X2,2))',handles.X2');
                        handles.X2 = sum(handles.X2);
                        
                    case 'beads'
                        
                end
            end
        end
        subplot(1,1,1,'parent',handles.Intervals_frame1)
        plot(handles.X2)
        
    end
    
    
end





% handles.X2 = (squeeze(mean(handles.X(:,:,:),3))');
% 
% if size(handles.listbox1_data,1) == 1
%     switch handles.listbox1_data{1}
%         case 'msbackadj'
%             handles.X2 = msbackadj((1:size(handles.X2,2))',handles.X2');
%             handles.X2 = sum(handles.X2);
%             
%         case 'beads'
%             
%     end
% else
%     for i = 1:2
%         switch handles.listbox1_data{i}
%             case 'msbackadj'
%                 handles.X2 = msbackadj((1:size(handles.X2,2))',handles.X2');
%                 handles.X2 = sum(handles.X2);
%                 
%             case 'beads'
%                 
%         end
%     end
% end
% plot(handles.X2)










setappdata(0,'handles',handles)
set(handles.Intervals_wait_str,'Visible','off')

end





function Intervals_calculate_area_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
handles.Areas_Of_Selected_Intervals = [];


Intervals = handles.Intervals(:,1:2);
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
Intervals = sortrows(kk2,1);

% handles.axis_min,handles.axis_mz
% % for i = 1:size(Intervals,1)
% %     handles.Areas_Of_Selected_Intervals(:,i) = Integrate1(Intervals(i,1), Intervals(i,2),handles.axis_min, handles.matrix);
% % end
% assignin('base','Areas_Of_Selected_Intervals',handles.Areas_Of_Selected_Intervals)
if handles.Intervals_Selected_intervals_area_popupmenu_val == 1
    handles.QuantIon = {handles.axis_mz};
    handles.QuantIon = repmat(handles.QuantIon,size(Intervals,1),1);
elseif handles.Intervals_Selected_intervals_area_popupmenu_val == 2
    % elseif handles.Intervals_Selected_intervals_area_popupmenu_val == 3
    %     QuantIon = Import_from_workspace1;
end
data = get(handles.Intervals_Selected_intervals_uitable, 'Data');
% assignin('base','data',data)
if isempty(data{1,3})
    errordlg('Please, Input M/Z range for all intervals and try again.')
    return
end
handles.QuantIon = cell(size(data,1),1);
for i = 1:size(data,1)
    switch data{i,3}
        case 'All'
            handles.QuantIon (i,1) = {handles.axis_mz};
        otherwise
            if ischar(data{i,3})
                switch data{i,3}(1)
                    case '['
                        str1 = data{i,3};
                        tf3 = strfind(str1,'[');
                        if length(tf3) > 1
                            tf1 = strfind(str1,',');
                            if isempty(tf1)
                                tf2 = strfind(str1,']');
                                for j =length(tf2)-1 : -1 : 1
                                    str1 = [str1(1:tf2(j)) ',' str1(tf2(j)+1:end)];
                                end
                            end
                            str2 = ['[' str1 ']'];
                            handles.QuantIon (i,1) = {eval(str2)};
                        else
                            handles.QuantIon (i,1) = {eval(str1)};
                        end
                    otherwise
                        txt1 = ['[' data{i,3} ']'];
                        % handles.QuantIon (i,1) = {str2num(data{i,3})};
                        handles.QuantIon (i,1) = {eval(txt1)};
                end
            else
                handles.QuantIon (i,1) = data(i,3);
            end
    end
% handles.QuantIon (i,1) = {}

end
% assignin('base','QuantIon222',handles.QuantIon)


for i=1:size(Intervals,1)
    RT_ranges (i,1) = {Intervals(i,:)};
end
% assignin('base','RT_ranges',RT_ranges)
% assignin('base','QuantIon',QuantIon)
% RT_ranges
% QuantIon
Areas_Of_Selected_Intervals1 = GetPeakAreasForNabi(handles.matrix, RT_ranges, handles.axis_min,handles.QuantIon);
handles.Areas_Of_Selected_Intervals = Areas_Of_Selected_Intervals1.data;


for i = 1:size(Intervals,1)
    txt(i,1) = {[num2str(Intervals(i,1)) '-' num2str(Intervals(i,2))]};
end
set(handles.Intervals_Selected_intervals_area_uitable,'ColumnName', txt)
set(handles.Intervals_Selected_intervals_area_uitable,'RowName', handles.filename_for_listbox)

set(handles.Intervals_Selected_intervals_area_uitable,'Data',handles.Areas_Of_Selected_Intervals)

setappdata(0,'handles',handles)
set(handles.Intervals_wait_str,'Visible','off')

set(handles.Intervals_Selected_intervals_area_uitable_str,'Visible','on')
set(handles.Intervals_Selected_intervals_area_uitable,'Visible','on')
set(handles.Intervals_save_to_excel_pushbutton,'Visible','on')


end







% 
% set(handles.Intervals_calculate_area_pushbutton,'Visible','on')
% set(handles.Intervals_Selected_intervals_area_str1,'Visible','on')
% set(handles.Intervals_Selected_intervals_area_popupmenu,'Visible','on')
% set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')


function Intervals_Selected_intervals_area_popupmenu_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

handles.Intervals_Selected_intervals_area_popupmenu_val = get(handles.Intervals_Selected_intervals_area_popupmenu,'Value');

Intervals = handles.Intervals;
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
kk2 = sortrows(kk2,1);

if handles.Intervals_Selected_intervals_area_popupmenu_val == 2
    
    str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),3);
    for i = 1:size(kk2,1)
        str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,2)} {''}];
    end
    set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)

    set(handles.Intervals_Selected_intervals_area_edit,'Visible','on')
    set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','on')
elseif handles.Intervals_Selected_intervals_area_popupmenu_val == 3
    handles.QuantIon = Import_from_workspace1;
    if isempty(handles.QuantIon)
        str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),3);
        for i = 1:size(kk2,1)
            str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,2)} {''}];
        end
        set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)
        
        return
    end
    str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),3);
    for i = 1:size(kk2,1)
        str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,2)} {cell2str(handles.QuantIon(i))}];
    end
    set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)
    
    set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
    set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','off')
else
    set(handles.Intervals_Selected_intervals_area_edit,'Visible','off')
    set(handles.Intervals_Selected_intervals_area_apply_pushbutton,'Visible','off')

    str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),3);
    for i = 1:size(kk2,1)
        str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,2)} {'All'}];
    end
    set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)
    
end

setappdata(0,'handles',handles)

end






function Intervals_Selected_intervals_area_apply_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

temp = get(handles.Intervals_Selected_intervals_area_edit,'String');

Intervals = handles.Intervals;
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
kk2 = sortrows(kk2,1);

temp2 = repmat(temp , size(kk2,1) , 1);
str_for_Intervals_Selected_intervals_uitable = cell(size(kk2,1),3);
for i = 1:size(kk2,1)
    str_for_Intervals_Selected_intervals_uitable(i,:) = [{kk2(i,1)} {kk2(i,2)} {temp2(i,:)}];
end
set(handles.Intervals_Selected_intervals_uitable, 'Data', str_for_Intervals_Selected_intervals_uitable)

QuantIon = eval(['{' temp '}']);
QuantIon = QuantIon';
QuantIon = repmat(QuantIon , size(kk2,1) , 1);
handles.QuantIon = QuantIon;

setappdata(0,'handles',handles)
end





function Intervals_save_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

Intervals = handles.Intervals(:,1:2);
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
Intervals = sortrows(kk2,1);

if isempty(handles.Areas_Of_Selected_Intervals)
    checkLabels = {'Intervals'};
    varNames = {'Intervals'};
    items = {Intervals};
    export2wsdlg(checkLabels, varNames, items, 'Save to Workspace');
    
else
    checkLabels = {'Intervals','Areas'};
    varNames = {'Intervals','Areas'};
    items = {Intervals,handles.Areas_Of_Selected_Intervals};
    export2wsdlg(checkLabels, varNames, items, 'Save to Workspace');
end
setappdata(0,'handles',handles)

end



function Intervals_save_to_excel_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

Intervals = handles.Intervals(:,1:2);
kk = ~isnan(Intervals(:,1));
kk2 = Intervals(kk,:);
Intervals = sortrows(kk2,1);
for i = 1:size(Intervals,1)
    txt(i,1) = {[num2str(Intervals(i,1)) '-' num2str(Intervals(i,2))]};
end

% set(handles.Intervals_Selected_intervals_area_uitable,'ColumnName', txt)
% set(handles.Intervals_Selected_intervals_area_uitable,'RowName', handles.filename_for_listbox)

set(handles.Intervals_Selected_intervals_area_uitable,'Data',handles.Areas_Of_Selected_Intervals)

prompt = {'Input name for excel file:'};
name = 'Input excel file name';
numlines = 1;
defaultanswer = {'data'};
excel_name = inputdlg(prompt,name,numlines,defaultanswer);
if isempty(excel_name)
    return
end
xlswrite([excel_name{1} '.xlsx'],(handles.filename_for_listbox)',excel_name{1},'A2')
xlswrite([excel_name{1} '.xlsx'],txt',excel_name{1},'B1')
xlswrite([excel_name{1} '.xlsx'],handles.Areas_Of_Selected_Intervals,excel_name{1},'B2')

setappdata(0,'handles',handles)
end











% =============================================================================================================================
% Resolve
% =============================================================================================================================

function Resolve_parafac2_options_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');
% subplot(1,1,1,'parent',handles.Preprocessing_frame1)
% plot(0,0,'*w')
% axis off

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)

temp = nabi_PARAFAC_options(handles.parafac2.options)
if ~isempty(temp)
     handles.parafac2.options = temp;
end


setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end









function Resolve_run_parafac2_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)

% k1 = handles.Intervals;
% kk = ~isnan(k1(:,1));
% Intervals = k1(kk,:);
% Intervals = sortrows(Intervals,1);
% set(handles.Intervals_Selected_intervals_uitable,'Value',1);
% set(handles.Intervals_Selected_intervals_uitable, 'String', num2str(kk2))
% set(handles.Intervals_No_of_detected_intervals_str2, 'String', num2str(size(kk2,1)))

handles.P2_models = [];

if ~isempty(handles.Intervals)
    Intervals = handles.Resolve_uitable_run_parafac2.Data;
else
    Intervals = [];
end

size_Intervals = size(Intervals,1);
first_int_factors = str2num(Intervals{1,3});
set(handles.Resolve_intervals_uitable_1,'Data', 1:size(Intervals,1));
set(handles.Resolve_factors_uitable_2,'Data', first_int_factors)



for k = 1:size(Intervals,1);
    int_no = str2num(Intervals{k,3})
    for jj = 1:length(int_no)
        int1 = find(handles.axis_min == Intervals{k,1});
        int2 = find(handles.axis_min == Intervals{k,2});
        
        if handles.preprocessing_accept_checkbox_val == 0
            
            
            data = handles.matrix(int1:int2,:,:);
            [int1 int2 size(data) int_no(jj)]
            model =  parafac2(data,int_no(jj),handles.parafac2.options);
            handles.P2_models{k,jj} = model;
            
            
            
            
        elseif handles.preprocessing_accept_checkbox_val == 1
            %             size(handles.xCS)
            
        end
        
        
        
        
        %     for i = all_P{1,k}(1,1):all_P{1,k}(1,end);
        %
        %         model =  parafac2(all_ints{1,k},i,op2);
        %
        %         P2_models{k,i} = model;
        %
        %         save (['Parafac' num2str(k)], 'P2_models');
        %
        %     end;
    end
        
end

% load P2_models
% handles.P2_models = P2_models;



% assignin('base','P2_models',P2_models)





% handles.Intervals_frame1
% handles.Intervals_frame2
% handles.Intervals_frame3
% handles.Intervals_frame4
% handles.Intervals_frame5
% handles.Intervals_frame6









% mz = handles.axis_mz;
% RTs = handles.axis_min;
% 
% loc1=find(handles.axis_min == handles.Intervals(1,1));
% loc2=find(handles.axis_min == handles.Intervals(1,2));
% rt = handles.axis_min(loc1:loc2);
% 
% handles.Nint=1; % what Interval
% handles.Npc=1; % what Component
%     
% x=handles.P2_models{handles.Nint,handles.Npc};
% 
% y = handles.matrix(loc1:loc2,:,:);
% 
% name=('MS of ');
% 
% 
% 
% 
% 
% 
% 
% 
% 
% % Get Weighted Elution Profiles
% P=x.loads{1}.P; H=x.loads{1}.H; A=x.loads{3};
% for i=1:length(P)
%     L(:,:,i)=P{i}*H;
%     for f=1:size(A,2)
%         L(:,f,i)=L(:,f,i)*A(i,f);
%     end
% end
% 
% color={'b','g','r','c','m','y','k','b','g','r','c','m','y','k'}; 
% Elutions=L; 
% Conc=A;
% 
% % Get MS profiles
% for i=1:f
%     for k=1:length(mz)
%         MS(k,i)=x.loads{2,1}(k,i);
%     end
% end
% 
% % figure
% subplot(1,1,1,'Parent',handles.Resolve_frame1)
% plot(1:110,1:110,'w.'); 
% axis tight
% hold on
% 
% text(5, 95, [num2str(size(x.loads{3,1},2)) '  Factors']);
% text(5, 85, [num2str(x.detail.ssq.perc) ' %  Explained Variance' ]);
% text(5, 75, [num2str(x.detail.innercore.coreconsistency.consistency) ' Core Consistancy']);
% text(2, 65, [x.detail.converged.message ' = StopCrit']);
% title(['interval#' num2str(handles.Nint) ' / / PARAFAC2 Model Details']);
% 
% hold off
% 
% 
% % figure% Plot TIC of RAW Chrom Interval
% subplot(1,1,1,'Parent',handles.Resolve_frame2)
% plot(rt,squeeze(sum(y,2)))
% axis tight
% xlabel('RT sec')
% title(['interval#' num2str(handles.Nint) ' / / TIC'])
% 
% 
% % figure% Superimpose Elution profiles
% subplot(1,1,1,'Parent',handles.Resolve_frame3)
% legend_str = {};
% for i=1:f
%     plot(rt,squeeze(sum(Elutions(:,i,:),2)),color{i})
%     axis tight
%     hold on
%     
%     xlabel('RT sec')
%     legend_str(i) = {['PC#' num2str(i)]};
%     %         legend(['PC#' num2str(i)],'Location','northwest')
% end
% % legend(legend_str,'Location','northwest')
% title('Resolved Elution Profiles')
% hold off
% 
% % figure% Subplot Elution profiles
% % subplot(1,1,1,'Parent',handles.Intervals_frame4)
% for i=f
%     subplot(1,1,1,'Parent',handles.Resolve_frame4)
% 
% %     subplot(f,1,i)
%     plot(rt,squeeze(sum(Elutions(:,i,:),2)),color{i})
%     axis tight
%     legend(['PC#' num2str(i)],'Location','northwest');%title(['interval#' num2str(handles.Nint) ' / / Conc of PC#' num2str(i)]);
%     hold on
% end
% xlabel('RT sec');
% hold off
% 
% % Subplot resolved MS profiles
% % figure
% for i=f
% %     subplot(f,1,i)
%     subplot(1,1,1,'Parent',handles.Resolve_frame5)
%     bar(mz,x.loads{2,1}(:,i),0.001,color{i})
%     axis tight
% hold on
% legend(['PC#' num2str(i)],'Location','northwest')
% end
% xlabel('m/z')
% hold off
% 
% % figure% Plot Concentration Prifiles
%  for i=f
%      subplot(1,1,1,'Parent',handles.Resolve_frame6)
% %      subplot(f,1,i)
%      bar(1:size(y,3),A(:,i),0.2,color{i})
%      hold on;%title(['interval#' num2str(handles.Nint) ' / / Conc of PC#' num2str(i)]);
%  hold on
%  legend(['PC#' num2str(i)],'Location','northwest');%text(1:size(y,3),A(:,i)*1.45,y.label{3,1});
%  ylim([0 max(A(:,i))*1.55])
%  end
%  xlabel('Samples')
%  hold off
% 
% a2=x.detail.innercore.coreconsistency.consistency;
% 
















        
        
        




% save PARAFAC2_models P2_models all_ints all_P RTs mz op2



% handles.Resolve_run_parafac2_pushbutton




% selected_interval = handles.Resolve_intervals_uitable_1.Data(eventdata.Indices(1,2))
% selected_factor = handles.Resolve_factors_uitable_2.Data(eventdata.Indices(1,2))








setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end







% handles.Resolve_intervals_uitable_1 = uitable('Parent',handles.h3_tab_Resolve,'Data', {0 0 0},...
%     'FontSize',11,'ColumnName', [],'RowName',[],'Callback',@Resolve_intervals_uitable_1_Callback,...
%     'Position', [55 7 400 30]);
% 
% 
% 
% % columnname = {'1','2','3'};
% handles.Resolve_factors_uitable_str2 = uicontrol('Parent', handles.h3_tab_Resolve, 'Style', 'text', 'String',...
%     'Factors:','FontSize',8,'Visible','on', 'HorizontalAlignment', 'left', 'Position', [520 10 70 20]) ;
% 
% handles.Resolve_factors_uitable_2 = uitable('Parent',handles.h3_tab_Resolve,'Data', {0 0 0},...
%     'FontSize',11,'ColumnName', [],'RowName',[],'Callback',@Resolve_factors_uitable_2_Callback,...
%     'Position', [565 7 400 30]);






function Resolve_intervals_uitable_1_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)
% eventdata.Indices(1,2)

selected_interval = handles.Resolve_intervals_uitable_1.Data(eventdata.Indices(1,2))
temp_Intervals = handles.Resolve_uitable_run_parafac2.Data;
temp_factors = str2num(temp_Intervals{selected_interval,3});

% set(handles.Resolve_factors_uitable_2,'Data',temp_factors)
handles.Nint=selected_interval; % what Interval













% mz = handles.axis_mz;
% RTs = handles.axis_min;
% 
% loc1=find(handles.axis_min == handles.Intervals(handles.Nint,1));
% loc2=find(handles.axis_min == handles.Intervals(handles.Nint,2));
% rt = handles.axis_min(loc1:loc2);
% 
% % handles.Npc=1; % what Component
%     
% x=handles.P2_models{handles.Nint,handles.Npc};
% 
% y = handles.matrix(loc1:loc2,:,:);
% 
% name=('MS of ');
% 
% 
% 
% 
% 
% 
% 
% 
% 
% % Get Weighted Elution Profiles
% P=x.loads{1}.P; H=x.loads{1}.H; A=x.loads{3};
% for i=1:length(P)
%     L(:,:,i)=P{i}*H;
%     for f=1:size(A,2)
%         L(:,f,i)=L(:,f,i)*A(i,f);
%     end
% end
% 
% color={'b','g','r','c','m','y','k','b','g','r','c','m','y','k'}; 
% Elutions=L; 
% Conc=A;
% 
% % Get MS profiles
% for i=1:f
%     for k=1:length(mz)
%         MS(k,i)=x.loads{2,1}(k,i);
%     end
% end
% 
% % figure
subplot(1,1,1,'Parent',handles.Resolve_frame1)
plot(0,0,'W.')
axis off
% plot(1:110,1:110,'w.'); 
% axis tight
% hold on
% 
% text(5, 95, [num2str(size(x.loads{3,1},2)) '  Factors']);
% text(5, 85, [num2str(x.detail.ssq.perc) ' %  Explained Variance' ]);
% text(5, 75, [num2str(x.detail.innercore.coreconsistency.consistency) ' Core Consistancy']);
% text(2, 65, [x.detail.converged.message ' = StopCrit']);
% title(['interval#' num2str(handles.Nint) ' / / PARAFAC2 Model Details']);
% hold off
% % figure% Plot TIC of RAW Chrom Interval
subplot(1,1,1,'Parent',handles.Resolve_frame2)
plot(0,0,'W.')
axis off

% plot(rt,squeeze(sum(y,2)))
% axis tight
% xlabel('RT sec')
% title(['interval#' num2str(handles.Nint) ' / / TIC'])
% 
% 
% % % % % figure% Superimpose Elution profiles
subplot(1,1,1,'Parent',handles.Resolve_frame3)
plot(0,0,'W.')
axis off

% % % % for i=1:f
% % % %     plot(rt,squeeze(sum(Elutions(:,i,:),2)),color{i})
% % % %     axis tight
% % % %     hold on
% % % %     
% % % %     xlabel('RT sec')
% % % %     legend(['PC#' num2str(i)],'Location','northwest')
% % % % end
% % % % title('Resolved Elution Profiles')
% % % % hold off
% 
% % figure% Subplot Elution profiles
subplot(1,1,1,'Parent',handles.Resolve_frame4)
plot(0,0,'W.')
axis off


% for i=f
%     subplot(1,1,1,'Parent',handles.Resolve_frame4)
% 
% %     subplot(f,1,i)
%     plot(rt,squeeze(sum(Elutions(:,i,:),2)),color{i})
%     axis tight
%     legend(['PC#' num2str(i)],'Location','northwest');%title(['interval#' num2str(handles.Nint) ' / / Conc of PC#' num2str(i)]);
%     hold on
% end
% xlabel('RT sec');
% hold off
% 
% % Subplot resolved MS profiles
% % figure
% for i=f
% %     subplot(f,1,i)
subplot(1,1,1,'Parent',handles.Resolve_frame5)
plot(0,0,'W.')
axis off

%     bar(mz,x.loads{2,1}(:,i),0.001,color{i})
%     axis tight
% hold on
% legend(['PC#' num2str(i)],'Location','northwest')
% end
% xlabel('m/z')
% hold off
% 
% % figure% Plot Concentration Prifiles
%  for i=f
subplot(1,1,1,'Parent',handles.Resolve_frame6)
plot(0,0,'W.')
axis off

% %      subplot(f,1,i)
%      bar(1:size(y,3),A(:,i),0.2,color{i})
%      hold on;%title(['interval#' num2str(handles.Nint) ' / / Conc of PC#' num2str(i)]);
%  hold on
%  legend(['PC#' num2str(i)],'Location','northwest');%text(1:size(y,3),A(:,i)*1.45,y.label{3,1});
%  ylim([0 max(A(:,i))*1.55])
%  end
%  xlabel('Samples')
%  hold off
% 
% a2=x.detail.innercore.coreconsistency.consistency;
% 
% 
% 


handles.Npc = 1;




setappdata(0,'handles',handles)


handles.Resolve_factors_uitable_2.Data = temp_factors;




setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end





function Resolve_factors_uitable_2_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)
% eventdata.Indices(1,2)
if isempty(eventdata.Indices)
    setappdata(0,'handles',handles)
    set(handles.Resolve_wait_str,'Visible','off')
    return
else
    selected_factor = eventdata.Indices(1,2);
    handles.Npc=selected_factor; % what Component
end
















mz = handles.axis_mz;
RTs = handles.axis_min;

loc1=find(handles.axis_min == handles.Intervals(handles.Nint,1));
loc2=find(handles.axis_min == handles.Intervals(handles.Nint,2));
rt = handles.axis_min(loc1:loc2);

% handles.Nint=selected_interval; % what Interval
    
x=handles.P2_models{handles.Nint,handles.Npc};

y = handles.matrix(loc1:loc2,:,:);

name=('MS of ');









% Get Weighted Elution Profiles
P=x.loads{1}.P; H=x.loads{1}.H; A=x.loads{3};
for i=1:length(P)
    L(:,:,i)=P{i}*H;
    for f=1:size(A,2)
        L(:,f,i)=L(:,f,i)*A(i,f);
    end
end

color={'b','g','r','c','m','y','k','b','g','r','c','m','y','k'}; 
Elutions=L; 
Conc=A;

% Get MS profiles
for i=1:f
    for k=1:length(mz)
        MS(k,i)=x.loads{2,1}(k,i);
    end
end

% figure

subplot(1,1,1,'Parent',handles.Resolve_frame1)

plot(1:110,1:110,'w.'); 
axis tight
text(5, 95, [num2str(size(x.loads{3,1},2)) '  Factors']);

hold on

text(5, 85, [num2str(x.detail.ssq.perc) ' %  Explained Variance' ]);
text(5, 75, [num2str(x.detail.innercore.coreconsistency.consistency) ' Core Consistancy']);
text(2, 65, [x.detail.converged.message ' = StopCrit']);
title(['interval#' num2str(handles.Nint) ' / / PARAFAC2 Model Details']);
hold off
% figure% Plot TIC of RAW Chrom Interval
subplot(1,1,1,'Parent',handles.Resolve_frame2)
plot(rt,squeeze(sum(y,2)))
axis tight
xlabel('RT sec')
title(['interval#' num2str(handles.Nint) ' / / TIC'])


% figure% Superimpose Elution profiles
subplot(1,1,1,'Parent',handles.Resolve_frame3)
legend_str = {};
for i=1:f
    plot(rt,squeeze(sum(Elutions(:,i,:),2)),color{i})
    axis tight
    hold on
    
    xlabel('RT sec')
    %     legend_str(i) = {['PC#' num2str(i)]};
    legend(['PC#' num2str(i)],'Location','northwest')
end
% legend(legend_str,'Location','northwest')
title('Resolved Elution Profiles')
hold off

% figure% Subplot Elution profiles
% subplot(1,1,1,'Parent',handles.Intervals_frame4)
for i=f
    subplot(1,1,1,'Parent',handles.Resolve_frame4)

%     subplot(f,1,i)
    plot(rt,squeeze(sum(Elutions(:,i,:),2)),color{i})
    axis tight
    legend(['PC#' num2str(i)],'Location','northwest');%title(['interval#' num2str(handles.Nint) ' / / Conc of PC#' num2str(i)]);
    hold on
end
xlabel('RT sec');
hold off

% Subplot resolved MS profiles
% figure
for i=f
%     subplot(f,1,i)
    subplot(1,1,1,'Parent',handles.Resolve_frame5)
    bar(mz,x.loads{2,1}(:,i),0.001,color{i})
    axis tight
hold on
legend(['PC#' num2str(i)],'Location','northwest')
end
xlabel('m/z')
hold off

% figure% Plot Concentration Prifiles
 for i=f
     subplot(1,1,1,'Parent',handles.Resolve_frame6)
%      subplot(f,1,i)
     bar(1:size(y,3),A(:,i),0.2,color{i})
     hold on;%title(['interval#' num2str(handles.Nint) ' / / Conc of PC#' num2str(i)]);
 hold on
 legend(['PC#' num2str(i)],'Location','northwest');%text(1:size(y,3),A(:,i)*1.45,y.label{3,1});
 ylim([0 max(A(:,i))*1.55])
 end
 xlabel('Samples')
 hold off

a2=x.detail.innercore.coreconsistency.consistency;

















setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end















% handles.Resolve_No_of_component_for_all_pushbutton = uicontrol('Parent',handles.h1_tab_Resolve, 'Style', 'pushbutton', 'String',...
%     'Apply to all','Callback',{@Resolve_No_of_component_for_all_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [130 430 65 25]) ;


function Resolve_No_of_component_for_all_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)

Resolve_No_of_component_for_all_val = get(handles.Resolve_No_of_component_for_all_edit,'String');
% handles.Resolve_No_of_component_for_all_edit = uicontrol('Parent', handles.h1_tab_Resolve, 'Style', 'edit','String',...
%     '2:3','Visible','on','Position', [67 432 60 20]) ;


if ~isempty(handles.Intervals)
    Intervals = handles.Intervals;
    kk = ~isnan(Intervals(:,1));
    kk2 = Intervals(kk,:);
    kk2 = sortrows(kk2,1);
    
    temp = kk2;
    for ii = 1:size(temp,1)
        temp1(ii,:) = {kk2(ii,1) kk2(ii,2) Resolve_No_of_component_for_all_val};
    end
    Intervals = temp1;
    set(handles.Resolve_uitable_run_parafac2, 'Data', Intervals)
    
    rnames = (1:size(temp,1))';
    handles.Resolve_uitable_run_parafac2.RowName = rnames;
else
    handles.Resolve_uitable_run_parafac2.Data = [];
end






setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end







function Resolve_save_results_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)



checkLabels = {'Resolve Table Data','P2_models'};
varNames = {'resolve_table_data','P2_models'};


if ~isempty(handles.Intervals)
    data = str2double(get(handles.Resolve_uitable_run_parafac2, 'Data'));
    
    items = {data,handles.P2_models};
    export2wsdlg(checkLabels, varNames, items, 'Save to Workspace');
    
end




setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end



% handles.Accept_this_result_as_the_best_pushbutton = uicontrol('Parent',handles.h3_tab_Resolve, 'Style', 'pushbutton', 'String',...
%     'Accept','Callback',{@Accept_this_result_as_the_best_pushbutton_Callback,handles}, 'HorizontalAlignment', 'left', 'Position', [700 20 65 25]) ;
% 
% handles.Accept_this_result_as_the_best_uitable = uitable('Parent',handles.h3_tab_Resolve,'Data', d,... 
%             'ColumnName', columnname, 'ColumnFormat', columnformat, 'ColumnEditable', [false false],...
%             'RowName',rnames, 'Position', [800 2 200 80]);


function Accept_this_result_as_the_best_pushbutton_Callback(source,eventdata,handles)
handles = getappdata(0,'handles');

set(handles.Resolve_wait_str,'Visible','on')
pause(0.0000000000000001)



Intervals = handles.Resolve_uitable_run_parafac2.Data;
% Intervals{handles.Nint,3}
% str2num(Intervals{handles.Nint,3})
factors1 = str2num(Intervals{handles.Nint,3});







data2 = double(get(handles.Accept_this_result_as_the_best_uitable,'Data'));



data2(handles.Nint,:) = [handles.Nint factors1(handles.Npc)];
% handles.Nint=1; % what Interval
% handles.Npc=1; % what Component
rnames = 1:size(Intervals,1);
set(handles.Accept_this_result_as_the_best_uitable,'Data',data2,'RowName',rnames)




setappdata(0,'handles',handles)
set(handles.Resolve_wait_str,'Visible','off')

end









% =============================================================================================================================
% Identification
% =============================================================================================================================







% =============================================================================================================================
% Export
% =============================================================================================================================




















% =============================================================================================================================
% Help UImenu
% =============================================================================================================================


function Import_and_view_uimenu_help(source,callbackdata)

PARADISe_uimenu_help_window('Import and view help window' , 'Import and view')

end



function Preprocessing_uimenu_help(source,callbackdata)

PARADISe_uimenu_help_window('Preprocessing (icoshiftMC) help window' , 'Preprocessing (icoshiftMC)')

end



function Intervals_uimenu_help(source,callbackdata)

PARADISe_uimenu_help_window('Intervals help window' , 'Intervals')

end



function Resolve_uimenu_help(source,callbackdata)

PARADISe_uimenu_help_window('Resolve help window' , 'Resolve')

end



function Identification_uimenu_help(source,callbackdata)

PARADISe_uimenu_help_window('Identification help window' , 'Identification')

end



function Export_uimenu_help(source,callbackdata)

PARADISe_uimenu_help_window('Export help window' , 'Export')

end
