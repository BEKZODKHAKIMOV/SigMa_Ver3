


function tf = haveInet
tf = false;
  try
    address = java.net.InetAddress.getByName('www.google.de')
    tf = true;
  end
  tf
end
