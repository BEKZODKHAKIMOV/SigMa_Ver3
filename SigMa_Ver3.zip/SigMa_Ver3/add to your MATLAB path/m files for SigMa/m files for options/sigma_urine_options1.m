function [ options ] = sigma_urine_options1
%
%
% options for "sigma_urine_options" function
% to see how default "options" look run  [ options ] = sigma_urine_options;
% 
% Note: user can enter the option they wish rest will be set to default parameters
%
%
% Option 1
% Get NMR Spectral Regions of Known Metabolites (class 1), Unknown Spin Systems (class 2), & Bins(class 3)  
% example:   
% intervals = {'1' 'alanine' ' 1.498' ' 1.475';
% '2' 'unk10_s' ' 1.28' ' 1.268';
% '3' 'bin24' ' 2.092' '  2.08'};
% 
 %
% Option 2
% Get VariableClass
% It can only be 1-to-3
% 1 = knowns
% 2 = unknowns
% 3 = bins (this includes (optionally) user defined, automatically selected, and any other region left out as bins)
%
%
% Option 3
% Get BaseLineRemove
% No=0 & Yes=1. 
% default : options.BaseLineRemove= [0];  
%
% Option 4
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "
% default : options.BaseLineProportion = 20;
%
% Option 5
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 
% default : options.cutoff=3;
%
% Option 6
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.3 -0.3];
%
%
% Option 7
% Get preAlignment seetings for a global icoshift. Please type "help icoshift3"
% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment ans stop and return preAlignedData  
% default : options.preAlignment.status=[0];  
% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc. This optional input can also be left out.
% options.preAlignment.regions = [9 0.2];  means only do preAlignment of 9-0.2 ppm
% Target vector used for global icoshift
% default : options.preAlignment.target= 'average';
% definition of alignment mode
% default : options.preAlignment.inter='whole';
% shift allowed (optional)
% default : options.preAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.preAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 8
% Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"
% Target vector used for global icoshift
% default : options.intervalAlignment.target = 'average';
% shift allowed (optional)
% default : options.intervalAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.intervalAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  ionlt the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0
% default : options.wholeSpectra=1;
%
% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3
%
% Option 11
% Color Styles
%
%
% BKH, 17.02.2020

%% Option 0
load('urine_ref.mat');
load('urine_ref_ppm.mat');
options.ref_spect=urine_ref;
options.ref_spect_ppm=urine_ref_ppm;

%% Option 1
intervals={'1' 'TSP' '0.02' '-0.02' '0.0001' '0.0001' '1' '1' '1';
'2' 'unk_d' '0.5753' '0.5385' '0.0005' '0.007' '1' '1' '1';
'2' 'unk_d' '0.7617' '0.7405' '0.002' '0.004' '1' '1' '1';
'1' 'isoleucine' '0.9398' '0.9311' '0.0001' '0.0001' '1' '1' '1';
'1' 'leucine' '0.9781' '0.9584' '0.002' '0.0012' '1' '1' '1';
'1' '4-aminobutyrate' '0.9877' '0.9805' '0.0001' '0.0001' '1' '1' '1';
'1' 'valine' '1.004' '0.9861' '0.0001' '0.0001' '1' '1' '1';
'1' 'isoleucine' '1.025' '1.006' '0.001' '0.001' '1' '1' '1';
'1' 'valine' '1.056' '1.035' '0.001' '0.001' '1' '1' '1';
'1' 'isobutyrate_propionate' '1.064' '1.061' '0.0001' '0.001' '1' '1' '1';
'2' 'unk_d_methylsuccinate' '1.083' '1.066' '0.001' '0.002' '1' '1' '1';
'2' 'unk_d ' '1.118' '1.101' '0.001' '0.002' '1' '1' '1';
'1' 'propylene glycol' '1.145' '1.14' '0.0001' '0.001' '1' '1' '1';
'2' '3-hydroxybutyrate' '1.206' '1.19' '0.001' '0.003' '1' '1' '1';
'1' 'fucose' '1.221' '1.206' '0.001' '0.002' '1' '1' '1';
'1' 'methylmalonate' '1.244' '1.225' '0.0005' '0.003' '1' '1' '1';
'1' 'fucose' '1.2645' '1.244' '0.001' '0.0005' '1' '1' '1';
'1' 'lactate' '1.346' '1.327' '0.001' '0.001' '1' '1' '1';
'1' '2-hydroxyisobutyrate' '1.366' '1.357' '0.004' '0.002' '1' '1' '1';
'1' 'alanine' '1.498' '1.475' '0.001' '0.001' '1' '1' '1';
'1' 'lysine' '1.759' '1.703' '0.001' '0.001' '1' '1' '1';
'1' 'acetate' '1.929' '1.924' '0.003' '0.003' '1' '1' '1';
'2' 'unk_s' '1.994' '1.984' '0.001' '0.001' '1' '1' '1';
'3' 'Bin-N-acetyl-AA' '2.075' '2.036' '0.005' '0.002' '1' '1' '1';
'1' 'methionine' '2.146' '2.14' '0.0005' '0.0005' '1' '1' '1';
'1' 'hydroxyacetone' '2.163' '2.154' '0.001' '0.0001' '1' '1' '1';
'1' 'acetone' '2.178' '2.172' '0.002' '0.005' '1' '1' '1';
'1' 'acetoacetate' '2.191' '2.181' '0.002' '0.002' '1' '1' '1';
'2' 'unk_s' '2.244' '2.231' '0.001' '0.001' '1' '1' '1';
'1' 'thymol' '2.266' '2.256' '0.002' '0.002' '1' '1' '1';
'2' 'unk_m' '2.292' '2.268' '0.002' '0.001' '1' '1' '1';
'2' 'unk_s' '2.354' '2.339' '0.004' '0.002' '1' '1' '1';
'1' 'pyruvate' '2.383' '2.378' '0.0001' '0.001' '1' '1' '1';
'1' 'succinate' '2.414' '2.408' '0.002' '0.002' '1' '1' '1';
'3' 'Bin-glutamine-proline' '2.474' '2.433' '0.002' '0.002' '1' '1' '1';
'1' 'citrate' '2.57' '2.526' '0.002' '0.002' '1' '1' '1';
'1' 'citrate' '2.703' '2.657' '0.01' '0.01' '1' '1' '1';
'1' 'DMA' '2.73' '2.718' '0.01' '0.005' '1' '1' '1';
'2' 'unk_s-sarcosine' '2.788' '2.779' '0.002' '0.003' '1' '1' '1';
'1' 'TMA' '2.869' '2.862' '0.003' '0.003' '1' '1' '1';
'3' 'Bin-N-DMG' '2.935' '2.923' '0.001' '0.001' '1' '1' '1';
'1' 'asparagine' '2.953' '2.941' '0.001' '0.001' '1' '1' '1';
'1' 'Bin-creatine-creatinine' '3.063' '3.033' '0.01' '0.003' '1' '1' '1';
'1' 'cis-aconitate' '3.128' '3.122' '0.0001' '0.0001' '1' '1' '1';
'3' 'Bin-dimethylsulfone' '3.168' '3.158' '0.002' '0.002' '1' '1' '1';
'2' 'unk_s' '3.235' '3.218' '0.001' '0.001' '1' '1' '1';
'1' 'betaine' '3.27' '3.262' '0.001' '0.001' '1' '1' '1';
'1' 'TMAO' '3.281' '3.272' '0.003' '0.002' '1' '1' '1';
'2' 'unk_s' '3.363' '3.357' '0.001' '0.001' '1' '1' '1';
'1' 'methanol' '3.371' '3.365' '0.003' '0.002' '1' '1' '1';
'1' 'taurine' '3.449' '3.417' '0.001' '0.003' '1' '1' '1';
'3' 'Bin-cis-trans-sconitate' '3.462' '3.447' '0.001' '0.001' '1' '1' '1';
'2' 'unk_s' '3.527' '3.516' '0.001' '0.001' '1' '1' '1';
'1' 'glycine' '3.58' '3.563' '0.005' '0.001' '1' '1' '1';
'1' 'threonine' '3.59' '3.578' '0.001' '0.001' '1' '1' '1';
'1' 'pi-methylhistidine' '3.724' '3.717' '0.002' '0.002' '1' '1' '1';
'1' 'DMG' '3.73' '3.7235' '0.001' '0.0005' '1' '1' '1';
'3' 'bin-glutamine-fucose-alanine' '3.7965' '3.772' '0.0005' '0.003' '1' '1' '1';
'1' 'guanidoacetate' '3.803' '3.797' '0.002' '0.005' '1' '1' '1';
'1' 'ethanolamine' '3.847' '3.826' '0.002' '0.002' '1' '1' '1';
'1' 'serine' '3.866' '3.846' '0.001' '0.001' '1' '1' '1';
'1' 'aspartate' '3.901' '3.893' '0.001' '0.001' '1' '1' '1';
'1' 'betaine' '3.907' '3.902' '0.001' '0.001' '1' '1' '1';
'1' 'creatine' '3.94' '3.93' '0.001' '0.001' '1' '1' '1';
'1' 'creatine phosphate' '3.958' '3.951' '0.002' '0.002' '1' '1' '1';
'1' 'hippurate' '3.982' '3.963' '0.002' '0.001' '1' '1' '1';
'1' 'creatinine' '4.072' '4.049' '0.005' '0.001' '1' '1' '1';
'2' 'unk_d' '4.111' '4.097' '0.001' '0.001' '1' '1' '1';
'1' 'lactate' '4.134' '4.116' '0.001' '0.001' '1' '1' '1';
'2' 'unk_d-gluconate' '4.15' '4.138' '0.001' '0.001' '1' '1' '1';
'3' 'bin-threonine' '4.281' '4.245' '0.001' '0.001' '1' '1' '1';
'1' 'tartrate' '4.346' '4.34' '0.001' '0.001' '1' '1' '1';
'1' 'trigonelline' '4.447' '4.433' '0.005' '0.002' '1' '1' '1';
'1' '1-methylnicotinamide' '4.488' '4.477' '0.003' '0.003' '1' '1' '1';
'3' 'bin-ascorbate-arabinose' '4.529' '4.516' '0.001' '0.002' '1' '1' '1';
'1' 'fucose' '4.577' '4.555' '0.001' '0.001' '1' '1' '1';
'3' 'bin-glucose-glucose6P' '4.667' '4.641' '0.001' '0.001' '1' '1' '1';
'2' 'unk_d' '4.702' '4.68' '0.001' '0.001' '1' '1' '1';
'1' 'unk_d-ribose' '4.939' '4.922' '0.001' '0.001' '1' '1' '1';
'1' 'unk_m' '5.04' '5.002' '0.001' '0.001' '1' '1' '1';
'3' 'bin-glucose-glucose6P-anomerics' '5.27' '5.198' '0.002' '0.002' '1' '1' '1';
'1' 'allantoin' '5.402' '5.389' '0.001' '0.001' '1' '1' '1';
'1' 'sucrose' '5.476' '5.468' '0.001' '0.001' '1' '1' '1';
'2' 'unk_d' '5.628' '5.602' '0.001' '0.001' '1' '1' '1';
'3' 'bin-cis-aconitate' '5.735' '5.72' '0.03' '0.03' '1' '1' '1'; %it moves a ot
'3' 'bin-urea-uracil-xanthosine' '6.016' '5.735' '0.01' '0.001' '1' '1' '1';
'3' 'bin-cytidine' '6.08' '6.061' '0.0005' '0.001' '1' '1' '1';
'1' 'trans-ferulate' '6.421' '6.379' '0.001' '0.001' '1' '1' '1';
'1' 'fumarate' '6.528' '6.521' '0.001' '0.001' '1' '1' '1';
'1' 'cis-trans-aconitate' '6.601' '6.59' '0.001' '0.001' '1' '1' '1';
'2' 'unk_d' '6.681' '6.654' '0.001' '0.001' '1' '1' '1';
'1' '4-hydroxyphenylacetate' '6.881' '6.851' '0.001' '0.001' '1' '1' '1';
'1' 'tyrosine' '6.914' '6.891' '0.001' '0.001' '1' '1' '1';
'3' 'bin-trans-ferulate' '6.958' '6.934' '0.001' '0.001' '1' '1' '1';
'1' '1-methylhistidine' '7.058' '7.045' '0.001' '0.001' '1' '1' '1';
'1' 'histidine' '7.147' '7.132' '0.001' '0.001' '1' '1' '1';
'1' 'histamine' '7.167' '7.154' '0.001' '0.001' '1' '1' '1';
'1' '4-hydroxyphenylacetate' '7.178' '7.169' '0.001' '0.001' '1' '1' '1';
'3' 'bin-tyrosine' '7.208' '7.182' '0.001' '0.001' '1' '1' '1';
'2' 'unk_part_of_d' '7.226' '7.209' '0.001' '0.001' '1' '1' '1';
'3' 'bin-tryptophan' '7.296' '7.26' '0.001' '0.001' '1' '1' '1';
'3' 'bin-tryptophan-phenylalanine' '7.335' '7.323' '0.001' '0.001' '1' '1' '1';
'1' 'phenylalanine' '7.344' '7.335' '0.001' '0.001' '1' '1' '1';
'3' 'bin-N-phenylacetylglycine-phenyalanine-3-indoxylsulfate' '7.356' '7.345' '0.001' '0.001' '1' '1' '1';
'1' 'N-phenylacetylglycine' '7.385' '7.358' '0.001' '0.001' '1' '1' '1';
'1' 'phenylalanine' '7.401' '7.386' '0.001' '0.001' '1' '1' '1';
'1' 'N-phenylacetylglycine' '7.446' '7.409' '0.001' '0.001' '1' '1' '1';
'1' '3-indoxylsulfate' '7.521' '7.497' '0.001' '0.001' '1' '1' '1';
'1' 'tryptophan' '7.538' '7.529' '0.001' '0.001' '1' '1' '1';
'1' 'hippurate' '7.582' '7.539' '0.002' '0.001' '1' '1' '1';
'1' 'hippurate' '7.663' '7.618' '0.002' '0.001' '1' '1' '1';
'1' 'unk_d' '7.686' '7.676' '0.001' '0.001' '1' '1' '1';
'1' '3-indoxylsulfate' '7.717' '7.689' '0.001' '0.001' '1' '1' '1';
'1' '1-methylhistidine' '7.798' '7.784' '0.001' '0.001' '1' '1' '1';
'1' 'hippurate' '7.856' '7.818' '0.003' '0.002' '1' '1' '1';
'1' 'histidine' '8.011' '7.992' '0.002' '0.002' '1' '1' '1';
'1' 'trigonelline' '8.106' '8.072' '0.001' '0.001' '1' '1' '1';
'1' 'histamine' '8.139' '8.115' '0.002' '0.002' '1' '1' '1';
'1' 'formate' '8.469' '8.457' '0.005' '0.002' '1' '1' '1';
'2' 'unk-d-nicotinic-acid-adenine-dinucleotide' '8.802' '8.771' '0.005' '0.002' '1' '1' '1';
'1' 'trigonelline' '8.862' '8.82' '0.005' '0.002' '1' '1' '1';
'1' '1-methylnicotinamide' '8.915' '8.888' '0.002' '0.002' '1' '1' '1';
'1' '1-methylnicotinamide' '8.981' '8.956' '0.002' '0.002' '1' '1' '1';
'1' 'trigonelline' '9.135' '9.115' '0.005' '0.002' '1' '1' '1';
'1' 'ERETIC-10mM-Proton' '12.05' '11.95' '0.0001' '0.0001' '1' '1' '1'}; 

options.intervals_class=str2num(cell2str(intervals(:,1)));
options.intervals_name=intervals(:,2);
options.intervals_ppm=cat(2,str2num(cell2str(intervals(:,3))),str2num(cell2str(intervals(:,4))));
options.intervals_ppm_flex=cat(2,str2num(cell2str(intervals(:,5))),str2num(cell2str(intervals(:,6))));
options.intervals_SS_and_total_1H=cat(2,str2num(cell2str(intervals(:,7))),str2num(cell2str(intervals(:,8)))); % e.g. for Alanine 7=# of 1H in SS & 8=# of 1H in a molecular
options.intervals_Interative_Align=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning Align
options.intervals_MCR_Components=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning 1 component MCR model
options.intervals_consistant_occasional=str2num(cell2str(intervals(:,9))); % 9 = 1 means consistently occuring mets & 2 means occasionally occuring mets

% Take only included variables for Quantification
options.VariablesIncluded=ones(size(options.intervals_class,1),1);


%% Option2 
% Which classes of variables should be processed
% [1] = knowns 
% [2] = unknowns 
% [3] = bins

options.VariableClass=[1:3];

%% Option 3
% Should Baseline be removed 
% Yes ( =1 ) or Not ( = 0 default)

options.BaseLineRemove= [0];  

%% Option 4 
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "

options.BaseLineProportion = 20;

%% Option 5 
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 

options.cutoff=3;

%% Option 6
% Reference Alignment 
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.05 -0.05];

% 0 = no refAlignment, 1 = refAlignment and continue, 2 = refAlignment and stop 
options.refAlignment.status=0;  

% Reference Alignemnt Region
options.refAlignment.region=[0.25 -0.25];

% Target vector used for global icoshift
options.refAlignment.target= 'average';

% definition of alignment mode
options.refAlignment.inter=[];

% icoshift Optional Inpuits - read "help icoshift3"
options.refAlignment.icoshiftOptions=[0 1 0 50 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.print=1; 

%% Option 7 
%  Get preAlignment seetings for a global icoshift. Please type "help icoshift3"

% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment and stop and return preAlignedData 
options.preAlignment.status=0;  

% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc.


options.preAlignment.regions = [2.19 1.894; 2.33 2.19; 2.53 2.33; 2.63 2.558; 2.835 2.63; 3.08 2.835; 3.181 3.118;
    3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
   3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
    0.9981 0.9515; 1.046 1.0175; 1.0175 0.9981; 1.079 1.046; 1.12 1.079; 1.231 1.17; 1.367 1.335;
    1.518 1.479; 1.947 1.85; 2.12 1.947; 2.19 2.12; 2.289 2.21; 2.358 2.289; 2.383 2.358; 2.401 2.383; 2.497 2.443;
    2.559 2.539; 2.63 2.558; 2.678 2.63; 2.835 2.678; 2.9565 2.835; 3 2.9565; 3.07 3.00; 3.181 3.118;
    3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
   3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
   0.9977 0.9335; 0.997 0.962; 1.042 0.997; 1.041 1.018; 1.074 1.047; 
    1.24 1.18; 1.375 1.332; 1.515 1.483; 1.945 1.929; 2.105 1.945; 2.19 2.105; 2.401 2.381 ; 
   2.5 2.437; 2.56 2.537; 2.6 2.565; 2.695 2.655; 2.82 2.731; 2.96 2.84; 3.055 3.011; 
   3.07 3.055; 3.082 3.07; 3.118 3.082; 3.355 3.331; 3.377 3.355; 3.39 3.377; 3.586 3.558; 3.61 3.586;
   3.776 3.767; 3.797 3.776; 3.818 3.797; 3.974 3.951; 4.033 3.974; 4.106 4.06; 5.268 5.24];

% options.preAlignment.regions = [2.19 2.105];


% Target vector used for global icoshift
options.preAlignment.target= 'average';

% definition of alignment mode
options.preAlignment.inter=[];

% max_ppm_allowed_shift
options.preAlignment.max_allowed_ppm_shift=0.01; 

% icoshift Optional Inpuits - read "help icoshift3"
options.preAlignment.icoshiftOptions=[0 1 0 options.preAlignment.max_allowed_ppm_shift 1 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.print=1; 

%% Option 8
%   Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"

% 0 = No intervalAlignment before quantification, 1 = Do intervalAlignment before quantification
options.intervalAlignment.status=1;  

% Target vector used for global icoshift
options.intervalAlignment.target = 'average';

% definition of alignment mode
options.intervalAlignment.inter=[];

% max_ppm_allowed_shift
options.intervalAlignment.max_allowed_ppm_shift=0.005; %max_ppm_allowed_shift

% icoshift Optional Inpuits - read "help icoshift3"
options.intervalAlignment.icoshiftOptions=[0 1 0 options.intervalAlignment.max_allowed_ppm_shift 1 1];

% Plot intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.plot=1; 

% Print intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.print=1; 


%% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  only the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0

options.should_left_out_ppm_regions_be_included.status=0; % default must be 1 (0= No)
options.should_left_out_ppm_regions_be_included.min_ppm=0.01; % (in ppm)

%% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3


options.automatic_interval_selection.status=0;
options.automatic_interval_selection.mode=2;
options.automatic_interval_selection.std_value=0.00015; % we need to explain this in help
options.automatic_interval_selection.peak_width=0.005; % we need to explain this in help
options.automatic_interval_selection.space_between_two_intervals=0.0005; % we need to explain this in help
options.automatic_interval_selection.continue_until_next_minimum=0; % we need to explain this in help
options.automatic_interval_selection.handles=[]; % we need to explain

%% Option 11
% 11 Color Options of Plots

options.Colors.red_transparent=[1 0.2 0.2, 0.2];
options.Colors.red=[1 0.2 0.2];
options.Colors.blue_transparent=[0.2 0.2 1, 0.2];
options.Colors.blue=[0.2 0.2 1];
options.Colors.green_transparent=[0.2 1 0.2, 0.2];
options.Colors.green=[0.2 1 0.2];
options.Colors.blueish_transparent=[0 0.4470 0.7410, 0.2];
options.Colors.brownish_transparent=[0.8500 0.3250 0.0980, 0.2];
options.Colors.yellowish=[0.9290 0.6940 0.1250, 0.2];
options.Colors.magendaish_transparent=[0.4940 0.1840 0.5560, 0.2];
options.Colors.greenish_transparent=[0.4660 0.6740 0.1880, 0.2];
options.Colors.light_blueish_transparent=[0.3010 0.7450 0.9330, 0.2];
options.Colors.redish_transparent=[0.6350 0.0780 0.1840, 0.2];
options.Colors.greyish_transparent=[0.25 0.25 0.25, 0.2];




end
