function [ options ] = sigma_plasma_options1
%
%
% options for "sigma_sample_options" function
% to see how default "options" look run  [ options ] = sigma_urine_options;
% 
% Note: user can enter the option they wish & rest will be set to default parameters
%
%
% Option 1
% intervals = {'1','TSP','0.075','-0.075','0.001','0.001','9','1','1';...etc.};
% Nine inputs, 1=class, 2=name, 3=start ppm, 4=end ppm, 5=flex ppm right,
% 6=flex ppm left, 7= total Hs, 8= SS Hs, 9=(consistant=1, occasuanal=2)
%
% Option 2
% Get VariableClass
% It can only be 1-to-3
% 1 = knowns
% 2 = unknowns
% 3 = bins (this includes (optionally) user defined, automatically selected, and any other region left out as bins)
%
%
% Option 3
% Get BaseLineRemove
% No=0 & Yes=1. 
% default : options.BaseLineRemove= [0];  
%
% Option 4
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "
% default : options.BaseLineProportion = 20;
%
% Option 5
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 
% default : options.cutoff=3;
%
% Option 6
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.3 -0.3];
%
%
% Option 7
% Get preAlignment seetings for a global icoshift. Please type "help icoshift3"
% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment ans stop and return preAlignedData  
% default : options.preAlignment.status=[0];  
% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc. This optional input can also be left out.
% options.preAlignment.regions = [9 0.2];  means only do preAlignment of 9-0.2 ppm
% Target vector used for global icoshift
% default : options.preAlignment.target= 'average';
% definition of alignment mode
% default : options.preAlignment.inter='whole';
% shift allowed (optional)
% default : options.preAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.preAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 8
% Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"
% Target vector used for global icoshift
% default : options.intervalAlignment.target = 'average';
% shift allowed (optional)
% default : options.intervalAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.intervalAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  ionlt the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0
% default : options.wholeSpectra=1;
%
% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3
%
% Option 11
% Color Styles
%
%
% BKH, 17.02.2020

%% Option 0
load('plasma_ref.mat');
load('plasma_ref_ppm.mat');
options.ref_spect=plasma_ref;
options.ref_spect_ppm=plasma_ref_ppm;

%% Option 1

intervals={'1','TSP','0.075','-0.075','0.001','0.001','9','9','1';
   '1','cholesterol','0.75','0.6611','0.001','0.001','3','45','1'; ...
   '1','LP (CH3)','0.9248','0.8','0.001','0.001','3','1','1';
   '3','bin (isovalerate+2hydroxybutyric acid)','0.9389','0.8931','0.001','0.001','NaN','NaN','1';
   '1','isoleucine 1','0.9595','0.9389','0.001','0.001','2.25','9','1';
   '1','leucine','0.994','0.9736','0.001','0.001','4.5','10','1';'3','bin (2aminobutyric acid+valine)','1.0173','0.9946','0.001','0.001','NaN','NaN','1';'1','isoleucine 2','1.037','1.0169','0.001','0.001','3','9','1';
   '1','valine 1','1.071','1.0462','0.001','0.001','3','8','1';'1','isobutyric acid','1.11','1.073','0.001','0.001','6','7','1';'1','LP (CH2)','1.338','1.217','0.001','0.001','2','1','1';
   '1','lactate 1','1.3614','1.3371','0.001','0.001','3','4','1';
   '1','alanine','1.5103','1.4824','0.001','0.001','3','4','1';'1','LP (CH2CCO) 1','1.65','1.5103','0.001','0.001','2','1','1';'3','bin (LP (CCH2C=C)+cadaverine+arginine+spermidine+spermine+2hydroxybutyric acid+lysine)','1.783','1.593','0.001','0.001','NaN','NaN','1';'3','bin (lysine+arginine+spermine+spermidine+2aminobutyric_acid)','1.963','1.783','0.001','0.001','NaN','NaN','1';'1','acetate','1.939','1.932','0.001','0.001','3','3','1';'3','bin (LP (CCH2C=C)+isovaleric acid+proline)','2.0444','1.97','0.001','0.001','NaN','NaN','1';'3','bin (glycoprotein (NHCOCH3)+glutamic acid+proline)','2.072','2.046','0.001','0.001','NaN','NaN','1';'3','bin (isovaleric acid+glutamic acid+proline)','2.12','2.0739','0.001','0.001','NaN','NaN','1';'3','bin (paracetamol+methionine+glutamic acid+glutamine)','2.197','2.1216','0.001','0.001','NaN','NaN','1';'3','bin (LP (CH2CO)+acetone)','2.276','2.22','0.001','0.001','2','1','1';'1','acetone','2.2514','2.2431','0.001','0.001','6','6','1';'3','bin (Proline+Glutamine+pyruvic acid)','2.411','2.323','0.001','0.001','NaN','NaN','1';'1','pyruvic acid','2.3925','2.386','0.001','0.001','3','3','1';'3','bin (glutamine+Isobutyric acid+carnitine)','2.522','2.411','0.001','0.001','NaN','NaN','1';'1','citric acid','2.5557','2.5327','0.001','0.001','0.8235','4','1';'1','methionine','2.6602','2.6435','0.001','0.001','0.5','8','1';'3','bin (aspartic acid+citric acid)','2.712','2.652','0.001','0.001','NaN','NaN','1';'1','LP (C=CCH2C=C)','2.84','2.74','0.001','0.001','2','1','1';'1','aspartic acid','2.829','2.801','0.001','0.001','0.62','5','1';'3','bin (aspartic acid+asparagine)','2.876','2.84','0.001','0.001','NaN','NaN','1';'3','bin (dimethylglycine+tyramine+asparagine)','2.956','2.908','0.001','0.001','NaN','NaN','1';'1','asparagine','2.979','2.967','0.001','0.001','0.5','3','1';'3','bin (lysine+creatinine+creatine+creatineP+tyrosine+cysteine)','3.081','3.034','0.001','0.001','NaN','NaN','1';'3','bin (1-methylhistidine+cystine)','3.208','3.168','0.001','0.001','NaN','NaN','1';'3','bin (tyramine+carnitine+histidine)','3.248','3.234','0.001','0.001','NaN','NaN','1';'3','bin (histidine+arginine+glucose+taurine+betaine)','3.285','3.248','0.001','0.001','NaN','NaN','1';'3','bin (cystine+proline+methanol+glutamate)','3.376','3.358','0.001','0.001','NaN','NaN','1';'1','cystine','3.395','3.384','0.001','0.001','1','6','1';'3','bin (taurine+carnitine+glucose+proline+glutamic acid)','3.466','3.408','0.001','0.001','NaN','NaN','1';'3','bin (tryptophan+glucose+choline)','3.542','3.472','0.001','0.001','NaN','NaN','1';'1','glucose 1','3.5729','3.544','0.001','0.001','0.5','7','1';'1','glycine','3.5839','3.5732','0.001','0.001','2','2','1';'1','threonine 1','3.597','3.585','0.001','0.001','1','5','1';'3','bin (isoleucine+ethanol)','3.693','3.648','0.001','0.001','NaN','NaN','1';'3','bin (glucose+dimethylglycine+2aminobutyric acid+glutamic acid+lysine+arginine+glutamine+alanine)','3.824','3.718','0.001','0.001','NaN','NaN','1';'3','bin (serine+glucose)','3.882','3.842','0.001','0.001','NaN','NaN','1';'3','bin (betaine+tyrosine+glucose+aspartic acid+cysteine)','3.941','3.899','0.001','0.001','NaN','NaN','1';'3','bin (creatine+creatineP+serine)','3.966','3.94','0.001','0.001','NaN','NaN','1';'3','bin (serine+asparagine+histidine+hippuric acid)','4.023','3.967','0.001','0.001','NaN','NaN','1';'3','bin (cystine+creatinine+typtophan+sucrose+choline)','4.1','4.045','0.001','0.001','NaN','NaN','1';'1','lactate 2','4.1297','4.11','0.001','0.001','0.5','4','1';'3','bin (lactate+proline)','4.164','4.1303','0.001','0.001','NaN','NaN','1';'3','bin (LP (CH2OCOR)+threonine)','4.35','4.24','0.001','0.001','NaN','NaN','1';'1','LP (CHOCOR)','5.2385','5.1489','0.001','0.001','1','1','1';'1','glucose 2','5.2644','5.247','0.001','0.001','0.5','7','1';'1','LP (CH of unsaturated lipids)','5.382','5.2644','0.001','0.001','1','1','1';'3','bin (paracetamol+tyrosine+tyramine)','6.93','6.885','0.001','0.001','NaN','NaN','1';'1','histidine 2','7.0907','7.0607','0.001','0.001','1','5','1';'3','bin (tyramine+tyrosine+tryptophan)','7.228','7.183','0.001','0.001','NaN','NaN','1';'3','bin (paracetamol+tryptophan)','7.307','7.241','0.001','0.001','NaN','NaN','1';'3','bin (tryptophan+phenylalanine)','7.36','7.33','0.001','0.001','NaN','NaN','1';'1','phenylalanine 1','7.407','7.372','0.001','0.001','1','8','1';'1','phenylalanine 2','7.463','7.429','0.001','0.001','2','8','1';'3','bin (tryptophan+hippuric acid)','7.572','7.525','0.001','0.001','NaN','NaN','1';'3','bin (1-methylhistidine+hippuric acid)','7.651','7.605','0.001','0.001','NaN','NaN','1';'1','histidine 3','7.8113','7.7797','0.02','0.02','1','5','1';'3','hippuric acid','7.896','7.8127','0.003','0.003','2','7','1';'1','formate','8.4826','8.473','0.001','0.001','1','1','1';
   '1','ERETIC','15.05','14.95','0.001','0.001','1','1','1'};



options.intervals_class=str2num(cell2str(intervals(:,1)));
options.intervals_name=intervals(:,2);
options.intervals_ppm=cat(2,str2num(cell2str(intervals(:,3))),str2num(cell2str(intervals(:,4))));
options.intervals_ppm_flex=cat(2,str2num(cell2str(intervals(:,5))),str2num(cell2str(intervals(:,6))));
options.intervals_SS_and_total_1H=cat(2,str2num(cell2str(intervals(:,7))),str2num(cell2str(intervals(:,8)))); % e.g. for Alanine 7=# of 1H in SS & 8=# of 1H in a molecular
options.intervals_Interative_Align=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning Align
options.intervals_MCR_Components=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning 1 component MCR model
options.intervals_consistant_occasional=str2num(cell2str(intervals(:,9))); % 9 = 1 means consistently occuring mets & 2 means occasionally occuring mets

% Take only included variables for Quantification
options.VariablesIncluded=ones(size(options.intervals_class,1),1);


%% Option2 
% Which classes of variables should be processed
% [1] = knowns 
% [2] = unknowns 
% [3] = bins

options.VariableClass=[1:3];

%% Option 3
% Should Baseline be removed 
% Yes ( =1 ) or Not ( = 0 default)

options.BaseLineRemove= [1];  

%% Option 4 
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "

options.BaseLineProportion = 20;

%% Option 5 
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 

options.cutoff=3;

%% Option 6
% Reference Alignment 
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.05 -0.05];

% 0 = no refAlignment, 1 = refAlignment and continue, 2 = refAlignment and stop 
options.refAlignment.status=0;  

% Reference Alignemnt Region
options.refAlignment.region=[0.25 -0.25];

% Target vector used for global icoshift
options.refAlignment.target= 'average';

% definition of alignment mode
options.refAlignment.inter=[];

% icoshift Optional Inpuits - read "help icoshift3"
options.refAlignment.icoshiftOptions=[0 1 0 50 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.print=1; 

%% Option 7 
%  Get preAlignment seetings for a global icoshift. Please type "help icoshift3"

% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment and stop and return preAlignedData 
options.preAlignment.status=0;  

% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc.


% options.preAlignment.regions = [2.19 1.894; 2.33 2.19; 2.53 2.33; 2.63 2.558; 2.835 2.63; 3.08 2.835; 3.181 3.118;
%     3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
%    3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
%     0.9981 0.9515; 1.046 1.0175; 1.0175 0.9981; 1.079 1.046; 1.12 1.079; 1.231 1.17; 1.367 1.335;
%     1.518 1.479; 1.947 1.85; 2.12 1.947; 2.19 2.12; 2.289 2.21; 2.358 2.289; 2.383 2.358; 2.401 2.383; 2.497 2.443;
%     2.559 2.539; 2.63 2.558; 2.678 2.63; 2.835 2.678; 2.9565 2.835; 3 2.9565; 3.07 3.00; 3.181 3.118;
%     3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
%    3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
%    0.9977 0.9335; 0.997 0.962; 1.042 0.997; 1.041 1.018; 1.074 1.047; 
%     1.24 1.18; 1.375 1.332; 1.515 1.483; 1.945 1.929; 2.105 1.945; 2.19 2.105; 2.401 2.381 ; 
%    2.5 2.437; 2.56 2.537; 2.6 2.565; 2.695 2.655; 2.82 2.731; 2.96 2.84; 3.055 3.011; 
%    3.07 3.055; 3.082 3.07; 3.118 3.082; 3.355 3.331; 3.377 3.355; 3.39 3.377; 3.586 3.558; 3.61 3.586;
%    3.776 3.767; 3.797 3.776; 3.818 3.797; 3.974 3.951; 4.033 3.974; 4.106 4.06; 5.268 5.24];

options.preAlignment.regions = [2.19 2.105];



% Target vector used for global icoshift
options.preAlignment.target= 'average';

% definition of alignment mode
options.preAlignment.inter=[];

% max_ppm_allowed_shift
options.preAlignment.max_allowed_ppm_shift=0.01; 

% icoshift Optional Inpuits - read "help icoshift3"
options.preAlignment.icoshiftOptions=[0 1 0 options.preAlignment.max_allowed_ppm_shift 1 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.print=1; 

%% Option 8
%   Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"

% 0 = No intervalAlignment before quantification, 1 = Do intervalAlignment before quantification
options.intervalAlignment.status=1;  

% Target vector used for global icoshift
options.intervalAlignment.target = 'average';

% definition of alignment mode
options.intervalAlignment.inter=[];

% max_ppm_allowed_shift
options.intervalAlignment.max_allowed_ppm_shift=0.005; %max_ppm_allowed_shift

% icoshift Optional Inpuits - read "help icoshift3"
options.intervalAlignment.icoshiftOptions=[0 1 0 options.intervalAlignment.max_allowed_ppm_shift 1 1];

% Plot intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.plot=1; 

% Print intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.print=1; 


%% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  only the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0

options.should_left_out_ppm_regions_be_included.status=0; % default must be 1 (0= No)
options.should_left_out_ppm_regions_be_included.min_ppm=0.01; % (in ppm)

%% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3


options.automatic_interval_selection.status=0;
options.automatic_interval_selection.mode=2;
options.automatic_interval_selection.std_value=0.00015; % we need to explain this in help
options.automatic_interval_selection.peak_width=0.005; % we need to explain this in help
options.automatic_interval_selection.space_between_two_intervals=0.0005; % we need to explain this in help
options.automatic_interval_selection.continue_until_next_minimum=0; % we need to explain this in help
options.automatic_interval_selection.handles=[]; % we need to explain

%% Option 11
% 11 Color Options of Plots

options.Colors.red_transparent=[1 0.2 0.2, 0.2];
options.Colors.red=[1 0.2 0.2];
options.Colors.blue_transparent=[0.2 0.2 1, 0.2];
options.Colors.blue=[0.2 0.2 1];
options.Colors.green_transparent=[0.2 1 0.2, 0.2];
options.Colors.green=[0.2 1 0.2];
options.Colors.blueish_transparent=[0 0.4470 0.7410, 0.2];
options.Colors.brownish_transparent=[0.8500 0.3250 0.0980, 0.2];
options.Colors.yellowish=[0.9290 0.6940 0.1250, 0.2];
options.Colors.magendaish_transparent=[0.4940 0.1840 0.5560, 0.2];
options.Colors.greenish_transparent=[0.4660 0.6740 0.1880, 0.2];
options.Colors.light_blueish_transparent=[0.3010 0.7450 0.9330, 0.2];
options.Colors.redish_transparent=[0.6350 0.0780 0.1840, 0.2];
options.Colors.greyish_transparent=[0.25 0.25 0.25, 0.2];




end
