function [ options ] = sigma_plasma_options1
%
%
% options for "sigma_sample_options" function
% to see how default "options" look run  [ options ] = sigma_urine_options;
% 
% Note: user can enter the option they wish & rest will be set to default parameters
%
%
% Option 1
% intervals = {'1','TSP','0.075','-0.075','0.001','0.001','9','1','1';...etc.};
% Nine inputs, 1=class, 2=name, 3=start ppm, 4=end ppm, 5=flex ppm right,
% 6=flex ppm left, 7= total Hs, 8= SS Hs, 9=(consistant=1, occasuanal=2)
%
% Option 2
% Get VariableClass
% It can only be 1-to-3
% 1 = knowns
% 2 = unknowns
% 3 = bins (this includes (optionally) user defined, automatically selected, and any other region left out as bins)
%
%
% Option 3
% Get BaseLineRemove
% No=0 & Yes=1. 
% default : options.BaseLineRemove= [0];  
%
% Option 4
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "
% default : options.BaseLineProportion = 20;
%
% Option 5
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 
% default : options.cutoff=3;
%
% Option 6
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.3 -0.3];
%
%
% Option 7
% Get preAlignment seetings for a global icoshift. Please type "help icoshift3"
% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment ans stop and return preAlignedData  
% default : options.preAlignment.status=[0];  
% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc. This optional input can also be left out.
% options.preAlignment.regions = [9 0.2];  means only do preAlignment of 9-0.2 ppm
% Target vector used for global icoshift
% default : options.preAlignment.target= 'average';
% definition of alignment mode
% default : options.preAlignment.inter='whole';
% shift allowed (optional)
% default : options.preAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.preAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 8
% Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"
% Target vector used for global icoshift
% default : options.intervalAlignment.target = 'average';
% shift allowed (optional)
% default : options.intervalAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.intervalAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  ionlt the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0
% default : options.wholeSpectra=1;
%
% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3
%
% Option 11
% Color Styles
%
%
% BKH, 17.02.2020

%% Option 0
load('fecal_ref.mat');
load('fecal_ref_ppm.mat');
options.ref_spect=fecal_ref;
options.ref_spect_ppm=fecal_ref_ppm;

%% Option 1

intervals={'2' 'unk30_d' '0.8023' '0.7849' '0.0003' '0.0009' '1' '1' '1';
    '2' 'unk1_d' '0.8463' '0.8303' '0.0008' '0.0002' '1' '1' '1';
    '2' 'unk2_s_of_d' '0.8511' '0.8468' '0.0007' '0.0003' '1' '1' '1';
    '2' 'unk3_s' '0.8631' '0.8592' '0.0003' '0.0003' '1' '1' '1';
    '2' 'unk4_s_of_d' '0.869' '0.863' '0.002' '0.002' '1' '1' '1';
    '2' 'unk5_s' '0.875' '0.8722' '0.001' '0.001' '1' '1' '1';
    '2' 'unk6_s' '0.8792' '0.8766' '0.001' '0.001' '1' '1' '1';
    '1' 'valerate1' '0.8821' '0.8787' '0.0004' '0.0003' '1' '1' '1';
    '1' 'butyrate1' '0.8888' '0.8844' '0.0044' '0.0003' '1' '1' '1';
    '1' 'valerate2' '0.8943' '0.8905' '0.0009' '0.0009' '1' '1' '1'; 
    '1' 'butyrate2' '0.9013' '0.8963' '0.0013' '0.0055' '1' '1' '1'; 
    '1' 'valerate3' '0.9062' '0.9033' '0.0001' '0.0005' '1' '1' '1';
    '1' 'isovalerate' '0.9096' '0.9066' '0.0047' '0.0019' '1' '1' '1';
    '1' 'butyrate3' '0.912' '0.909' '0.002' '0.002' '1' '1' '1'; 
    '1' 'isovalerate_and_else' '0.9218' '0.9177' '0.0018' '0.0032' '1' '1' '1'; 
    '1' 'isoleucine1' '0.9313' '0.9273' '0.002' '0.004' '1' '1' '1';
    '3' 'bin2' '0.9392' '0.9319' '0.001' '0.001' '1' '1' '1';
    '1' 'isoleucine2' '0.944' '0.9395' '0.003' '0.0032' '1' '1' '1';
    '2' 'unk8_s' '0.9481' '0.9445' '0.001' '0.001' '1' '1' '1';
    '1' 'leucine' '0.9793' '0.950' '0.002' '0.003' '1' '1' '1';
    '2' 'unk91_s' '0.9843' '0.981' '0.001' '0.001' '1' '1' '1';
    '1' 'valine1' '1.002' '0.984' '0.003' '0.004' '1' '1' '1';
    '1' 'isoleucine3' '1.021' '1.003' '0.002' '0.002' '1' '1' '1';
    '1' 'valine2' '1.0415' '1.035' '0.0005' '0.005' '1' '1' '1';
    '1' 'propionate1' '1.049' '1.045' '0.003' '0.004' '1' '1' '1';
    '1' 'valine3' '1.053' '1.049' '0.001' '0.0001' '1' '1' '1';
    '1' 'isobutyrate_propionate' '1.076' '1.055' '0.004' '0.002' '1' '1' '1';
    '2' 'unk9_s' '1.111' '1.083' '0.002' '0.002' '1' '1' '1';
    '2' 'unk10_s' '1.136' '1.12' '0.001' '0.001' '1' '1' '1';
    '3' 'bin_propylene_glycol' '1.144' '1.138' '0.001' '0.001' '1' '1' '1';
    '2' 'unk_s' '1.155' '1.148' '0.002' '0.001' '1' '1' '1';
    '1' 'ethanol' '1.202' '1.174' '0.002' '0.003' '1' '1' '1';
    '3' 'bin4' '1.258' '1.244' '0.001' '0.001' '1' '1' '1';
    '3' 'bin_valerate_isoleucine' '1.292' '1.284' '0.001' '0.001' '1' '1' '1';
    '3' 'bin_valerate4' '1.314' '1.296' '0.001' '0.002' '1' '1' '1';
    '1' 'lactate' '1.345' '1.323' '0.003' '0.003' '1' '1' '1'; 
    '3' 'bin6' '1.39' '1.374' '0.001' '0.001' '1' '1' '1';
    '2' 'unk15_d' '1.455' '1.451' '0.002' '0.001' '1' '1' '1';
    '2' 'unk16_s' '1.467' '1.46' '0.002' '0.002' '1' '1' '1';
    '1' 'alanine1' '1.494' '1.472' '0.008' '0.003' '1' '1' '1';
    '2' 'unk17_d' '1.519' '1.515' '0.002' '0.001' '1' '1' '1';
    '1' 'butyrate4' '1.595' '1.531' '0.005' '0.0002' '1' '1' '1';
    '3' 'bin_leucine_lysine' '1.761' '1.682' '0.002' '0.002' '1' '1' '1'; 
    '3' 'bin9' '1.795' '1.789' '0.002' '0.002' '1' '1' '1';
    '2' 'unk18_s' '1.818' '1.8145' '0.001' '0.001' '1' '1' '1';
    '3' 'bin10' '1.84' '1.835' '0.002' '0.001' '1' '1' '1';
    '2' 'unk19_s' '1.872' '1.866' '0.002' '0.002' '1' '1' '1';
    '3' 'bin11' '1.913' '1.903' '0.003' '0.001' '1' '1' '1';
    '1' 'acetate' '1.928' '1.919' '0.006' '0.005' '1' '1' '1';
    '3' 'bin_isoleucine5' '2.019' '1.998' '0.002' '0.001' '1' '1' '1';
    '2' 'unk93_d' '2.043' '2.024' '0.001' '0.003' '1' '1' '1';
    '3' 'bin_glutamate' '2.069' '2.049' '0.003' '0.004' '1' '1' '1';
    '1' 'glutamate' '2.093' '2.074' '0.001' '0.001' '1' '1' '1';
    '2' 'unk21_d' '2.11' '2.101' '0.001' '0.001' '1' '1' '1';
    '2' 'unk22_s' '2.117' '2.114' '0.001' '0.002' '1' '1' '1';
    '2' 'unk23_s' '2.123' '2.117' '0.001' '0.001' '1' '1' '1';
    '2' 'unk24_s' '2.13' '2.1262' '0.001' '0.002' '1' '1' '1';
    '2' 'unk25_s' '2.135' '2.13' '0.001' '0.001' '1' '1' '1';
    '1' 'methionine1' '2.144' '2.139' '0.003' '0.004' '1' '1' '1';
    '1' 'butyrate5' '2.152' '2.1468' '0.003' '0.0028' '1' '1' '1'; 
    '1' 'butyrate6' '2.165' '2.158' '0.001' '0.004' '1' '1' '1'; 
    '1' 'propionate2' '2.169' '2.165' '0.001' '0.0001' '1' '1' '1';
    '1' 'butyrate7' '2.176' '2.171' '0.002' '0.002' '1' '1' '1';
    '1' 'propionate3' '2.1825' '2.178' '0.002' '0.002' '1' '1' '1';
    '2' 'unk26_s' '2.187' '2.184' '0.0001' '0.0001' '1' '1' '1';
    '1' 'valerate5' '2.195' '2.190' '0.001' '0.004' '1' '1' '1';
    '2' 'unk29_s' '2.2' '2.195' '0.001' '0.001' '1' '1' '1';
    '1' 'propionate5' '2.208' '2.203' '0.003' '0.001' '1' '1' '1';
    '1' 'acetone' '2.24' '2.234' '0.001' '0.002' '1' '1' '1';
    '2' 'unk31_s' '2.251' '2.248' '0.0001' '0.001' '1' '1' '1';
    '3' 'bin17' '2.276' '2.259' '0.002' '0.001' '1' '1' '1';
    '2' 'unk32_d' '2.287' '2.274' '0.002' '0.003' '1' '1' '1';
    '3' 'bin18' '2.311' '2.29' '0.001' '0.001' '1' '1' '1';
    '1' 'glutamate' '2.378' '2.34' '0.004' '0.001' '1' '1' '1';
    '1' 'pyruvate' '2.412' '2.406' '0.006' '0.004' '1' '1' '1';
    '3' 'bin_glutamine' '2.491' '2.439' '0.002' '0.001' '1' '1' '1'; 
    '2' 'unk34_s' '2.523' '2.518' '0.002' '0.001' '1' '1' '1';
    '2' 'unk35_s' '2.589' '2.586' '0.001' '0.001' '1' '1' '1';
    '2' 'unk36_s' '2.611' '2.607' '0.002' '0.003' '1' '1' '1';
    '2' 'unk37_s' '2.616' '2.613' '0.001' '0.001' '1' '1' '1';
    '2' 'unk38_s' '2.622' '2.618' '0.002' '0.001' '1' '1' '1';
    '1' 'methionine2' '2.652' '2.63' '0.003' '0.004' '1' '1' '1';
    '1' 'aspartate2' '2.6615' '2.6565' '0.001' '0.003' '1' '1' '1'; 
    '1' 'malate3' '2.671' '2.661' '0.0002' '0.0002' '1' '1' '1';
    '1' 'aspartate3' '2.675' '2.6715' '0.002' '0.0015' '1' '1' '1';
    '1' 'aspartate_malate' '2.6905' '2.6855' '0.002' '0.002' '1' '1' '1';
    '1' 'malate4' '2.696' '2.692' '0.002' '0.002' '1' '1' '1';
    '1' 'aspartate4' '2.704' '2.7' '0.002' '0.001' '1' '1' '1';
    '2' 'unk39_s' '2.728' '2.725' '0.002' '0.001' '1' '1' '1';
    '2' 'unk40_s' '2.739' '2.736' '0.003' '0.001' '1' '1' '1';
    '1' 'sarcosine' '2.758' '2.754' '0.001' '0.002' '1' '1' '1';
    '1' 'aspartate4' '2.809' '2.798' '0.002' '0.005' '1' '1' '1';
    '1' 'aspartate1' '2.838' '2.827' '0.002' '0.005' '1' '1' '1';
    '2' 'unk_s' '2.845' '2.838' '0.002' '0.001' '1' '1' '1';
    '2' 'unk_s11' '2.856' '2.852' '0.001' '0.003' '1' '1' '1'; 
    '1' 'trimathylamine' '2.867' '2.86' '0.002' '0.003' '1' '1' '1';
    '2' 'unk_s111' '2.874' '2.869' '0.001' '0.002' '1' '1' '1'; 
    '2' 'unk43_s' '2.887' '2.882' '0.003' '0.006' '1' '1' '1'; 
    '2' 'unk44_s' '2.901' '2.893' '0.002' '0.002' '1' '1' '1'; 
    '2' 'unk45_s' '2.912' '2.907' '0.002' '0.003' '1' '1' '1'; 
    '2' 'unk94_s' '2.944' '2.938' '0.001' '0.006' '1' '1' '1'; 
    '1' 'lysine' '3.051' '3.007' '0.001' '0.005' '1' '1' '1'; 
    '2' 'unk52_s' '3.113' '3.108' '0.004' '0.005' '1' '1' '1';
    '3' 'bin22' '3.126' '3.12' '0.002' '0.005' '1' '1' '1'; 
    '1' 'malonate' '3.137' '3.129' '0.003' '0.005' '1' '1' '1'; 
    '3' 'bin23' '3.15' '3.14' '0.001' '0.001' '1' '1' '1'; 
    '2' 'unk53_s' '3.187' '3.181' '0.002' '0.002' '1' '1' '1'; 
    '2' 'unk_s' '3.197' '3.19' '0.002' '0.001' '1' '1' '1'; 
    '2' 'unk54_d' '3.221' '3.214' '0.005' '0.002' '1' '1' '1'; 
    '2' 'unk55_s' '3.233' '3.228' '0.002' '0.002' '1' '1' '1';
    '1' 'glucose2' '3.256' '3.233' '0.003' '0.0002' '1' '1' '1'; 
    '1' 'betaine1_glucose' '3.268' '3.263' '0.002' '0.002' '1' '1' '1'; 
    '2' 'unk56_s' '3.282' '3.277' '0.002' '0.004' '1' '1' '1'; 
    '2' 'unk57_d' '3.307' '3.3' '0.001' '0.002' '1' '1' '1'; 
    '2' 'unk58_s' '3.353' '3.348' '0.001' '0.002' '1' '1' '1';
    '1' 'methanol' '3.368' '3.364' '0.003' '0.007' '1' '1' '1'; 
    '1' 'carnitine' '3.4275' '3.424' '0.002' '0.005' '1' '1' '1'; 
    '3' 'bin_27' '3.431' '3.425' '0.001' '0.003' '1' '1' '1'; 
    '3' 'bin_35' '3.44' '3.433' '0.003' '0.001' '1' '1' '1'; 
    '3' 'bin_glucose_and_else1' '3.477' '3.449' '0.001' '0.001' '1' '1' '1';
    '1' 'glucose1' '3.5' '3.4755' '0.005' '0.004' '1' '1' '1'; 
    '2' 'unk59_d' '3.528' '3.516' '0.004' '0.005' '1' '1' '1'; 
    '3' 'bin_glucose_and_else2' '3.549' '3.525' '0.001' '0.002' '1' '1' '1'; 
    '2' 'unk60_s' '3.556' '3.55' '0.001' '0.001' '1' '1' '1';
    '1' 'glycine' '3.57' '3.563' '0.001' '0.002' '1' '1' '1'; 
    '1' 'glycerol1' '3.576' '3.57' '0.003' '0.001' '1' '1' '1'; 
    '2' 'unk62_s' '3.582' '3.577' '0.001' '0.001' '1' '1' '1';
    '1' 'glycerol2' '3.58' '3.5765' '0.002' '0.001' '1' '1' '1'; 
    '1' 'valine3' '3.623' '3.61' '0.002' '0.001' '1' '1' '1'; 
    '1' 'glycerol3' '3.65' '3.646' '0.004' '0.003' '1' '1' '1'; 
    '1' 'glycerol4' '3.657' '3.653' '0.003' '0.002' '1' '1' '1'; 
    '1' 'ethanol2' '3.6572' '3.652' '0.002' '0.001' '1' '1' '1'; 
    '1' 'N-phenylacetylglycine' '3.669' '3.666' '0.004' '0.002' '1' '1' '1'; 
    '1' 'isoleucine4' '3.677' '3.672' '0.002' '0.005' '1' '1' '1'; 
    '1' 'isoleucine5' '3.683' '3.678' '0.002' '0.001' '1' '1' '1'; 
    '2' 'unk72_s' '3.7815' '3.776' '0.001' '0.004' '1' '1' '1';
    '1' 'alanine4' '3.786' '3.783' '0.001' '0.001' '1' '1' '1'; 
    '2' 'unk73_d' '3.795' '3.787' '0.001' '0.001' '1' '1' '1';
    '1' 'alanine3' '3.798' '3.794' '0.002' '0.001' '1' '1' '1'; 
    '1' 'guanidoacetate' '3.802' '3.799' '0.001' '0.0015' '1' '1' '1'; 
    '1' 'alanine2' '3.812' '3.805' '0.001' '0.002' '1' '1' '1'; 
    '3' 'bin_28' '3.833' '3.815' '0.0001' '0.004' '1' '1' '1';
    '3' 'bin_L-Serine1' '3.855' '3.84' '0.003' '0.007' '1' '1' '1';
    '2' 'unk75_s' '3.86' '3.855' '0.004' '0.001' '1' '1' '1';
    '3' 'bin_glucose_and_else4' '3.919' '3.91' '0.002' '0.002' '1' '1' '1';
    '3' 'bin37' '3.946' '3.933' '0.01' '0.002' '1' '1' '1';
    '3' 'bin_glycolate' '3.95' '3.947' '0.006' '0.001' '1' '1' '1';
    '1' 'L-Serine2' '3.994' '3.955' '0.001' '0.004' '1' '1' '1'; 
    '2' 'unk95_d' '4.008' '3.997' '0.001' '0.003' '1' '1' '1';
    '2' 'unk78_s' '4.014' '4.009' '0.001' '0.002' '1' '1' '1';
    '2' 'unk80_d' '4.062' '4.057' '0.001' '0.003' '1' '1' '1';
    '1' 'proline' '4.1485' '4.145' '0.001' '0.002' '1' '1' '1'; 
    '1' 'threonine2' '4.284' '4.24' '0.001' '0.003' '1' '1' '1'; 
    '1' 'malate2' '4.326' '4.297' '0.002' '0.002' '1' '1' '1'; 
    '2' 'unk96_s' '4.37' '4.364' '0.002' '0.003' '1' '1' '1';
    '2' 'unk97_s' '4.428' '4.423' '0.003' '0.001' '1' '1' '1';
    '2' 'unk98_d' '4.532' '4.513' '0.002' '0.004' '1' '1' '1';
    '2' 'unk99_d' '4.663' '4.642' '0.002' '0.004' '1' '1' '1';
    '2' 'unk100_d' '4.945' '4.927' '0.001' '0.005' '1' '1' '1';
    '1' 'glucose3' '5.248' '5.234' '0.003' '0.005' '1' '1' '1'; 
    '1' 'galactose' '5.279' '5.267' '0.001' '0.001' '1' '1' '1';
    '2' 'unk82_t' '5.311' '5.295' '0.001' '0.002' '1' '1' '1';
    '2' 'unk102_d' '5.522' '5.51' '0.0001' '0.0001' '1' '1' '1';
    '1' 'Uracil1' '5.818' '5.794' '0.005' '0.008' '1' '1' '1'; 
    '1' 'fumarate' '6.526' '6.522' '0.003' '0.004' '1' '1' '1'; 
    '2' 'unk103_dd' '6.771' '6.738' '0.004' '0.001' '1' '1' '1';
    '2' 'unk104_s' '3.902' '3.895' '0.002' '0.003' '1' '1' '1';
    '1' 'tyrosine_1' '6.809' '6.797' '0.013' '0.008' '1' '1' '1'; 
    '1' 'tyrosine_2' '7.209' '7.183' '0.005' '0.005' '1' '1' '1'; 
    '1' 'phenylalanine' '7.344' '7.317' '0.003' '0.002' '1' '1' '1'; 
    '3' 'bin_N-phenylacetylglycine_phenylalanine_phenylacetate' '7.446' '7.414' '0.002' '0.006' '1' '1' '1';
    '1' 'N-phenylacetylglycine_phenylalanine' '7.449' '7.414' '0.005' '0.004' '1' '1' '1'; 
    '1' 'Uracil2' '7.553' '7.524' '0.004' '0.005' '1' '1' '1'; 
    '1' 'xanthine' '7.923' '7.895' '0.064' '0.044' '1' '1' '1'; 
    '1' 'formate' '8.463' '8.457' '0.004' '0.005' '1' '1' '1'}; 


options.intervals_class=str2num(cell2str(intervals(:,1)));
options.intervals_name=intervals(:,2);
options.intervals_ppm=cat(2,str2num(cell2str(intervals(:,3))),str2num(cell2str(intervals(:,4))));
options.intervals_ppm_flex=cat(2,str2num(cell2str(intervals(:,5))),str2num(cell2str(intervals(:,6))));
options.intervals_SS_and_total_1H=cat(2,str2num(cell2str(intervals(:,7))),str2num(cell2str(intervals(:,8)))); % e.g. for Alanine 7=# of 1H in SS & 8=# of 1H in a molecular
options.intervals_Interative_Align=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning Align
options.intervals_MCR_Components=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning 1 component MCR model
options.intervals_consistant_occasional=str2num(cell2str(intervals(:,9))); % 9 = 1 means consistently occuring mets & 2 means occasionally occuring mets

% Take only included variables for Quantification
options.VariablesIncluded=ones(size(options.intervals_class,1),1);


%% Option2 
% Which classes of variables should be processed
% [1] = knowns 
% [2] = unknowns 
% [3] = bins

options.VariableClass=[1:3];

%% Option 3
% Should Baseline be removed 
% Yes ( =1 ) or Not ( = 0 default)

options.BaseLineRemove= [1];  

%% Option 4 
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "

options.BaseLineProportion = 20;

%% Option 5 
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 

options.cutoff=3;

%% Option 6
% Reference Alignment 
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.05 -0.05];

% 0 = no refAlignment, 1 = refAlignment and continue, 2 = refAlignment and stop 
options.refAlignment.status=0;  

% Reference Alignemnt Region
options.refAlignment.region=[0.25 -0.25];

% Target vector used for global icoshift
options.refAlignment.target= 'average';

% definition of alignment mode
options.refAlignment.inter=[];

% icoshift Optional Inpuits - read "help icoshift3"
options.refAlignment.icoshiftOptions=[0 1 0 50 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.print=1; 

%% Option 7 
%  Get preAlignment seetings for a global icoshift. Please type "help icoshift3"

% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment and stop and return preAlignedData 
options.preAlignment.status=0;  

% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc.


% options.preAlignment.regions = [2.19 1.894; 2.33 2.19; 2.53 2.33; 2.63 2.558; 2.835 2.63; 3.08 2.835; 3.181 3.118;
%     3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
%    3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
%     0.9981 0.9515; 1.046 1.0175; 1.0175 0.9981; 1.079 1.046; 1.12 1.079; 1.231 1.17; 1.367 1.335;
%     1.518 1.479; 1.947 1.85; 2.12 1.947; 2.19 2.12; 2.289 2.21; 2.358 2.289; 2.383 2.358; 2.401 2.383; 2.497 2.443;
%     2.559 2.539; 2.63 2.558; 2.678 2.63; 2.835 2.678; 2.9565 2.835; 3 2.9565; 3.07 3.00; 3.181 3.118;
%     3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
%    3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
%    0.9977 0.9335; 0.997 0.962; 1.042 0.997; 1.041 1.018; 1.074 1.047; 
%     1.24 1.18; 1.375 1.332; 1.515 1.483; 1.945 1.929; 2.105 1.945; 2.19 2.105; 2.401 2.381 ; 
%    2.5 2.437; 2.56 2.537; 2.6 2.565; 2.695 2.655; 2.82 2.731; 2.96 2.84; 3.055 3.011; 
%    3.07 3.055; 3.082 3.07; 3.118 3.082; 3.355 3.331; 3.377 3.355; 3.39 3.377; 3.586 3.558; 3.61 3.586;
%    3.776 3.767; 3.797 3.776; 3.818 3.797; 3.974 3.951; 4.033 3.974; 4.106 4.06; 5.268 5.24];

options.preAlignment.regions = [2.19 2.105];



% Target vector used for global icoshift
options.preAlignment.target= 'average';

% definition of alignment mode
options.preAlignment.inter=[];

% max_ppm_allowed_shift
options.preAlignment.max_allowed_ppm_shift=0.01; 

% icoshift Optional Inpuits - read "help icoshift3"
options.preAlignment.icoshiftOptions=[0 1 0 options.preAlignment.max_allowed_ppm_shift 1 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.print=1; 

%% Option 8
%   Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"

% 0 = No intervalAlignment before quantification, 1 = Do intervalAlignment before quantification
options.intervalAlignment.status=1;  

% Target vector used for global icoshift
options.intervalAlignment.target = 'average';

% definition of alignment mode
options.intervalAlignment.inter=[];

% max_ppm_allowed_shift
options.intervalAlignment.max_allowed_ppm_shift=0.005; %max_ppm_allowed_shift

% icoshift Optional Inpuits - read "help icoshift3"
options.intervalAlignment.icoshiftOptions=[0 1 0 options.intervalAlignment.max_allowed_ppm_shift 1 1];

% Plot intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.plot=1; 

% Print intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.print=1; 


%% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  only the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0

options.should_left_out_ppm_regions_be_included.status=0; % default must be 1 (0= No)
options.should_left_out_ppm_regions_be_included.min_ppm=0.01; % (in ppm)

%% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3


options.automatic_interval_selection.status=0;
options.automatic_interval_selection.mode=2;
options.automatic_interval_selection.std_value=0.00015; % we need to explain this in help
options.automatic_interval_selection.peak_width=0.005; % we need to explain this in help
options.automatic_interval_selection.space_between_two_intervals=0.0005; % we need to explain this in help
options.automatic_interval_selection.continue_until_next_minimum=0; % we need to explain this in help
options.automatic_interval_selection.handles=[]; % we need to explain

%% Option 11
% 11 Color Options of Plots

options.Colors.red_transparent=[1 0.2 0.2, 0.2];
options.Colors.red=[1 0.2 0.2];
options.Colors.blue_transparent=[0.2 0.2 1, 0.2];
options.Colors.blue=[0.2 0.2 1];
options.Colors.green_transparent=[0.2 1 0.2, 0.2];
options.Colors.green=[0.2 1 0.2];
options.Colors.blueish_transparent=[0 0.4470 0.7410, 0.2];
options.Colors.brownish_transparent=[0.8500 0.3250 0.0980, 0.2];
options.Colors.yellowish=[0.9290 0.6940 0.1250, 0.2];
options.Colors.magendaish_transparent=[0.4940 0.1840 0.5560, 0.2];
options.Colors.greenish_transparent=[0.4660 0.6740 0.1880, 0.2];
options.Colors.light_blueish_transparent=[0.3010 0.7450 0.9330, 0.2];
options.Colors.redish_transparent=[0.6350 0.0780 0.1840, 0.2];
options.Colors.greyish_transparent=[0.25 0.25 0.25, 0.2];




end
