function [ options ] = sigma_oil_options1
%
%
% options for "sigma_sample_options" function
% to see how default "options" look run  [ options ] = sigma_urine_options;
% 
% Note: user can enter the option they wish & rest will be set to default parameters
%
%
% Option 1
% intervals = {'1','TSP','0.075','-0.075','0.001','0.001','9','1','1';...etc.};
% Nine inputs, 1=class, 2=name, 3=start ppm, 4=end ppm, 5=flex ppm right,
% 6=flex ppm left, 7= total Hs, 8= SS Hs, 9=(consistant=1, occasuanal=2)
%
% Option 2
% Get VariableClass
% It can only be 1-to-3
% 1 = knowns
% 2 = unknowns
% 3 = bins (this includes (optionally) user defined, automatically selected, and any other region left out as bins)
%
%
% Option 3
% Get BaseLineRemove
% No=0 & Yes=1. 
% default : options.BaseLineRemove= [0];  
%
% Option 4
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "
% default : options.BaseLineProportion = 20;
%
% Option 5
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 
% default : options.cutoff=3;
%
% Option 6
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.3 -0.3];
%
%
% Option 7
% Get preAlignment seetings for a global icoshift. Please type "help icoshift3"
% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment ans stop and return preAlignedData  
% default : options.preAlignment.status=[0];  
% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc. This optional input can also be left out.
% options.preAlignment.regions = [9 0.2];  means only do preAlignment of 9-0.2 ppm
% Target vector used for global icoshift
% default : options.preAlignment.target= 'average';
% definition of alignment mode
% default : options.preAlignment.inter='whole';
% shift allowed (optional)
% default : options.preAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.preAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 8
% Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"
% Target vector used for global icoshift
% default : options.intervalAlignment.target = 'average';
% shift allowed (optional)
% default : options.intervalAlignment.n='b';
% icoshift Optional Inpuits - read "help icoshift3"
% default : options.intervalAlignment.icoshiftOptions=[0 1 0 0.005 1 1];
%
% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  ionlt the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0
% default : options.wholeSpectra=1;
%
% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3
%
% Option 11
% Color Styles
%
%
% BKH, 17.02.2020

%% Option 0
load('oil_ref.mat');
load('oil_ref_ppm.mat');
options.ref_spect=oil_ref;
options.ref_spect_ppm=oil_ref_ppm;

%% Option 1

intervals={'1','beta-sitosterol1','0.6953','0.6778','0.001','0.001','1','1','1';
'1','saturated and monounsaturated omiga-9 fatty chain','0.8837','0.8571','0.001','0.001','1','1','1';
'1','linoleic chain1','0.9093','0.8841','0.001','0.001','1','1','1';
'1','linolenic chain1','0.9865','0.9534','0.001','0.001','1','1','1';
'1','acyl group of saturated fatty acid','1.2701','1.2104','0.001','0.001','1','1','1';
'1','acyl group of oleic acid  and esters','1.2882','1.2707','0.001','0.001','1','1','1';
'1','acyl group of polyenoic fatty acids and esters','1.3947','1.2889','0.001','0.001','1','1','1';
'1','gossypol1','1.5711','1.5529','0.001','0.001','1','1','1';
'1','beta-CH2','1.6561','1.5722','0.001','0.001','1','1','1';
'1','squalene','1.6818','1.661','0.001','0.001','1','1','1';
'1','alpha-CH2 to one double bond fatty acids','2.0799','1.9656','0.001','0.001','1','1','1';
'1','alpha-CH2 to ester','2.3205','2.2658','0.001','0.001','1','1','1';
'1','(9-cis, 11-trans) conjugated linoleic acids','2.3867','2.3513','0.001','0.001','1','1','1';
'1','conjugated ketodienes','2.5297','2.4929','0.001','0.001','1','1','1';
'1','hydroxytyrosol','2.6046','2.5749','0.001','0.001','1','1','1';
'1','polyenoic fatty acids and esters(cis-trans)','2.6751','2.6369','0.001','0.001','1','1','1';
'1','linoleic chain2','2.7836','2.7412','0.001','0.001','1','1','1';
'1','linolenic chain2','2.8168','2.7844','0.001','0.001','1','1','1';
'1','Keto-epoxy-monoenes 1','2.9156','2.8835','0.001','0.001','1','1','1';
'1','beta-sitosterol2','3.5233','3.4613','0.001','0.001','1','1','1';
'1','sn-1,2/2,3 diglycerides','3.7382','3.679','0.001','0.001','1','1','1';
'1','gossypol2','3.9121','3.8748','0.001','0.001','1','1','1';
'1','sn-1,3-diacylglycerides 2','4.0328','3.9912','0.001','0.001','1','1','1';
'1','triglycerides1','4.1671','4.1029','0.001','0.001','1','1','1';
'1','sn-1,3-diacylglycerides','4.1912','4.1687','0.001','0.001','1','1','1';
'1','sn-1,2-diacylglycerides1','4.2337','4.1952','0.001','0.001','1','1','1';
'1','triglycerides 2','4.3204','4.2707','0.001','0.001','1','1','1';
'1','sn-1,2-diacylglycerides2','4.3477','4.3211','0.001','0.001','1','1','1';
'1','esters of phytol & geranylgeraniol','4.5888','4.5662','0.001','0.001','1','1','1';
'1','beta-sitosteryl acetate','4.6368','4.5896','0.001','0.001','1','1','1';
'1','triglycerides3','5.2798','5.2246','0.001','0.001','1','1','1';
'1','olefeinic protons of triglycerides','5.3972','5.2805','0.001','0.001','1','1','1';
'1','punicic acid1','5.4779','5.431','0.001','0.001','1','1','1';
'1','alpha-eleostearic acid','5.6769','5.6166','0.001','0.001','1','1','1';
'1','beta-eleostearic acid','5.7672','5.6904','0.001','0.001','1','1','1';
'1','gama-Tocopherol','6.3582','6.3421','0.001','0.001','1','1','1';
'1','tyrosol derivatives','7.0206','6.9911','0.001','0.001','1','1','1';
'2','unk1','0.7073','0.7003','0.001','0.001','1','1','1';
'2','unk2','0.7255','0.7171','0.001','0.001','1','1','1';
'2','unk3','0.7649','0.7584','0.001','0.001','1','1','1';
'2','unk4','0.8184','0.8115','0.001','0.001','1','1','1';
'2','unk5','0.8287','0.8218','0.001','0.001','1','1','1';
'2','unk6','0.8353','0.8295','0.001','0.001','1','1','1';
'2','unk7','0.8402','0.8354','0.001','0.001','1','1','1';
'2','unk8','0.8521','0.8410','0.001','0.001','1','1','1';
'2','unk9','1.4775','1.4417','0.001','0.001','1','1','1';
'2','unk10','1.8719','1.822','0.001','0.001','1','1','1';
'2','unk11','1.9159','1.8809','0.001','0.001','1','1','1';
'2','unk12','1.9614','1.9171','0.001','0.001','1','1','1';
'2','unk13','2.1354','2.1014','0.001','0.001','1','1','1';
'2','unk14','2.1706','2.1364','0.001','0.001','1','1','1';
'2','unk15','2.2167','2.1711','0.001','0.001','1','1','1';
'2','unk16','2.346','2.3226','0.001','0.001','1','1','1';
'2','unk17','2.8836','2.8502','0.001','0.001','1','1','1';
'2','unk18','3.6488','3.639','0.001','0.001','1','1','1';
'2','unk19','3.978','3.9594','0.001','0.001','1','1','1';
'2','unk20','4.0739','4.0339','0.001','0.001','1','1','1';
'2','unk21','4.4355','4.3984','0.001','0.001','1','1','1';
'2','unk22','7.038','7.0234','0.001','0.001','1','1','1';
'2','unk23','7.2328','7.1975','0.001','0.001','1','1','1';
'3','bin-gramisterol, citrostadienol, D7-avenasterol, D7-campesterol','0.5486','0.5352','0.001','0.001','1','1','1';
'3','bin-esters of cycloartenol, 24-methylenecycloartanol & cyclobranol','0.5844','0.5489','0.001','0.001','1','1','1';
'3','bin-oleanolic acid-maslinic acid','0.7783','0.7675','0.001','0.001','1','1','1';
'3','bin-13C satellites1','0.7974','0.7788','0.001','0.001','1','1','1';
'3','bin1','0.9380','0.9139','0.001','0.001','1','1','1';
'3','bin-13C satellites2','1.0243','0.9868','0.001','0.001','1','1','1';
'3','bin2','1.0351','1.0251','0.001','0.001','1','1','1';
'3','bin3','1.4401','1.4043','0.001','0.001','1','1','1';
'3','bin4','1.5138','1.4829','0.001','0.001','1','1','1';
'3','bin5','1.5528','1.5181','0.001','0.001','1','1','1';
'3','bin6','1.8215','1.746','0.001','0.001','1','1','1';
'3','bin7','2.4332','2.3868','0.001','0.001','1','1','1';
'3','bin8','2.7332','2.6902','0.001','0.001','1','1','1';
'3','bin-oleanolic acid, cycloeucalenol, butyrospermol','3.2466','3.2026','0.001','0.001','1','1','1';
'3','bin-tetracosanol, hexacosanol, 1-monoacylglycerides','3.6275','3.5596','0.001','0.001','1','1','1';
'3','bin9','4.1023','4.0788','0.001','0.001','1','1','1';
'3','bin10','4.270','4.2395','0.001','0.001','1','1','1';
'3','bin-cycloeucalenol, 24-methylenecycloartanol, gramisterol, obtusifoliol1','4.667','4.6448','0.001','0.001','1','1','1';
'3','bin-cycloeucalenol, 24-methylenecycloartanol, gramisterol, obtusifoliol2','4.7151','4.7016','0.001','0.001','1','1','1';
'3','bin-sn-1,2/2,3 diacylglycerides','5.1076','5.0585','0.001','0.001','1','1','1';
'3','bin-squalene','5.162','5.1081','0.001','0.001','1','1','1';
'3','bin11','5.2225','5.1691','0.001','0.001','1','1','1';
'3','bin12','5.4307','5.3981','0.001','0.001','1','1','1';
'3','HPO-c(Z,E)dEs1','5.5423','5.4787','0.001','0.001','1','1','1';
'3','HO-c(E,E)dEs','5.5996','5.5431','0.001','0.001','1','1','1';
'3','HPO-c(Z,E)dEs2','6.019','5.8954','0.001','0.001','1','1','1';
'3','bin-HO-c(E,E)dEs-KO-c(Z,E)dEs','6.1763','6.0192','0.001','0.001','1','1','1';
'3','HPO-c(E,E)dEs','6.2636','6.2017','0.001','0.001','1','1','1';
'3','keto-epoxy-monoenes2','6.3264','6.2685','0.001','0.001','1','1','1';
'3','bin-punicic acid-HO-c(Z,E)dEs','6.5041','6.4425','0.001','0.001','1','1','1';
'3','keto-epoxy-monoenes3','6.573','6.5129','0.001','0.001','1','1','1';
'3','bin13','7.1603','7.0906','0.001','0.001','1','1','1'};



options.intervals_class=str2num(cell2str(intervals(:,1)));
options.intervals_name=intervals(:,2);
options.intervals_ppm=cat(2,str2num(cell2str(intervals(:,3))),str2num(cell2str(intervals(:,4))));
options.intervals_ppm_flex=cat(2,str2num(cell2str(intervals(:,5))),str2num(cell2str(intervals(:,6))));
options.intervals_SS_and_total_1H=cat(2,str2num(cell2str(intervals(:,7))),str2num(cell2str(intervals(:,8)))); % e.g. for Alanine 7=# of 1H in SS & 8=# of 1H in a molecular
options.intervals_Interative_Align=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning Align
options.intervals_MCR_Components=ones(size(options.intervals_class,1),1); % By Default All 1 - meaning 1 component MCR model
options.intervals_consistant_occasional=str2num(cell2str(intervals(:,9))); % 9 = 1 means consistently occuring mets & 2 means occasionally occuring mets

% Take only included variables for Quantification
options.VariablesIncluded=ones(size(options.intervals_class,1),1);


%% Option2 
% Which classes of variables should be processed
% [1] = knowns 
% [2] = unknowns 
% [3] = bins

options.VariableClass=[1:3];

%% Option 3
% Should Baseline be removed 
% Yes ( =1 ) or Not ( = 0 default)

options.BaseLineRemove= [1];  

%% Option 4 
% Get BaseLineProportion
% How many % of data points from the minimum to max must be used prior to
% calculate Noise using Equation "noise=nanmean(nanmean(Baseline_Intensities)); "

options.BaseLineProportion = 20;

%% Option 5 
% Get cutoff level
% What factor must be used to multiply with Noise prior to Remove Baseline
% Cutoff_Level=noise*cutoff; 

options.cutoff=3;

%% Option 6
% Reference Alignment 
% Alignment of the Entire Spectra according to the Reference Signal which
% is usually TSP singlet at 0.00 ppm., e.g, options.RefAlignment=[0.05 -0.05];

% 0 = no refAlignment, 1 = refAlignment and continue, 2 = refAlignment and stop 
options.refAlignment.status=0;  

% Reference Alignemnt Region
options.refAlignment.region=[0.25 -0.25];

% Target vector used for global icoshift
options.refAlignment.target= 'average';

% definition of alignment mode
options.refAlignment.inter=[];

% icoshift Optional Inpuits - read "help icoshift3"
options.refAlignment.icoshiftOptions=[0 1 0 50 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.refAlignment.print=1; 

%% Option 7 
%  Get preAlignment seetings for a global icoshift. Please type "help icoshift3"

% 0 = no preAlignment, 1 = preAlignment and continue, 2= preAlignment and stop and return preAlignedData 
options.preAlignment.status=0;  

% % What ppm range(s) must be used for global icoshift. Example for one range: [1.4 0.6]. for more ranges: [1.4 0.6; 3.6 2.1] etc.


% options.preAlignment.regions = [2.19 1.894; 2.33 2.19; 2.53 2.33; 2.63 2.558; 2.835 2.63; 3.08 2.835; 3.181 3.118;
%     3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
%    3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
%     0.9981 0.9515; 1.046 1.0175; 1.0175 0.9981; 1.079 1.046; 1.12 1.079; 1.231 1.17; 1.367 1.335;
%     1.518 1.479; 1.947 1.85; 2.12 1.947; 2.19 2.12; 2.289 2.21; 2.358 2.289; 2.383 2.358; 2.401 2.383; 2.497 2.443;
%     2.559 2.539; 2.63 2.558; 2.678 2.63; 2.835 2.678; 2.9565 2.835; 3 2.9565; 3.07 3.00; 3.181 3.118;
%     3.249 3.186; 3.302 3.249; 3.392 3.325; 3.465 3.405; 3.526 3.465; 3.588 3.526; 3.588 3.558; 3.649 3.588; 3.716 3.649;
%    3.829 3.717; 3.829 3.767; 3.901 3.829; 3.954 3.901; 4.158 4.107; 4.17 4.158; 5.4 5.15; 5.263 5.24; 8.505 8.457;
%    0.9977 0.9335; 0.997 0.962; 1.042 0.997; 1.041 1.018; 1.074 1.047; 
%     1.24 1.18; 1.375 1.332; 1.515 1.483; 1.945 1.929; 2.105 1.945; 2.19 2.105; 2.401 2.381 ; 
%    2.5 2.437; 2.56 2.537; 2.6 2.565; 2.695 2.655; 2.82 2.731; 2.96 2.84; 3.055 3.011; 
%    3.07 3.055; 3.082 3.07; 3.118 3.082; 3.355 3.331; 3.377 3.355; 3.39 3.377; 3.586 3.558; 3.61 3.586;
%    3.776 3.767; 3.797 3.776; 3.818 3.797; 3.974 3.951; 4.033 3.974; 4.106 4.06; 5.268 5.24];

options.preAlignment.regions = [2.19 2.105];



% Target vector used for global icoshift
options.preAlignment.target= 'average';

% definition of alignment mode
options.preAlignment.inter=[];

% max_ppm_allowed_shift
options.preAlignment.max_allowed_ppm_shift=0.01; 

% icoshift Optional Inpuits - read "help icoshift3"
options.preAlignment.icoshiftOptions=[0 1 0 options.preAlignment.max_allowed_ppm_shift 1 1];

% Plot preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.plot=1; 

% Print preAlignment: Yes ( =1 ) or Not ( = 0 default)
options.preAlignment.print=1; 

%% Option 8
%   Get intervalAlignment seetings for a icoshift. Please type "help icoshift3"

% 0 = No intervalAlignment before quantification, 1 = Do intervalAlignment before quantification
options.intervalAlignment.status=1;  

% Target vector used for global icoshift
options.intervalAlignment.target = 'average';

% definition of alignment mode
options.intervalAlignment.inter=[];

% max_ppm_allowed_shift
options.intervalAlignment.max_allowed_ppm_shift=0.005; %max_ppm_allowed_shift

% icoshift Optional Inpuits - read "help icoshift3"
options.intervalAlignment.icoshiftOptions=[0 1 0 options.intervalAlignment.max_allowed_ppm_shift 1 1];

% Plot intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.plot=1; 

% Print intervalAlignment: Yes ( =1 ) or Not ( = 0 default)
options.intervalAlignment.print=1; 


%% Option 9
% Include left out ppm ranges from "options.intervals_ppm". If set to 1, it means all ppm_scale (wholeSpectra) will be used for quantification, apart from those incl. in "options.intervals_ppm".
% These left out ppm ranges will not be Aligned and/or BaseLineRemoved. If set to No=0,  only the ranges incl. in "options.intervals_ppm"  will be used for quantification.
% Yes=1 & No=0

options.should_left_out_ppm_regions_be_included.status=0; % default must be 1 (0= No)
options.should_left_out_ppm_regions_be_included.min_ppm=0.01; % (in ppm)

%% Option 10
% Automatic Interval Selection Optional
% status = Yes (=1), No (=0)
% modes:
% 0 (Use ONLY Automatically Selected Intervals)
% 1 (Use BOTH Automatically Selected Intervals and User Defined Intervals)
% 2 ( Use Unique Automatically Selected Intervals (different in relation to User Defined Intervals) and User Defined Intervals)
% 3 ( Use Unique Automatically Selected Intervals & other Auto Slected Intervals that are partially Overlapped  + User Defined Intervals)
% Prefered Modes are 2 or 3


options.automatic_interval_selection.status=0;
options.automatic_interval_selection.mode=2;
options.automatic_interval_selection.std_value=0.00015; % we need to explain this in help
options.automatic_interval_selection.peak_width=0.005; % we need to explain this in help
options.automatic_interval_selection.space_between_two_intervals=0.0005; % we need to explain this in help
options.automatic_interval_selection.continue_until_next_minimum=0; % we need to explain this in help
options.automatic_interval_selection.handles=[]; % we need to explain

%% Option 11
% 11 Color Options of Plots

options.Colors.red_transparent=[1 0.2 0.2, 0.2];
options.Colors.red=[1 0.2 0.2];
options.Colors.blue_transparent=[0.2 0.2 1, 0.2];
options.Colors.blue=[0.2 0.2 1];
options.Colors.green_transparent=[0.2 1 0.2, 0.2];
options.Colors.green=[0.2 1 0.2];
options.Colors.blueish_transparent=[0 0.4470 0.7410, 0.2];
options.Colors.brownish_transparent=[0.8500 0.3250 0.0980, 0.2];
options.Colors.yellowish=[0.9290 0.6940 0.1250, 0.2];
options.Colors.magendaish_transparent=[0.4940 0.1840 0.5560, 0.2];
options.Colors.greenish_transparent=[0.4660 0.6740 0.1880, 0.2];
options.Colors.light_blueish_transparent=[0.3010 0.7450 0.9330, 0.2];
options.Colors.redish_transparent=[0.6350 0.0780 0.1840, 0.2];
options.Colors.greyish_transparent=[0.25 0.25 0.25, 0.2];




end
