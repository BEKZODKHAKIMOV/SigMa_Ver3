function [ options ] = sigma_get_options_bkh( sample_type )


     switch strcmp(sample_type,'urine');
        case 1
            options=sigma_urine_options1;
     end;
    
     switch strcmp(sample_type,'plasma');
        case 1
            options=sigma_plasma_options1;
    end;
    
    switch strcmp(sample_type,'faecal');
        case 1
            options=sigma_faecal_options1;
    end;
     

end

